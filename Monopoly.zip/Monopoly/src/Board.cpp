/*
 * Board.cpp
 *
 *  Created on: Mar 19, 2021
 *      Author: Andrew Hariyanto
 */

#include "Board.h"

Board::Board() {
	// TODO Auto-generated constructor stub

}

Board::~Board() {
	// TODO Auto-generated destructor stub
}


void Board::initializeBoard(){
	for(int row = 0; row < 32; row++){
		Cell** cellAddress = cellP + row;
		Cell* cell = (Cell*) malloc(sizeof(Cell));

		cell->setRowNum(row);
		cell->setOwner(-1);
		cell->setNumHouses(0);

		if(row == 0){
			cell->setType(3);
		}
		else if(row == 2 || row==10 || row ==18 || row ==26){
			cell->setType(2);
		}
		else if(row == 8 || row == 16 || row == 24){
			cell->setType(4);
		}
		else if(row == 5|| row==13 || row==21 || row ==29 ){
			cell->setType(1);
		}
		else{
			cell->setType(0);
		}

		*(cellAddress) = cell;
	}
}

void Board::displayBoard(){
	int streetAccum = 0;
	int railroadAccum = 0;
	int chanceAccum = 0;

	printf("Here is the board\n");fflush(stdout);
	printf(" _______________________________________________\n");fflush(stdout);
	printf("|Row Number| Location | Details\n");fflush(stdout);
	printf("|    0     |    GO    | earn $200\n");fflush(stdout);
	for(int i = 1; i < 32; i++){
		Cell* cell = this->getCell(i);
		if(cell->getType() == 0){
			if(i >= 10){
				if(streetAccum >= 10){
					printf("|    %d    | street%d | owned by %d with %d houses\n", i, streetAccum,
							cell->getOwner(), cell->getNumHouses());fflush(stdout);
				}
				else{
					printf("|    %d    | street%d  | owned by %d with %d houses\n", i, streetAccum,
							cell->getOwner(), cell->getNumHouses());fflush(stdout);
				}
			}
			else{
				printf("|    %d     | street%d  | owned by %d with %d houses\n", i, streetAccum,
						cell->getOwner(), cell->getNumHouses());fflush(stdout);
			}
			streetAccum++;
		}
		if(cell->getType() == 1){
			if( i >= 10){
				printf("|    %d    |railroad%d | owned by %d\n", i, railroadAccum, cell->getOwner());fflush(stdout);
			}
			else{
				printf("|    %d     |railroad%d | owned by %d\n", i, railroadAccum, cell->getOwner());fflush(stdout);
			}
			railroadAccum++;
		}
		if(cell->getType() == 2){
			if(i >= 10){
				printf("|    %d    | chance%d  | get a chance card\n", i, chanceAccum);fflush(stdout);
			}
			else{
				printf("|    %d     | chance%d  | get a chance card\n", i, chanceAccum);fflush(stdout);
			}
			chanceAccum++;
		}
		if(cell->getType() == 4){
			if(i >= 10){
				printf("|    %d    |   free   | no need to do anything\n", i);fflush(stdout);
			}
			else{
				printf("|    %d     |   free   | no need to do anything\n", i);fflush(stdout);
			}
		}
	}
	printf("-----------------------------------------------\n");fflush(stdout);
}


Cell* Board::getCell(int num){
	return *(cellP + num);
}

void Board::setCellP(Cell** cellP){
	this->cellP = cellP;
}

Cell** Board::getCellP(){
	return cellP;
}

int Board::sellProperty(int playerNum, bool* soldRailRoad){
	int i = -1;
	bool done = false;
	bool done1= false;

	printf("You need to sell one of your properties\n");fflush(stdout);
	int row = -1;
	printf("Please pick the row of the property you want to sell: ");fflush(stdout);
	scanf(" %d", &row);

	Cell* cell = this->getCell(row);

	while(!done){
		cell = this->getCell(row);
		if(cell->getOwner() == playerNum){
			done = true;
		}
		else{
			printf("You don't own this property\n");fflush(stdout);
			printf("Please choose the row again: ");fflush(stdout);
			scanf(" %d", &row);
		}
	}

	if(cell->getType() == 1){//railroad
		printf("You are now selling a railroad\n");fflush(stdout);
		int propertyPrice = cell->getBuyPrice();
		i = propertyPrice/2;
		*soldRailRoad = true;
		cell->setOwner(-1);
	}
	else{
		while(!done1){

			*soldRailRoad = false;
			char x = 'x';
			printf("Do you want to sell the street or just houses? p for former / h for later: ");fflush(stdout);
			scanf(" %c", &x);fflush(stdin);

			if(x == 'p'){//means street including all houses on it

				int propertyPrice = cell->getBuyPrice();
				int housePrice = 30*(cell->getNumHouses());

				i = (propertyPrice + housePrice)/2;
				cell->setNumHouses(0);
				cell->setOwner(-1);
				done1 = true;
			}
			else if(x == 'h'){//means houses only
				int num = -1;
				printf("Number of houses you want to sell: ");fflush(stdout);
				scanf(" %d", &num);

				bool done2 = false;
				while(!done2){
					if(cell->getNumHouses() < num){
						printf("You don't have that many houses please try again: ");fflush(stdout);
						scanf(" %d", &num);
					}
					else{
						cell->setNumHouses(cell->getNumHouses() - num);

						i = (num*30)/2;
						done1 = true;
						done2 = true;
					}
				}

			}
			else{
				printf("Invalid input please try again: p/h");fflush(stdout);
				scanf(" %c", &x);
			}
		}
	}
	return i;
}
