/*
 * PlayerPiece.cpp
 *
 *  Created on: Mar 19, 2021
 *      Author: Andrew Hariyanto
 */

#include "PlayerPiece.h"
#include "Cell.h"
#include "Board.h"

PlayerPiece::PlayerPiece() {
	// TODO Auto-generated constructor stub

}

PlayerPiece::~PlayerPiece() {
	// TODO Auto-generated destructor stub
}

void PlayerPiece::setPlayerNum(int num){
	this->playerNum = num;
}

int PlayerPiece::getPlayerNum(){
	return playerNum;
}

void PlayerPiece::setRowNum(int num){
	this->rowNum = num;
}

int PlayerPiece::getRowNum(){
	return rowNum;
}
void PlayerPiece::setWallet(int amount){
	this->wallet = amount;
}
int PlayerPiece::getWallet(){
	return wallet;
}

void PlayerPiece::setPropertyOwned(int amount){
	this->propertyOwned = amount;
}

int PlayerPiece::getPropertyOwned(){
	return this->propertyOwned;
}

bool PlayerPiece::isBankrupt(){
	bool ok = false;

	if(this->wallet <= 0 && this->propertyOwned == 0){
		ok = true;
	}

	return ok;
}

void PlayerPiece::setNumRailroads(int num){
	this->numRailroads = num;
}

int PlayerPiece::getNumRailroads(){
	return this->numRailroads;
}

void PlayerPiece::addToWallet(int amount){
	this->wallet = this->wallet + amount;
}

void PlayerPiece::takeFromWallet(int amount){
	wallet = this->wallet - amount;
}

void PlayerPiece::addPropertyOwned(int amount){
	propertyOwned = this->propertyOwned + amount;
}

bool PlayerPiece::checkEnoughMoney(int price){
	bool ok = false;

	if(wallet >= price){
		ok = true;
	}

	return ok;
}

bool PlayerPiece::wantToBuy(int propertyNum, Board* board){
	char x = 'x';
	bool ans = false;

	Cell* cell = board->getCell(propertyNum);


	printf("Do you want to buy this property? Y/N: ");fflush(stdout);
	scanf(" %c", &x);

	if(x == 'Y'){
		cell->setOwner(this->playerNum);
		this->takeFromWallet(cell->getBuyPrice());
		propertyOwned = this->propertyOwned + cell->getBuyPrice();
		if(cell->getType() == 1){
			this->numRailroads++;
		}
		ans = true;
	}
	return ans;
}

void PlayerPiece::upgradeProperty(Board* board, int* housesBought){//check if have enough for one house at least
	int x = -1;
	int numHouses = -1;
	bool done = false;

	while(!done){
		printf("Which property do you want to upgrade? ");fflush(stdout);
		scanf(" %d", &x);
		Cell* cell = board->getCell(x);
		if(cell->getNumHouses() < 4){

			printf("How many houses do you want to buy? ");fflush(stdout);
			scanf(" %d", &numHouses);

			int currentHouses = cell->getNumHouses() + numHouses;

			*housesBought = numHouses;

			if(currentHouses > 4){
				printf("You passed the limit please try again\n");fflush(stdout);
			}
			else{
				int value = numHouses*30;

				if(this->checkEnoughMoney(value)){
					printf("Assets before is %d\n", propertyOwned);
					this->propertyOwned = propertyOwned + value;
					cell->setNumHouses(currentHouses);
					done = true;
				}
				else{
					printf("Please try again... you have enough for at least one house\n");fflush(stdout);
				}


			}
		}
		else{
			printf("Max houses reached please choose another location\n");fflush(stdout);
		}
	}
}


bool PlayerPiece::passedGo(Move* move){
	bool ok = false;

	if(move->newRow < move->oldRow){
		ok = true;
	}

	return ok;
}
