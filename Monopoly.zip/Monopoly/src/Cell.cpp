/*
 * Cell.cpp
 *
 *  Created on: Mar 19, 2021
 *      Author: Andrew Hariyanto
 */

#include "Cell.h"

Cell::Cell() {
	// TODO Auto-generated constructor stub

}

Cell::~Cell() {
	// TODO Auto-generated destructor stub
}

void Cell::setRowNum(int num){
	this->rowNum = num;
}

int Cell::getRowNum(){
	return rowNum;
}

int Cell::getType(){
	if(isStreet){return 0;}
	else if(isRailroad){return 1;}
	else if(isChance){return 2;}
	else if(isGo){return 3;}
	else if(isRest){return 4;}
}

void Cell::setType(int num){
	switch(num){
	case 0://street
		this->isStreet = true;
		this->isChance = false;
		this->isGo = false;
		this->isRailroad = false;
		this->isRest = false;
		break;
	case 1://railroad
		this->isStreet = false;
		this->isChance = false;
		this->isGo = false;
		this->isRailroad = true;
		this->isRest = false;
		break;
	case 2://chance
		this->isStreet = false;
		this->isChance = true;
		this->isGo = false;
		this->isRailroad = false;
		this->isRest = false;
		break;
	case 3://go
		this->isStreet = false;
		this->isChance = false;
		this->isGo = true;
		this->isRailroad = false;
		this->isRest = false;
		break;
	case 4://free
		this->isStreet = false;
		this->isChance = false;
		this->isGo = false;
		this->isRailroad = false;
		this->isRest = true;
		break;
	default:
		this->isStreet = false;
		this->isChance = false;
		this->isGo = false;
		this->isRailroad = false;
		this->isRest = false;
		break;
	}
}


void Cell::setOwner(int num){
	this->ownedBy = num;
}

int Cell::getOwner(){
	return ownedBy;
}

void Cell::setNumHouses(int num){
	this->numHouses = num;
}

int Cell::getNumHouses(){
	return numHouses;
}

PlayerPiece* Cell::findPlayer(int playerNum, PlayerPiece** players){
	PlayerPiece** temp = players + playerNum;
	return *(temp);
}

int Cell::getBuyPrice(){
	int i = -1;
	int row = this->getRowNum();

	if(this->getType() == 0){//street
		if(row >= 0 && row <= 7){
			i = 20;
		}
		else if(row >=8 && row <=15){
			i = 40;
		}
		else if(row >= 16 && row <= 23){
			i = 50;
		}
		else if(row >= 24 && row <=31){
			i = 70;
		}
	}
	if(this->getType() == 1){//railroad
		i = 100;
	}
	return i;
}

int Cell::getRentPrice(PlayerPiece** players){
	if(this->getType() == 0){//street
		if(this->numHouses == 4){
			return 60;
		}
		else{
			return (this->numHouses + 1)*10;//0->10, 1->20,2->30,3->40
		}
	}
	else if (this->getType() == 1){//railroad
		int playerOwns = this->getOwner();
		PlayerPiece* player = this->findPlayer(playerOwns, players);
		return 25*(player->getNumRailroads());
	}
	else{
		printf("invalid\n");fflush(stdout);
		return -1;
	}
}
