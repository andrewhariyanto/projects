/*
 * Production.h
 *
 *  Created on: Mar 19, 2021
 *      Author: Andrew Hariyanto
 */

#ifndef PRODUCTION_H_
#define PRODUCTION_H_
#include <stdio.h>
#include <stdbool.h>
#include <string.h>//strncpy
#include <stdlib.h>//strtol

#include "Board.h"
#include "LList.h"


#define FILENAMELENGTHALLOWANCE 50

class Production {
public:
	Production();
	virtual ~Production();
	bool prod(int argc, char* argv[]);
	bool readFile(char*, int*, Board*, PlayerPiece**);
	int rollDice(int, int);
	int rollChance();
	void displayHoldings(PlayerPiece**, int);
	void canPay(PlayerPiece*, Board*, int, Move*, int*);



private:

};

#endif /* PRODUCTION_H_ */
