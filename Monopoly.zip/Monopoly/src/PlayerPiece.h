/*
 * PlayerPiece.h
 *
 *  Created on: Mar 19, 2021
 *      Author: Andrew Hariyanto
 */

#ifndef PLAYERPIECE_H_
#define PLAYERPIECE_H_

class Board;
#include "LList.h"



class PlayerPiece {
public:
	PlayerPiece();
	virtual ~PlayerPiece();
	void setPlayerNum(int);
	int getPlayerNum();
	void setRowNum(int);
	int getRowNum();
	void setWallet(int);
	int getWallet();
	void setPropertyOwned(int);
	int getPropertyOwned();
	void setNumRailroads(int);
	int getNumRailroads();

	bool isBankrupt();
	void addToWallet(int);
	void takeFromWallet(int);
	void addPropertyOwned(int);
	bool checkEnoughMoney(int);
	bool wantToBuy(int, Board*); //user input function
	void upgradeProperty(Board*, int*); //user input function


	bool passedGo(Move*);//if newRow < oldRow then yes


private:
	int playerNum;
	int rowNum;
	int wallet;
	int propertyOwned; //in terms of money
	int numRailroads;

};

#endif /* PLAYERPIECE_H_ */
