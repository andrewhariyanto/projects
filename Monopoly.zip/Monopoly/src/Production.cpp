/*
 * Production.cpp
 *
 *  Created on: Mar 19, 2021
 *      Author: Andrew Hariyanto
 */

#include "Production.h"
#include <stdbool.h>

Production::Production() {
	// TODO Auto-generated constructor stub

}

Production::~Production() {
	// TODO Auto-generated destructor stub
}

bool Production::prod(int argc, char* argv[])
{
	printf("Starting Production\n");
	bool answer = false;

	if(argc <=1) //no interesting information
	{
		puts("Didn't find any arguments.");
		fflush(stdout);
		answer = false;
	}
	else //there is interesting information
	{
		printf("Found %d interesting arguments.\n", argc-1);
		fflush(stdout);
		char filename[FILENAMELENGTHALLOWANCE];
		char* eptr=(char*) malloc(sizeof(char*));
		long aL=-1L;
		int maxRolls;
		int whoFirst;

		for(int i = 1; i<argc; i++) //don't want to read argv[0]
				{//argv[i] is a string

					switch(i)
					{
					case 1:
						//this is filename
						printf("The length of the filename is %d.\n",strlen(argv[i]));
						printf("The proposed filename is %s.\n", argv[i]);
						if(strlen(argv[i])>=FILENAMELENGTHALLOWANCE)
						{
							puts("Filename is too long.");
							fflush(stdout);
							answer = false;
						}
						else
						{
							strcpy(filename, argv[i]);
							printf("Filename was %s.\n", filename);
							fflush(stdout);
						}
						break;
					case 2:
						//this is maximum number of rolls

						aL = strtol(argv[i], &eptr, 10);
						maxRolls = (int) aL;
						printf("Number of rolls is %d\n",maxRolls);fflush(stdout);
						break;
					case 3:
						//who goes first

						aL = strtol(argv[i], &eptr, 10);
						whoFirst = (int)aL;
						printf("Player %d goes first\n",whoFirst);fflush(stdout);
						break;

					default:
						puts("Unexpected argument count."); fflush(stdout);
						answer = false;
						break;
					}//end of switch
				}//end of for loop on argument count
				puts("after reading arguments"); fflush(stdout);

		//we'll want to read the file
		int nPlayers = -1;
		Board* board = new Board();
		LList* myLL = new LList();
		PlayerPiece* players[10];//addresses for 10 players

		puts("Before read file"); fflush(stdout);
		answer = readFile(filename, &nPlayers, board, players); //read the file
		puts("Back from read file"); fflush(stdout);

		int rollNumberAccum = 0;
		bool done = false;

		board->displayBoard();
		displayHoldings(players,nPlayers);

		//play one round starting with the first player then make it a while loop
		for(int i = whoFirst; i < nPlayers; i++){
			printf("Player %d's turn\n",i);fflush(stdout);
			rollNumberAccum++;
			int totalSoldProperty = 0;
			int totalCost = 0;
			Move* myMove = (Move*)malloc(sizeof(Move)); //for log file records
			myMove->playerNum = i;
			myMove->MoveNum = rollNumberAccum;
			myMove->cellType = -1;
			myMove->diceRoll = -1;
			myMove->housesBought = 0;
			myMove->madePurchase = false;
			myMove->madeUpgrade = false;
			myMove->newBalance = -1;
			myMove->newRow = -1;
			myMove->oldBalance = -1;
			myMove->oldRow = -1;
			myMove->passedGo = false;
			myMove->propertySoldAmount = -1;
			myMove->rolledChance = false;
			myMove->isLucky = false;
			myMove->soldProperty = false;
			myMove->wasBankrupt = false;//became bankrupt in the middle of the game
			myMove->alreadyBankrupt = false;//is already bankrupt before this turn
			myMove->propertyIsOwned = false;//if you land on another player's cell
			myMove->chanceAmt = -1;
			myMove->rentAmt = -1;


			int oldRow = players[i]->getRowNum();
			int oldBalance = players[i]->getWallet();
			myMove->oldRow = oldRow;
			myMove->oldBalance = oldBalance;

			//check if you are bankrupt
			if(players[i]->isBankrupt()){//you are bankrupt
				printf("Sorry, you are bankrupt... skipping turn\n");fflush(stdout);
				myMove->alreadyBankrupt = true;
			}

			else{//you are not bankrupt

				//roll the dice
				int roll = rollDice(1,8);//value from 1 to 8
				printf("Dice rolled %d\n", roll);
				myMove->diceRoll = roll;

				int newRow = oldRow + roll;
				myMove->newRow = newRow;
				players[i]->setRowNum(newRow);
				printf("Player %d is from %d now on %d\n", i, oldRow, newRow);

				//go to new location
				Cell* newLoc = board->getCell(newRow);
				//check what type it is

				if(newLoc->getType() == 4){// your are in rest
					//do nothing
					myMove->cellType = 4;
					printf("Piece landed on a free area\n");fflush(stdout);
				}

				else if(newLoc->getType() == 3){//you are in go
					myMove->cellType = 3;
					printf("Piece landed on GO\n");fflush(stdout);
				}

				else if(newLoc->getType() == 2){//you are in chance
					int chance = rollChance();
					myMove->cellType = 2;
					myMove->rolledChance = true;
					printf("Piece landed on chance\n");fflush(stdout);

					if(chance < 0){//you pay
						printf("You were unlucky and have to pay $%d\n", (-1)*chance);fflush(stdout);
						canPay(players[i], board, chance*(-1), myMove, &totalSoldProperty);
						totalCost += (-1)*chance;
						myMove->chanceAmt = (-1)*chance;
						if(myMove->wasBankrupt){
							printf("Piece became bankrupt\n");fflush(stdout);
						}
						else{
							printf("Transaction successful\n");fflush(stdout);
						}
					}
					else{//you gain
						printf("You were lucky and gained $%d\n", chance);fflush(stdout);
						players[i]->addToWallet(chance);//just add it
						myMove->isLucky = true;
						printf("Transaction successful\n");fflush(stdout);
						myMove->chanceAmt = chance;
					}
				}

				else if(newLoc->getType() == 1 || newLoc->getType() == 0){//you are on property
					myMove->cellType = newLoc->getType();

					printf("Piece landed on property\n");fflush(stdout);

					if(newLoc->getOwner() == -1){//you are on unowned property
						printf("Piece is on unowned property\n");fflush(stdout);
						if(newLoc->getBuyPrice() <= players[i]->getWallet()){//you have enough
							bool yes = players[i]->wantToBuy(newRow, board);//sets ownership, railroads, and player assets/wallet

							if(yes){
								printf("You bought this property\n");fflush(stdout);
								printf("Transaction successful\n");fflush(stdout);
								printf("Assets are now at %d and wallet is at %d\n", players[i]->getPropertyOwned(), players[i]->getWallet());
								myMove->madePurchase = true;
								totalCost += newLoc->getBuyPrice();
							}


						}
						else{//you don't have enough
							char x = 'x';
							printf("You do not have enough money. Do you want to sell property? Y/N: ");fflush(stdout);
							scanf(" %c", &x);

							if(x == 'Y'){
								canPay(players[i], board, newLoc->getBuyPrice(), myMove, &totalSoldProperty);//automatically pays

								if(myMove->wasBankrupt){// you became bankrupt
									//do nothing
									printf("You ended up in bankruptcy\n");fflush(stdout);
								}
								else{
									myMove->madePurchase = true;
									newLoc->setOwner(i);
									int propertyOwned = players[i]->getPropertyOwned() + newLoc->getBuyPrice();//sets ne assets
									players[i]->setPropertyOwned(propertyOwned);//renew
									if(newLoc->getType() == 1){//it is a railroad
										int numRR = players[i]->getNumRailroads();
										players[i]->setNumRailroads(numRR++);
									}
									printf("Retrying payment transaction for property...\n");fflush(stdout);
									printf("Transaction successful\n");fflush(stdout);
									printf("Assets are now at %d and wallet is at %d\n", players[i]->getPropertyOwned(), players[i]->getWallet());
									totalCost += newLoc->getBuyPrice();
								}
							}
							else{
								//do nothing
							}
						}

					}
					else{//you are on owned property
						if(i == newLoc->getOwner()){//you own it
							printf("Piece landed on a owned property\n");fflush(stdout);
							//do nothing
						}
						else{//you are on someone else's property
							printf("Piece landed on on player %d's property\n", newLoc->getOwner());fflush(stdout);
							int rent = newLoc->getRentPrice(players);
							printf("Piece has to pay $%d\n", rent);fflush(stdout);
							if(rent <= players[i]->getWallet()){//you have enough
								players[i]->takeFromWallet(rent);//made payment
								PlayerPiece* owner = newLoc->findPlayer(newLoc->getOwner(), players);
								owner->addToWallet(rent);//transaction complete
								printf("Transaction successful\n");fflush(stdout);
								printf("Assets are now at %d and wallet is at %d\n", players[i]->getPropertyOwned(), players[i]->getWallet());
								totalCost += rent;
								myMove->propertyIsOwned = true;
								myMove->rentAmt = rent;
							}
							else{//you don't have enough
								canPay(players[i],board,rent,myMove,&totalSoldProperty);//automatically takes away
								if(myMove->wasBankrupt){
									//don't do anything
									printf("You ended up in bankruptcy\n");fflush(stdout);
								}
								else{
									PlayerPiece* owner = newLoc->findPlayer(newLoc->getOwner(), players);
									owner->addToWallet(rent);//transaction complete
									printf("Retrying payment transaction for property...\n");fflush(stdout);
									printf("Transaction successful\n");fflush(stdout);
									printf("Assets are now at %d and wallet is at %d\n", players[i]->getPropertyOwned(), players[i]->getWallet());
									totalCost += rent;
									myMove->propertyIsOwned = true;
									myMove->rentAmt = rent;
								}
							}
						}
					}
				}

				//do you want to upgrade?
				char ans = 'x';

				printf("Do you want to upgrade any of your properties?\n");fflush(stdout);
				printf("Y/N: ");fflush(stdout);
				scanf(" %c", &ans);

				//check if you have enough money: sell property


				if(ans == 'Y'){//yes then upgrade
					//check if you have enough money
					if(players[i]->getWallet() >= 30){
						myMove->madeUpgrade = true;
						int housesBought = -1;
						players[i]->upgradeProperty(board, &housesBought);//this sets the new numHouses
						myMove->housesBought = housesBought;
						players[i]->takeFromWallet(housesBought*30);
						totalCost += housesBought*30;
						printf("Transaction successful\n");fflush(stdout);
						printf("Assets are now at %d and wallet is at %d\n", players[i]->getPropertyOwned(), players[i]->getWallet());
					}
					else{
						printf("Sorry you cannot afford it\n");fflush(stdout);
						//not enough money
						//don't do anything
					}

				}
				else{
					//don't do anything
				}

				//upgrade done

				//did you pass go?
				if(players[i]->passedGo(myMove)){
					myMove->passedGo = true;
					players[i]->addToWallet(200);
					printf("Piece passed GO\n");fflush(stdout);
					printf("Assets are now at %d and wallet is at %d\n", players[i]->getPropertyOwned(), players[i]->getWallet());
				}

				myMove->newBalance = players[i]->getWallet();
				myMove->propertySoldAmount = totalSoldProperty;
				myMove->cost = totalCost;

			}
			myLL->savePayload(myMove);
			board->displayBoard();
			displayHoldings(players, nPlayers);
		}

		while(!done){//game start after the first round

			for(int i = 0; i < nPlayers; i++){
				printf("Player %d's turn\n",i);fflush(stdout);
				rollNumberAccum++;
				int totalSoldProperty = 0;
				int totalCost = 0;
				Move* myMove = (Move*)malloc(sizeof(Move));
				myMove->playerNum = i;
				myMove->MoveNum = rollNumberAccum;
				myMove->cellType = -1;
				myMove->diceRoll = -1;
				myMove->housesBought = 0;
				myMove->madePurchase = false;
				myMove->madeUpgrade = false;
				myMove->newBalance = -1;
				myMove->newRow = -1;
				myMove->oldBalance = -1;
				myMove->oldRow = -1;
				myMove->passedGo = false;
				myMove->propertySoldAmount = -1;
				myMove->rolledChance = false;
				myMove->isLucky = false;
				myMove->soldProperty = false;
				myMove->wasBankrupt = false;//became bankrupt in the middle of the game
				myMove->alreadyBankrupt = false;//is already bankrupt before this turn
				myMove->propertyIsOwned = false;//if you land on another player's cell
				myMove->chanceAmt = -1;
				myMove->rentAmt = -1;

				int oldRow = players[i]->getRowNum();
				int oldBalance = players[i]->getWallet();
				myMove->oldRow = oldRow;
				myMove->oldBalance = oldBalance;

				//check if you are bankrupt
				if(players[i]->isBankrupt()){//you are bankrupt
					printf("Sorry, you are bankrupt... skipping turn\n");fflush(stdout);
					myMove->alreadyBankrupt = true;
				}

				else{//you are not bankrupt

					//roll the dice
					int roll = rollDice(1,8);//value from 1 to 8
					printf("Dice rolled %d\n", roll);
					myMove->diceRoll = roll;

					int newRow = oldRow + roll;
					myMove->newRow = newRow;
					players[i]->setRowNum(newRow);
					printf("Player %d is from %d now on %d\n", i, oldRow, newRow);

					//go to new location
					Cell* newLoc = board->getCell(newRow);
					//check what type it is

					if(newLoc->getType() == 4){// your are in rest
						//do nothing
						myMove->cellType = 4;
						printf("Piece landed on a free area\n");fflush(stdout);
					}

					else if(newLoc->getType() == 3){//you are in go
						myMove->cellType = 3;
						printf("Piece landed on GO\n");fflush(stdout);
					}

					else if(newLoc->getType() == 2){//you are in chance
						int chance = rollChance();
						myMove->cellType = 2;
						myMove->rolledChance = true;
						printf("Piece landed on chance\n");fflush(stdout);

						if(chance < 0){//you pay
							printf("You were unlucky and have to pay $%d\n", (-1)*chance);fflush(stdout);
							canPay(players[i], board, chance*(-1), myMove, &totalSoldProperty);
							totalCost += (-1)*chance;
							myMove->chanceAmt = (-1)*chance;
							if(myMove->wasBankrupt){
								printf("Piece became bankrupt\n");fflush(stdout);
							}
							else{
								printf("Transaction successful\n");fflush(stdout);
							}
						}
						else{//you gain
							printf("You were lucky and gained $%d\n", chance);fflush(stdout);
							players[i]->addToWallet(chance);//just add it
							myMove->isLucky = true;
							printf("Transaction successful\n");fflush(stdout);
							myMove->chanceAmt = chance;
						}
					}

					else if(newLoc->getType() == 1 || newLoc->getType() == 0){//you are on property
						myMove->cellType = newLoc->getType();

						printf("Piece landed on property\n");fflush(stdout);

						if(newLoc->getOwner() == -1){//you are on unowned property
							printf("Piece is on unowned property\n");fflush(stdout);
							if(newLoc->getBuyPrice() <= players[i]->getWallet()){//you have enough
								bool yes = players[i]->wantToBuy(newRow, board);//sets ownership, railroads, and player assets/wallet

								if(yes){
									printf("You bought this property\n");fflush(stdout);
									printf("Transaction successful\n");fflush(stdout);
									printf("Assets are now at %d and wallet is at %d\n", players[i]->getPropertyOwned(), players[i]->getWallet());
									myMove->madePurchase = true;
									totalCost += newLoc->getBuyPrice();
								}


							}
							else{//you don't have enough
								char x = 'x';
								printf("You do not have enough money. Do you want to sell property? Y/N: ");fflush(stdout);
								scanf(" %c", &x);

								if(x == 'Y'){
									canPay(players[i], board, newLoc->getBuyPrice(), myMove, &totalSoldProperty);//automatically pays

									if(myMove->wasBankrupt){// you became bankrupt
										//do nothing
										printf("You ended up in bankruptcy\n");fflush(stdout);
									}
									else{
										myMove->madePurchase = true;
										newLoc->setOwner(i);
										int propertyOwned = players[i]->getPropertyOwned() + newLoc->getBuyPrice();//sets ne assets
										players[i]->setPropertyOwned(propertyOwned);//renew
										if(newLoc->getType() == 1){//it is a railroad
											int numRR = players[i]->getNumRailroads();
											players[i]->setNumRailroads(numRR++);
										}
										printf("Retrying payment transaction for property...\n");fflush(stdout);
										printf("Transaction successful\n");fflush(stdout);
										printf("Assets are now at %d and wallet is at %d\n", players[i]->getPropertyOwned(), players[i]->getWallet());
										totalCost += newLoc->getBuyPrice();
									}
								}
								else{
									//do nothing
								}
							}

						}
						else{//you are on owned property
							if(i == newLoc->getOwner()){//you own it
								printf("Piece landed on a owned property\n");fflush(stdout);
								//do nothing
							}
							else{//you are on someone else's property
								printf("Piece landed on on player %d's property\n", newLoc->getOwner());fflush(stdout);
								int rent = newLoc->getRentPrice(players);
								printf("Piece has to pay $%d\n", rent);fflush(stdout);
								if(rent <= players[i]->getWallet()){//you have enough
									players[i]->takeFromWallet(rent);//made payment
									PlayerPiece* owner = newLoc->findPlayer(newLoc->getOwner(), players);
									owner->addToWallet(rent);//transaction complete
									printf("Transaction successful\n");fflush(stdout);
									printf("Assets are now at %d and wallet is at %d\n", players[i]->getPropertyOwned(), players[i]->getWallet());
									totalCost += rent;
									myMove->propertyIsOwned = true;
									myMove->rentAmt = rent;
								}
								else{//you don't have enough
									canPay(players[i],board,rent,myMove,&totalSoldProperty);//automatically takes away
									if(myMove->wasBankrupt){
										//don't do anything
										printf("You ended up in bankruptcy\n");fflush(stdout);
									}
									else{
										PlayerPiece* owner = newLoc->findPlayer(newLoc->getOwner(), players);
										owner->addToWallet(rent);//transaction complete
										printf("Retrying payment transaction for property...\n");fflush(stdout);
										printf("Transaction successful\n");fflush(stdout);
										printf("Assets are now at %d and wallet is at %d\n", players[i]->getPropertyOwned(), players[i]->getWallet());
										totalCost += rent;
										myMove->propertyIsOwned = true;
										myMove->rentAmt = rent;
									}
								}
							}
						}
					}

					//do you want to upgrade?
					char ans = 'x';

					printf("Do you want to upgrade any of your properties?\n");fflush(stdout);
					printf("Y/N: ");fflush(stdout);
					scanf(" %c", &ans);

					//check if you have enough money: sell property


					if(ans == 'Y'){//yes then upgrade
						//check if you have enough money
						if(players[i]->getWallet() >= 30){
							myMove->madeUpgrade = true;
							int housesBought = -1;
							players[i]->upgradeProperty(board, &housesBought);//this sets the new numHouses
							myMove->housesBought = housesBought;
							totalCost += housesBought*30;
							players[i]->takeFromWallet(housesBought*30);
							printf("Transaction successful\n");fflush(stdout);
							printf("Assets are now at %d and wallet is at %d\n", players[i]->getPropertyOwned(), players[i]->getWallet());
						}
						else{
							printf("Sorry you cannot afford it\n");fflush(stdout);
							//not enough money
							//don't do anything
						}

					}
					else{
						//don't do anything
					}

					//upgrade done

					//did you pass go?
					if(players[i]->passedGo(myMove)){
						myMove->passedGo = true;
						players[i]->addToWallet(200);
						printf("Piece passed GO\n");fflush(stdout);
						printf("Assets are now at %d and wallet is at %d\n", players[i]->getPropertyOwned(), players[i]->getWallet());
					}

					myMove->newBalance = players[i]->getWallet();
					myMove->propertySoldAmount = totalSoldProperty;
					myMove->cost = totalCost;

				}
				myLL->savePayload(myMove);
				board->displayBoard();
				displayHoldings(players, nPlayers);

				if(rollNumberAccum == maxRolls){
					done = true;
					printf("Game has stopped by max rolls\n");fflush(stdout);
				}

				int notBankruptAccum = 0;
				for(int i = 0; i < nPlayers; i++){
					if(!players[i]->isBankrupt()){
						notBankruptAccum++;
					}
				}
				if(notBankruptAccum == 1){//game is won
					done = true;
					printf("Game has stopped with winner\n");fflush(stdout);
				}

			}

		}

		FILE* fp = fopen("MonopolyLogFile.txt","w");
		myLL->printMoveListInFile(fp);
		fclose(fp);

	}
	return answer;
}

bool Production::readFile(char* filename, int* numPlayers, Board* board, PlayerPiece** players)
{
	bool ok = false;
	//the file tells how many players there are
	FILE* fp = fopen(filename, "r"); //read the file

	if (fp == NULL)
	{
		puts("Error! opening file");

	}
	else
	{
		fscanf(fp,"%d", numPlayers);
		board->setCellP((Cell**) malloc(32*sizeof(Cell*)));
		puts("Before initializing board"); fflush(stdout);
		board->initializeBoard();
		puts("After initializing"); fflush(stdout);
		int tempLocation = -1;
		int tempWallet = -1;
		int tempProperty = -1;
		int tempNumHouses = -1;

		for(int playerr = 0; playerr < *numPlayers; playerr++)
		{

			fscanf(fp,"%d", &tempLocation);
			//make a player and set values
			PlayerPiece** aPlayerP = players;
			aPlayerP = aPlayerP+playerr;
			*aPlayerP = (PlayerPiece*) malloc(sizeof(PlayerPiece));

			(*aPlayerP)->setPlayerNum(playerr);
			(*aPlayerP)->setRowNum(tempLocation);

			fscanf(fp, "%d", &tempWallet);
			(*aPlayerP)->setWallet(tempWallet);

			printf("The player %d has %d\n", playerr, tempWallet);

			printf("Properties are:\n");

			int railroadAccum = 1;
			int assetValue = 0;
			bool done = false;
			while(!done){
				fscanf(fp, "%d", &tempProperty);
				if(tempProperty == -1){//we go to the next player
					done = true;
				}
				else{
					fscanf(fp, "%d", &tempNumHouses);
					Cell* tempCell = board->getCell(tempProperty);

					tempCell->setOwner(playerr);
					tempCell->setNumHouses(tempNumHouses);

					if(tempCell->getType() == 1){
						(*aPlayerP)->setNumRailroads(railroadAccum);
						railroadAccum++;
					}

					assetValue = assetValue + tempCell->getBuyPrice() + 30*tempNumHouses;

				}
			}
			(*aPlayerP)->setPropertyOwned(assetValue);

			printf("%d railroads owned\n", (*aPlayerP)->getNumRailroads());


		}
		ok = true;
	}
	fclose(fp);

	return ok;
}

int Production::rollDice(int lowest, int highest){
	int num = -1;
	int num2 = -1;

	if(lowest == 0){
		num =  rand() % (highest++);
	}
	if(lowest > 0){
		num = rand()%(highest++);
		num2 = rand()%(lowest++);
		if(num < lowest){
			num = num + num2;
		}
		else{
			//do nothing
		}
	}

	return num;
}

int Production::rollChance(){
	int i = -1;

	int num1 = rollDice(0,1);//if 0 then it means its pay, if its 1 then its not pay

	if(num1 == 0){
		i = rollDice(1, 6);
		i = (-1)*10*i;
	}
	else{
		i = rollDice(1,6);
		i = i*10;
	}

	return i;
}


void Production::displayHoldings(PlayerPiece** players, int numPlayers){

	for(int i = 0; i < numPlayers; i++)
	{

		PlayerPiece** temp = players + i;
		int playerNum = (*temp)->getPlayerNum();
		int wallet = (*temp)->getWallet();
		int assets = (*temp)->getPropertyOwned();

		printf("Player %d has $%d in wallet and $%d in assets\n", playerNum, wallet, assets);fflush(stdout);
	}
}

//this function checks if you can pay and will set you to bankrupt if you can't pay a given amount
void Production::canPay(PlayerPiece* player, Board* board, int amount, Move* myMove, int* totalSoldProperty){
	bool enough = false;
	while(!enough){
		enough = player->checkEnoughMoney(amount);
		if(enough){
			player->takeFromWallet(amount);
		}
		else{
			bool isBankrupt = player->isBankrupt();

			if(isBankrupt){
				//stop the turn
				myMove->wasBankrupt = true;
				enough = true;//to end the loop
			}
			else{

				if(player->getPropertyOwned() <= 20){
					player->setPropertyOwned(0);//basically you can't do anything if you sell your only $20 property
				}
				else{
					bool soldRailroad = false;
					int amount1 = board->sellProperty(player->getPlayerNum(), &soldRailroad);
					myMove->soldProperty = true;
					*totalSoldProperty = *totalSoldProperty + amount1;

					player->addToWallet(amount1);//add it to our wallet
					player->addPropertyOwned(-2*amount1);//reduce our property owned

					if(soldRailroad){
						int railRoads = player->getNumRailroads();
						player->setNumRailroads(railRoads - 1);
					}
					printf("Sold successfully\n");fflush(stdout);
				}


			}
			//will ask if its enough still
		}
	}
}
