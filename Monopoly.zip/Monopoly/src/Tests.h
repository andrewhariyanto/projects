/*
 * Tests.h
 *
 *  Created on: Mar 19, 2021
 *      Author: Andrew Hariyanto
 */

#ifndef TESTS_H_
#define TESTS_H_
#include "Production.h"
#include "PlayerPiece.h"
#include "Cell.h"
#include "Board.h"
#include "LList.h"


class Tests {
public:
	Tests();
	virtual ~Tests();
	bool tests();

private:

	bool testGetCell();
	bool testSetGetCellP();
	bool testSetGetType();
	bool testSetGetRowNumCell();
	bool testSetGetOwner();
	bool testSetGetNumHouses();
	bool testSetGetPlayerNum();
	bool testSetGetRowNumPlayer();
	bool testSetGetWallet();
	bool testSetGetPropertyOwned();
	bool testIsBankrupt();
	bool testSetGetNumRailroad();

	bool testFindPlayer();
	bool testGetBuyPrice();
	bool testGetRentPrice();
	bool testSellProperty();

	bool testPassedGo();
	bool testAddToWallet();
	bool testTakeFromWallet();
	bool testAddPropertyOwned();
	bool testCheckEnoughMoney();

	bool testRollDice();
	bool testRollChance();

	bool testGetMoveList();
	bool testIsEmpty();
	bool testEnqueue();
	bool testMakeLList();
	bool testPrintMoveListInFile();

	bool testInitAndDisplayBoard();
	bool testDisplayHoldings();
	bool testUpdateBoard();

	bool testReadFile();
	bool testOutputFile();

	bool testWantToBuy();
	bool testUpgradeProperty();

};

#endif /* TESTS_H_ */
