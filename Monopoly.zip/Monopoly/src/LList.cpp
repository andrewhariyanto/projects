/*
 * LList.cpp
 *
 *  Created on: Mar 19, 2021
 *      Author: Andrew Hariyanto
 */

#include "LList.h"
#include <stdlib.h>

LList::LList() {
	// TODO Auto-generated constructor stub
	lp=makeEmptyLinkedList();

}

LList::~LList() {
	// TODO Auto-generated destructor stub
}

bool LList::isEmpty()
{
	bool ans = false;
	if(lp->payP == (Payload*)0)
	{
		ans = true;
	}
	return ans;
}

LLNode* LList::makeEmptyLinkedList()
{
	LLNode* lp = (LLNode*) malloc(sizeof(LLNode));
	lp->next = (struct LLNode*)0;
	lp->prev = (struct LLNode*)0;
	lp->payP = (Payload*)0;

	return lp;
}

void LList::savePayload(Payload* mp)
{
	//if the list is empty, then make payP be mp
	//else traverse the list,
	//make a new list element
	//put mp in that
	//attach the new list element to the existing list
	if(isEmpty())
	{
		lp->payP = mp;
	}
	else
	{
		LLNode* temp = lp;
		while(temp->next)
		{
			temp=(LLNode*)temp->next;
		}
		//now temp points to the last element

		//make a new element, attach mp to it, wire up the new element
		LLNode* newList = makeEmptyLinkedList();
		newList->payP = mp;
		temp->next = (struct LLNode*)newList;
		newList->prev = (struct LLNode*) temp;
	}
}


void LList::printMoveListInFile(FILE* fp){
	LLNode* temp = lp;

	while(temp->next){
		Move* move = (Move*)malloc(sizeof(Move));
		move = temp->payP;
		fprintf(fp, "This is dice roll %d:\n", move->MoveNum);fflush(fp);

		if(move->alreadyBankrupt){
			fprintf(fp, "Player %d is already bankrupt... turn is skipped\n", move->playerNum);fflush(fp);
		}
		else{
			fprintf(fp, "Player %d's turn\n",move->playerNum);fflush(fp);
			fprintf(fp, "Player %d rolled %d\n", move->playerNum, move->diceRoll);fflush(fp);

			if(move->cellType == 4){
				fprintf(fp, "Player %d moved from row %d to row %d onto free cell\n", move->playerNum, move->oldRow, move->newRow);fflush(fp);
			}
			else if(move->cellType == 3){
				fprintf(fp, "Player %d moved from row %d to row %d onto GO\n", move->playerNum, move->oldRow, move->newRow);fflush(fp);
			}
			else if(move->cellType == 2){
				fprintf(fp, "Player %d moved from row %d to row %d onto chance\n", move->playerNum, move->oldRow, move->newRow);fflush(fp);
				if(move->isLucky){
					fprintf(fp,"Player was lucky and gain $%d\n", move->chanceAmt);
				}
				else{
					fprintf(fp,"Player was unlucky and lost $%d\n", move->chanceAmt);
				}

			}
			else if(move->cellType == 1){
				fprintf(fp, "Player %d moved from row %d to row %d onto railroad\n", move->playerNum, move->oldRow, move->newRow);fflush(fp);
			}
			else{
				fprintf(fp, "Player %d moved from row %d to row %d onto street\n", move->playerNum, move->oldRow, move->newRow);fflush(fp);
				if(move->propertyIsOwned){
					fprintf(fp,"Player was on another player's property and paid $%d\n", move->rentAmt);fflush(fp);
				}
				else if(move->madePurchase){
					fprintf(fp, "At new location, player %d bought the property\n", move->playerNum);fflush(fp);
				}
				else{
					fprintf(fp, "Player landed on owned property\n");fflush(fp);
				}
			}

			if(move->madeUpgrade){
				fprintf(fp, "Player %d made an upgrade and bought %d houses\n",move->playerNum, move->housesBought);fflush(fp);
			}

			if(move->soldProperty){
				fprintf(fp, "Player %d sold property for $%d\n", move->playerNum, move->propertySoldAmount);fflush(fp);
			}

			if(move->passedGo){
				fprintf(fp, "Player %d passed go and earned $200\n", move->playerNum);fflush(fp);
			}


			fprintf(fp, "Total costs for player %d is $%d\n", move->playerNum, move->cost);fflush(fp);
			fprintf(fp, "Balance was $%d and now is $%d\n", move->oldBalance, move->newBalance);fflush(fp);

			if(move->wasBankrupt){
				fprintf(fp, "Player %d is now bankrupt\n", move->playerNum);fflush(fp);
			}
			fprintf(fp, "\n");fflush(fp);
		}
		temp = temp->next;
	}//at the end
	Move* move = (Move*)malloc(sizeof(Move));
	move = temp->payP;
	fprintf(fp, "This is dice roll %d:\n", move->MoveNum);fflush(fp);

	if(move->alreadyBankrupt){
		fprintf(fp, "Player %d is already bankrupt... turn is skipped\n", move->playerNum);fflush(fp);
	}
	else{
		fprintf(fp, "Player %d's turn\n",move->playerNum);fflush(fp);
		fprintf(fp, "Player %d rolled %d\n", move->playerNum, move->diceRoll);fflush(fp);

		if(move->cellType == 4){
			fprintf(fp, "Player %d moved from row %d to row %d onto free cell\n", move->playerNum, move->oldRow, move->newRow);fflush(fp);
		}
		else if(move->cellType == 3){
			fprintf(fp, "Player %d moved from row %d to row %d onto GO\n", move->playerNum, move->oldRow, move->newRow);fflush(fp);
		}
		else if(move->cellType == 2){
			fprintf(fp, "Player %d moved from row %d to row %d onto chance\n", move->playerNum, move->oldRow, move->newRow);fflush(fp);
			if(move->isLucky){
				fprintf(fp,"Player was lucky and gain $%d\n", move->chanceAmt);
			}
			else{
				fprintf(fp,"Player was unlucky and lost $%d\n", move->chanceAmt);
			}

		}
		else if(move->cellType == 1){
			fprintf(fp, "Player %d moved from row %d to row %d onto railroad\n", move->playerNum, move->oldRow, move->newRow);fflush(fp);
		}
		else{
			fprintf(fp, "Player %d moved from row %d to row %d onto street\n", move->playerNum, move->oldRow, move->newRow);fflush(fp);
			if(move->propertyIsOwned){
				fprintf(fp,"Player was on another player's property and paid $%d\n", move->rentAmt);fflush(fp);
			}
			else if(move->madePurchase){
				fprintf(fp, "At new location, player %d bought the property\n", move->playerNum);fflush(fp);
			}
			else{
				fprintf(fp, "Player landed on owned property\n");fflush(fp);
			}
		}

		if(move->madeUpgrade){
			fprintf(fp, "Player %d made an upgrade and bought %d houses\n",move->playerNum, move->housesBought);fflush(fp);
		}

		if(move->soldProperty){
			fprintf(fp, "Player %d sold property for $%d\n", move->playerNum, move->propertySoldAmount);fflush(fp);
		}

		if(move->passedGo){
			fprintf(fp, "Player %d passed go and earned $200\n", move->playerNum);fflush(fp);
		}


		fprintf(fp, "Total costs for player %d is $%d\n", move->playerNum, move->cost);fflush(fp);
		fprintf(fp, "Balance was $%d and now is $%d\n", move->oldBalance, move->newBalance);fflush(fp);

		if(move->wasBankrupt){
			fprintf(fp, "Player %d is now bankrupt\n", move->playerNum);fflush(fp);
		}
		fprintf(fp, "\n");fflush(fp);
	}
}

LLNode* LList::getMoveList(){
	return lp;
}
