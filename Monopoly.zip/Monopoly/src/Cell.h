/*
 * Cell.h
 *
 *  Created on: Mar 19, 2021
 *      Author: Andrew Hariyanto
 */

#ifndef CELL_H_
#define CELL_H_
#include "PlayerPiece.h"

class Cell {
public:
	Cell();
	virtual ~Cell();
	void setRowNum(int);
	int getRowNum();
	void setType(int);
	int getType();
	void setOwner(int);
	int getOwner();
	void setNumHouses(int);
	int getNumHouses();

	PlayerPiece* findPlayer(int, PlayerPiece**);
	int getBuyPrice();
	int getRentPrice(PlayerPiece**);


private:
	int rowNum;
	int ownedBy;//using player num; if no one owns set to -1
	int numHouses;
	bool isStreet;
	bool isRailroad;
	bool isChance;
	bool isGo;
	bool isRest;

	//types:
	//street = 0
	//railroad = 1
	//chance = 2
	//go = 3
	//rest = 4

};

#endif /* CELL_H_ */
