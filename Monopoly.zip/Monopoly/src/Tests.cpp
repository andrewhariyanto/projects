/*
 * Tests.cpp
 *
 *  Created on: Mar 19, 2021
 *      Author: Andrew Hariyanto
 */

#include "Tests.h"
#include <stdbool.h>

Tests::Tests() {
	// TODO Auto-generated constructor stub

}

Tests::~Tests() {
	// TODO Auto-generated destructor stub
}

bool Tests::tests()
{
	bool answer = true;


	bool ok32 = testSetGetRowNumCell();
	bool ok3 = testSetGetType();
	bool ok4 = testSetGetOwner();
	bool ok5 = testSetGetNumHouses();
	bool ok1 = testGetCell();
	bool ok6 = testSetGetPlayerNum();
	bool ok7 = testSetGetRowNumPlayer();
	bool ok8 = testSetGetWallet();
	bool ok9 = testSetGetPropertyOwned();
	bool ok10 = testIsBankrupt();
	bool ok33 = testSetGetNumRailroad();

	bool ok2 = testSetGetCellP();
	bool ok25 = testInitAndDisplayBoard();

	bool ok34 = testFindPlayer();
	bool ok11 = testGetBuyPrice();
	bool ok12 = testGetRentPrice();
	//bool ok13 = testSellProperty(); commented out so I don't have to input the tests again

	bool ok14 = testPassedGo();
	bool ok15 = testAddToWallet();
	bool ok16 = testTakeFromWallet();
	bool ok17 = testAddPropertyOwned();
	bool ok18 = testCheckEnoughMoney();

	bool ok19 = testRollDice();
	bool ok20 = testRollChance();


	bool ok21 = testIsEmpty();
	bool ok22 = testEnqueue();
	bool ok23 = testMakeLList();
	bool ok35 = testGetMoveList();
	bool ok24 = testPrintMoveListInFile();

	//bool ok30 = testWantToBuy();
	//bool ok31 = testUpgradeProperty();
	bool ok26 = testDisplayHoldings();

	bool ok28 = testReadFile();


	answer = ok1 && ok2 && ok3 && ok33 && ok4 && ok5 && ok6 && ok7 && ok8 && ok9 && ok10 && ok11 && ok12 /*&& ok13*/ && ok14 && ok15 && ok16
			&& ok17 && ok18 && ok19 && ok20 && ok21 && ok22 && ok23 && ok24 && ok25 && ok26 && ok28 /*&& ok30 && ok31*/
			&& ok32 && ok34 && ok35;
	return answer;
}

bool Tests::testReadFile()
{
	puts("starting testReadFile"); fflush(stdout);
	bool ok = false;
	//the file tells how many rooms there are
	int answer = -1;
	int rightAnswer = 3;


	Board* board = new Board();
	PlayerPiece* players[10];//addresses for 10 players

	Production* pP = new Production();

	ok = pP->readFile("monopolyConfig.txt", &answer, board, players); //read the file
	if(ok)
	{
		if(answer!=rightAnswer)
		{
			puts("test failed on number of players");
		}

	}



	puts("The Players");
	for(int i = 0; i<answer; i++)
	{
		printf("Player %d\n on row %d with %d in wallet and %d in properties\n",
				i, players[i]->getRowNum(), players[i]->getWallet(), players[i]->getPropertyOwned());
	}

	ok = true;
	if(ok){
		puts("testReadFile passed");fflush(stdout);
	}
	else{
		puts("testReadFile did not pass");fflush(stdout);
	}

	board->displayBoard();
	return ok;
}

bool Tests::testGetCell(){
	bool ok = true;

	Board* board = new Board();
	board->setCellP((Cell**)malloc(32*sizeof(Cell*)));
	board->initializeBoard();

	int rightAns = 1;

	Cell* cell = board->getCell(1);

	if(rightAns != cell->getRowNum()){
		ok = false;
		puts("testGetCell did not pass");fflush(stdout);
	}
	else{
		puts("testGetCell passed");fflush(stdout);
	}

	delete board;
	return ok;
}

bool Tests::testSetGetCellP(){
	bool ok = true;

	Board* board = new Board();
	Cell** size = (Cell**)malloc(32*sizeof(Cell*));
	board->setCellP(size);

	if(size != board->getCellP()){
		ok = false;
		puts("testSetGetCellP did not pass");fflush(stdout);
	}
	else{
		puts("testSeGetCellP passed");fflush(stdout);
	}

	delete board;
	return ok;
}

bool Tests::testSetGetType(){
	bool ok = true;

	Cell* cell = new Cell();

	cell->setType(1);//railroad
	int rightAns = 1;

	if(cell->getType() != rightAns){
		ok = false;
		puts("testSetGetType did not pass");fflush(stdout);
	}
	else{
		puts("testSetGetType passed");fflush(stdout);
	}

	delete cell;
	return ok;
}

bool Tests::testSetGetRowNumCell(){
	bool ok = true;

	Cell* cell = new Cell();

	cell->setRowNum(1);//railroad
	int rightAns = 1;

	if(cell->getRowNum() != rightAns){
		ok = false;
		puts("testSetGetRowNumCell did not pass");fflush(stdout);
	}
	else{
		puts("testSetGetRowNumCell passed");fflush(stdout);
	}

	delete cell;
	return ok;
}

bool Tests::testSetGetOwner(){
	bool ok = true;

	Cell* cell = new Cell();

	cell->setOwner(1);//player1
	int rightAns = 1;

	if(cell->getOwner() != rightAns){
		ok = false;
		puts("testSetGetOwner did not pass");fflush(stdout);
	}
	else{
		puts("testSetGetOwner passed");fflush(stdout);
	}

	delete cell;

	return ok;
}

bool Tests::testSetGetNumHouses(){
	bool ok = true;

	Cell* cell = new Cell();

	cell->setNumHouses(1);
	int rightAns = 1;

	if(cell->getNumHouses() != rightAns){
		ok = false;
		puts("testSetGetNumHouses did not pass");fflush(stdout);
	}
	else{
		puts("testSetGetNumHouses passed");fflush(stdout);
	}

	delete cell;

	return ok;
}

bool Tests::testSetGetPlayerNum(){
	bool ok = true;

	PlayerPiece* p1 = new PlayerPiece();

	p1->setPlayerNum(0);//player 0
	int rightAns = 0;

	if(p1->getPlayerNum() != rightAns){
		ok = false;
		puts("testSetGetPlayerNum did not pass");fflush(stdout);
	}
	else{
		puts("testSetGetPlayerNum passed");fflush(stdout);
	}

	delete p1;
	return ok;
}

bool Tests::testSetGetRowNumPlayer(){
	bool ok = true;

	PlayerPiece* p1 = new PlayerPiece();

	p1->setPlayerNum(1);
	int rightAns = 1;

	if(p1->getPlayerNum() != rightAns){
		ok = false;
		puts("testSetGetRowNumPlayer did not pass");fflush(stdout);
	}
	else{
		puts("testSetGetRowNumPlayer passed");fflush(stdout);
	}

	delete p1;
	return ok;
}

bool Tests::testSetGetWallet(){
	bool ok = true;

	PlayerPiece* p1 = new PlayerPiece();

	p1->setWallet(20);
	int rightAns = 20;

	if(p1->getWallet() != rightAns){
		ok = false;
		puts("testSetGetWallet did not pass");fflush(stdout);
	}
	else{
		puts("testSetGetWallet passed");fflush(stdout);
	}

	delete p1;
	return ok;
}

bool Tests::testSetGetPropertyOwned(){
	bool ok = true;

	PlayerPiece* p1 = new PlayerPiece();

	p1->setPropertyOwned(20);
	int rightAns = 20;

	if(p1->getPropertyOwned() != rightAns){
		ok = false;
		puts("testSetGetProperyOwned did not pass");fflush(stdout);
	}
	else{
		puts("testSetGetPropertyOwned passed");fflush(stdout);
	}

	delete p1;
	return ok;
}

bool Tests::testIsBankrupt(){
	bool ok = true;

	PlayerPiece* p1 = new PlayerPiece();
	p1->setWallet(-1);
	p1->setPropertyOwned(0);


	bool ans = p1->isBankrupt();
	bool rightAns = true;

	if(ans != rightAns){
		ok = false;
		puts("testIsBankrupt did not pass");fflush(stdout);
	}
	else{
		puts("testIsBankrupt passed");fflush(stdout);
	}

	delete p1;
	return ok;
}

bool Tests::testSetGetNumRailroad(){
	bool ok = true;

	PlayerPiece* p1 = new PlayerPiece();

	p1->setNumRailroads(1);
	int rightAns = 1;

	if(p1->getNumRailroads() != rightAns){
		ok = false;
		puts("testSetgetNumRailroad did not pass");fflush(stdout);
	}
	else{
		puts("testSetGetNumRailroad passed");fflush(stdout);
	}

	delete p1;
	return ok;
}

bool Tests::testFindPlayer(){
	bool ok = true;
	Cell* cell = new Cell();

	PlayerPiece* players[2];
	players[0] = (PlayerPiece*)malloc(sizeof(PlayerPiece));
	players[1] = (PlayerPiece*)malloc(sizeof(PlayerPiece));
	players[0]->setPlayerNum(0);
	players[1]->setPlayerNum(1);


	PlayerPiece* temp = cell->findPlayer(0, players);

	int rightAns = 0;

	if(temp->getPlayerNum() != rightAns){
		ok = false;
		puts("testFindPlayer did not pass");fflush(stdout);
	}
	else{
		puts("testFindPlayer passed");fflush(stdout);
	}

	delete cell;
	return ok;
}

bool Tests::testGetBuyPrice(){
	bool ok = true;

	Cell* cell = new Cell();
	cell->setRowNum(9);//cost for this street is 40
	cell->setType(0);//street

	int ans = cell->getBuyPrice();
	int rightAns = 40;

	//test case 1: street

	if(ans != rightAns){
		ok = false;
		puts("testGetBuyPrice did not pass test case 1");fflush(stdout);
	}
	else{
		puts("testGetBuyPrice passed test case 1");fflush(stdout);
	}

	//test case 2: railroad
	cell->setType(1);
	ans = cell->getBuyPrice();
	rightAns = 100;

	if(ans != rightAns){
		ok = false;
		puts("testGetBuyPrice did not pass test case 2");fflush(stdout);
	}
	else{
		puts("testGetBuyPrice passed test case 2");fflush(stdout);
	}

	delete cell;
	return ok;
}

bool Tests::testGetRentPrice(){
	bool ok = true;

	Cell* cell = new Cell();
	PlayerPiece* players[1];
	players[0]->setNumRailroads(2);

	cell->setRowNum(9);
	cell->setType(0);//street
	cell->setNumHouses(2);//rent is 30 for two houses

	int ans = cell->getRentPrice(players);

	int rightAns = 30;

	if(ans != rightAns){
		ok = false;
		puts("testGetRentPrice did not pass test case 1");fflush(stdout);
	}
	else{
		puts("testGetRentPrice passed test case 1");fflush(stdout);
	}

	//test case 2: railroad
	cell->setType(1);
	cell->setOwner(0);

	ans = cell->getRentPrice(players);
	rightAns = 50;

	if(ans != rightAns){
		ok = false;
		puts("testGetRentPrice did not pass test case 2");fflush(stdout);
	}
	else{
		puts("testGetRentPrice passed test case 2");fflush(stdout);
	}

	delete cell;
	return ok;
}

bool Tests::testSellProperty(){
	bool ok = true;

	Board* board= new Board();
	board->setCellP((Cell**)malloc(32*sizeof(Cell*)));
	board->initializeBoard();

	Cell* cell1 = board->getCell(9);//original cost is 40 for that street
	cell1->setOwner(0);
	bool soldRailroad = false;

	//test case 1: no houses
	int pay = board->sellProperty(0, &soldRailroad);//choose cell 9
	int rightAns = 20;

	if(pay != rightAns){
		ok  = false;
		puts("testSellProperty did not pass test case 1");fflush(stdout);
	}
	else{
		puts("testSellProperty passed test case 1");fflush(stdout);
	}

	//test case 2: 2 houses
	Cell* cell2 = board->getCell(12);//is a street that cost 40
	cell2->setNumHouses(2);
	cell2->setOwner(0);

	pay = board->sellProperty(0, &soldRailroad);//choose cell 12
	rightAns = 20 + 15 + 15; //street with two houses

	if(pay != rightAns){
		ok  = false;
		puts("testSellProperty did not pass test case 2");fflush(stdout);
	}
	else{
		puts("testSellProperty passed test case 2");fflush(stdout);
	}

	//test case 3: railroad
	Cell* cell3 = board->getCell(5);//railroad cost 100
	cell3->setOwner(0);

	pay = board->sellProperty(0, &soldRailroad);//choose cell 5
	rightAns = 50;

	if(pay != rightAns){
		ok  = false;
		puts("testSellProperty did not pass test case 3");fflush(stdout);
	}
	else{
		puts("testSellProperty passed test case 3");fflush(stdout);
	}

	//test case 4: just houses
	Cell* cell4 = board->getCell(30);
	cell4->setOwner(0);
	cell4->setNumHouses(2);
	pay = board->sellProperty(0, &soldRailroad);
	rightAns = 30; //2 houses = 60 then divide by two

	if(pay != rightAns){
		ok  = false;
		puts("testSellProperty did not pass test case 4");fflush(stdout);
	}
	else{
		puts("testSellProperty passed test case 4");fflush(stdout);
	}

	//test case 5: player does not own property - supposed to repeat if not found

	cell4->setOwner(1);
	pay = board->sellProperty(0, &soldRailroad);
	rightAns = 50; //choose row 5 when prompted

	if(pay != rightAns){
		ok  = false;
		puts("testSellProperty did not pass test case 5");fflush(stdout);
	}
	else{
		puts("testSellProperty passed test case 5");fflush(stdout);
	}

	delete board;
	return ok;
}

bool Tests::testPassedGo(){
	bool ok = true;
	PlayerPiece* p1 = new PlayerPiece();

	Move* myMove = (Move*)malloc(sizeof(Move));
	myMove->oldRow = 31;
	myMove->newRow = 0;

	p1->setRowNum(0);

	bool ans = p1->passedGo(myMove);
	bool rightAns = true;

	if(ans != rightAns){
		ok = false;
		puts("testPassedGo did not pass");fflush(stdout);
	}
	else{
		puts("testPassedGo passed");fflush(stdout);
	}

	delete p1;
	return ok;
}

bool Tests::testAddToWallet(){
	bool ok = true;

	PlayerPiece* p1 = new PlayerPiece();
	p1->setWallet(0);
	p1->addToWallet(100);

	int ans = p1->getWallet();
	int rightAns = 100;

	if(ans != rightAns){
		ok = false;
		puts("testAddToWallet did not pass");fflush(stdout);
	}
	else{
		puts("testAddToWallet passed");fflush(stdout);
	}

	delete p1;
	return ok;
}

bool Tests::testTakeFromWallet(){
	bool ok = true;

	PlayerPiece* p1 = new PlayerPiece();
	p1->setWallet(100);
	p1->takeFromWallet(50);

	int ans = p1->getWallet();
	int rightAns = 50;

	if(ans != rightAns){
		ok = false;
		puts("testTakeFromWallet did not pass");fflush(stdout);
	}
	else{
		puts("testTakeFromWallet passed");fflush(stdout);
	}

	delete p1;
	return ok;
}

bool Tests::testAddPropertyOwned(){
	bool ok = true;
	PlayerPiece* p1 = new PlayerPiece();

	p1->setPropertyOwned(50);
	p1->addPropertyOwned(50);

	int ans = p1->getPropertyOwned();
	int rightAns = 100;

	if(ans != rightAns){
		ok = false;
		puts("testAddPropertyOwned did not pass");fflush(stdout);
	}
	else{
		puts("testAddPropertyOwned passed");fflush(stdout);
	}

	delete p1;
	return ok;
}

bool Tests::testCheckEnoughMoney(){
	bool ok = true;

	PlayerPiece* p1 = new PlayerPiece();
	p1->setWallet(100);
	int price = 101;

	bool ans = p1->checkEnoughMoney(price);
	bool rightAns = false;

	if(ans != rightAns){
		ok = false;
		puts("testCheckEnoughMoney did not pass test case 1");fflush(stdout);
	}
	else{
		puts("testCheckEnoughMoney passed test case 1");fflush(stdout);
	}

	price = 100;

	ans = p1->checkEnoughMoney(price);
	rightAns = true;
	if(ans != rightAns){
		ok = false;
		puts("testCheckEnoughMoney did not pass test case 2");fflush(stdout);
	}
	else{
		puts("testCheckEnoughMoney passed test case 2");fflush(stdout);
	}

	delete p1;
	return ok;
}

bool Tests::testRollDice(){
	bool ok = true;

	Production* prod = new Production();
	int randNum = prod->rollDice(1, 8);

	bool ans = (randNum >= 1 && randNum <= 8);

	if(!ans){
		ok = false;
		puts("testRollDice did not pass");fflush(stdout);
	}
	else{
		puts("testRollDice passed");fflush(stdout);
	}

	delete prod;
	return ok;
}

bool Tests::testRollChance(){
	bool ok = true;

	Production* prod = new Production();
	int randChance = prod->rollChance();
	bool ans = false;

	if(randChance < 0){//pay
		ans = ((randChance*(-1))%10 == 0) && randChance >= -60;
	}
	else{//get
		ans = ((randChance%10) == 0) && randChance <= 60;
	}

	if(!ans){
		ok = false;
		puts("testRollChance did not pass");fflush(stdout);
	}
	else{
		puts("testRollChance passed");fflush(stdout);
	}

	delete prod;
	return ok;
}

bool Tests::testIsEmpty(){
	bool ans = true;
	LList* list = new LList();

	puts("check");fflush(stdout);
	if(!(list->isEmpty())){
		ans = false;
		puts("testIsEmpty did not pass");fflush(stdout);
	}
	else{
		puts("testIsEmpty passed");fflush(stdout);
	}
	delete list;
	return ans;
}

bool Tests::testGetMoveList(){
	bool ans = true;
	LList* lists = new LList();

	//Test case 1: testing if the initial list is 0
	LLNode* moves = lists->getMoveList();
	//if not empty then fail
	if(moves->payP != (Payload*)0){
		ans = false;
		puts("testGetMoveList did not pass test case 1");fflush(stdout);
	}
	else{
		puts("testGetMoveList passed test case 1");fflush(stdout);
	}

	//Test case 2: testing if what we add is correct
	Move* move = (Move*)malloc(sizeof(Move));
	move->MoveNum = 1;
	Move* move1 = (Move*)malloc(sizeof(Move));
	move1->MoveNum = 2;

	lists->savePayload(move);
	LLNode* moveList = lists->getMoveList();

	if(moveList->payP->MoveNum != 1)
	{
		ans = false;
		puts("testGetMoveList did not pass test case 2");fflush(stdout);
	}
	else{
		puts("testGetMoveList passed test case 2");fflush(stdout);
	}

	//Test case 3: testing if what we add does not match a wrong ship
	if(moveList->payP->MoveNum == move1->MoveNum){
		ans = false;
		puts("testGetMoveList did not pass test case 3");fflush(stdout);
	}
	else{
		puts("testGetMoveList passed test case 3");fflush(stdout);
	}

	delete lists;
	return ans;
}

bool Tests::testEnqueue(){
	bool ok = false;

	LList* list = new LList();


	Move* move = (Move*)malloc(sizeof(Move));
	move->MoveNum = 1;

	list->savePayload(move);

	LLNode* ans = list->getMoveList();

	if(ans->payP == move){
		ok = true;
		puts("testEnqueue passed");fflush(stdout);
	}
	else{
		puts("testEnqueue did not pass");fflush(stdout);
	}

	delete list;
	return ok;
}

bool Tests::testMakeLList(){
	bool ok = true;

	LList* list = new LList();

	//what are the criteria for success for make LList?
	//should be able to make one, add data to it, get the data back
	//test case 1:
	bool rightAnswer = true;
	bool answer = list->isEmpty();
	if(answer!=rightAnswer)
	{
		ok = false;
		printf("testMakeLList case 1, 2, and 3 did not pass\n");fflush(stdout);
	}
	else{
		printf("testMakeLList case 1 passed\n");fflush(stdout);

		//test case 2:
		//add something to it and make sure it is not empty
		Move* temp = (Move*)malloc(sizeof(Move));
		list->savePayload(temp);
		bool answer1 = list->isEmpty();
		if(answer1 == rightAnswer)
		{
			ok = false;
			puts("testMakeLList case 2 did not pass");fflush(stdout);
		}
		printf("testmakeLList case 2 passed\n");fflush(stdout);

		//test case 3:
		//add something to it and get it out, compare it with the expected answer
		LLNode* lp = list->getMoveList();
		Payload* pP = lp->payP;
		if(pP == temp){
			answer = true;
		}
		if(answer != rightAnswer){
			ok = false;
			puts("testMakeLList case 3 did not pass");fflush(stdout);
		}
		printf("testMakeLList case 3 passed\n");fflush(stdout);
	}
	delete list;
	return ok;
}

bool Tests::testPrintMoveListInFile(){
	bool ok = true;

	LList* list = new LList();
	Move* temp = (Move*)malloc(sizeof(Move));
	temp->MoveNum = 1;
	temp->playerNum = 1;
	temp->housesBought = 1;
	temp->cellType = 1;
	temp->cost = 100;
	temp->diceRoll = 6;
	temp->madePurchase = true;
	temp->madeUpgrade = true;
	temp->newBalance = 50;
	temp->oldBalance = 150;
	temp->newRow = 13;
	temp->oldRow = 7;
	temp->passedGo = false;
	temp->soldProperty = false;
	temp->wasBankrupt = false;

	Move* temp1 = (Move*)malloc(sizeof(Move));

	temp1->MoveNum = 2;
	temp1->playerNum = 2;
	temp1->diceRoll = 6;
	temp1->oldRow = 8;
	temp1->newRow = 14;
	temp1->cellType = 0;
	temp1->madeUpgrade = false;
	temp1->housesBought = 0;
	temp1->madePurchase = false;
	temp1->soldProperty = true;
	temp1->wasBankrupt = true;
	temp1->passedGo = true;
	temp1->cost = 100;
	temp1->newBalance = 0;
	temp1->oldBalance = 100;
	temp1->propertySoldAmount = 50;

	list->savePayload(temp);
	list->savePayload(temp1);

	FILE* fp = fopen("outputFileForTests.txt", "w");
	list->printMoveListInFile(fp);

	//manual check output file
	ok = true;
	if(ok){
		puts("testPrintMoveListInFile passed");fflush(stdout);
	}
	else{
		puts("testPrintMoveListInFile did not pass");fflush(stdout);
	}

	fclose(fp);
	delete list;
	return ok;
}

bool Tests::testInitAndDisplayBoard(){
	bool ok = true;
	Board* board = new Board();
	board->setCellP((Cell**)malloc(32*sizeof(Cell*)));
	board->initializeBoard();

	board->displayBoard();

	//manual
	ok = true;
	if(ok){
		puts("testInitAndDisplayBoard passed");fflush(stdout);
	}
	else{
		puts("testInitAndDisplayBoard did not pass");fflush(stdout);
	}

	return ok;
}

bool Tests::testDisplayHoldings(){
	bool ok = true;
	Production* prod = new Production();
	PlayerPiece* players[2];
	players[0]->setPlayerNum(0);
	players[0]->setWallet(100);
	players[0]->setPropertyOwned(100);
	players[1]->setPlayerNum(1);
	players[1]->setWallet(150);
	players[1]->setPropertyOwned(100);

	prod->displayHoldings(players, 2);

	//manual test
	ok = true;
	if(ok){
		puts("testDisplayHoldings passed");fflush(stdout);
	}
	else{
		puts("testDisplayHoldings did not pass");fflush(stdout);
	}

	delete prod;
	return ok;
}


bool Tests::testWantToBuy(){
	bool ok = true;

	Board* board = new Board();
	board->setCellP((Cell**)malloc(32*sizeof(Cell*)));
	board->initializeBoard();


	PlayerPiece* p1 = new PlayerPiece();
	p1->setPlayerNum(1);
	bool yes = p1->wantToBuy(12, board);

	if(board->getCell(12)->getOwner() != 1){
		ok = false;
		puts("testWantToBuy did not pass");fflush(stdout);
	}
	else{
		puts("testWantToBuy passed");fflush(stdout);
	}

	delete board;
	delete p1;
	return ok;
}

bool Tests::testUpgradeProperty(){
	bool ok = true;

	Board* board = new Board();
	board->setCellP((Cell**)malloc(32*sizeof(Cell*)));
	board->initializeBoard();


	PlayerPiece* p1 = new PlayerPiece();
	p1->setPlayerNum(1);
	p1->setPropertyOwned(90);

	Cell* cell = board->getCell(12);
	cell->setOwner(1);
	cell->setNumHouses(3);
	int housesBought = -1;

	p1->upgradeProperty(board, &housesBought);//ask for one house at property 12

	printf("houses bought %d\n", housesBought);

	if(board->getCell(12)->getNumHouses() != 4 || p1->getPropertyOwned() != 120){
		ok = false;
		puts("testUpgradeProperty did not pass test case 1");fflush(stdout);
	}
	else{
		puts("testUpgradeProperty passed test case 1");fflush(stdout);
	}

	//we already reached the limit


	Cell* cell1 = board->getCell(13);
	cell1->setOwner(1);
	cell1->setNumHouses(3);
	housesBought = -1;

	p1->upgradeProperty(board, &housesBought);//ask for 1 house at property 12 then ask for 13
	printf("houses bought %d\n", housesBought);

	if(board->getCell(13)->getNumHouses() != 4 || p1->getPropertyOwned() != 150){
		ok = false;
		puts("testUpgradeProperty did not pass test case 2");fflush(stdout);
	}
	else{
		puts("testUpgradeProperty passed test case 2");fflush(stdout);
	}

	delete board;
	delete p1;

	return ok;
}


