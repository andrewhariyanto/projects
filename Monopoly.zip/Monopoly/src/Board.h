/*
 * Board.h
 *
 *  Created on: Mar 19, 2021
 *      Author: Andrew Hariyanto
 */

#ifndef BOARD_H_
#define BOARD_H_

#include "Cell.h"

class Board {
public:
	Board();
	virtual ~Board();
	void initializeBoard();
	void displayBoard();
	Cell* getCell(int);
	void setCellP(Cell**);
	Cell** getCellP();
	int sellProperty(int, bool*);//user inputs which property they want to sell

private:
	Cell** cellP;
};

#endif /* BOARD_H_ */
