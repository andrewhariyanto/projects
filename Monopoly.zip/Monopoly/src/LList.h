/*
 * LList.h
 *
 *  Created on: Mar 19, 2021
 *      Author: Andrew Hariyanto
 */

#ifndef LLIST_H_
#define LLIST_H_

#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>


typedef struct Move
{
	int MoveNum;
	int playerNum;
	int diceRoll;
	int oldRow;
	int newRow;
	int cellType;
	bool madeUpgrade;
	int housesBought;
	bool madePurchase;
	bool rolledChance;
	bool soldProperty;
	bool wasBankrupt;
	bool passedGo;
	int cost;
	int newBalance;
	int oldBalance;
	int propertySoldAmount;
	bool alreadyBankrupt;
	bool isLucky;
	bool propertyIsOwned;
	int chanceAmt;
	int rentAmt;

}Move;

typedef Move Payload;//temp


struct LLNode;
typedef struct LLNode
{
	struct LLNode* next;
	struct LLNode* prev;
	Payload* payP;
}LLNode;


class LList {
public:
	LList();
	virtual ~LList();
	void savePayload(Payload* mp);
	bool isEmpty();
	void printMoveListInFile(FILE*);
	LLNode* getMoveList();


private:
	LLNode* lp;

	LLNode* makeEmptyLinkedList();

};




#endif /* LLIST_H_ */
