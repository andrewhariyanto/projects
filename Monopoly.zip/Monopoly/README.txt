This is Andrew's Monopoly game.

How it works:
Normal Monopoly rules. Every time a player goes, the Monopoly board with the properties
and their details will be printed. Occupied properties will be denoted by the owner's
player number. Unoccupied properties will be denoted by -1. Prices for properties will
vary. Players' accounts and assets will also be printed. Game ends when all rolls are
exhausted or when there is one player left. Once game ends, you can find the log file
for all that happened in the game in MonopolyLogFile.txt.

The program takes in 3 arguments in the run configurations:
1. The name of the Monopoly board configuration (ex. monopolyConfig.txt)
2. The number of total turns (all players)
3. The player that start first (starts at Player 0)

MonopolyConfig File:
//number of players
3
// each player's position followed by the money followed by property(row)Num then numHouses on it. A -1 means that it
// goes to the next player
// ex. 5 is the propertyNum and 0 is the houses on it, then it alternates: 7 is the next propertyNum and 2 is the number of houses on it
14 100 5 0 7 2 23 1 -1
0 100 25 1 19 3 17 0 -1
2 100 3 3 13 0 -1

Enjoy!