/*
 * LList.cpp
 *
 *  Created on: Mar 9, 2021
 *      Author: Andrew Hariyanto
 */

#include "LList.h"

LList::LList() {
	// TODO Auto-generated constructor stub
	lp=makeEmptyLinkedList();
	lp2=makeEmptyLinkedList2();
	lp3=makeEmptyLinkedList3();

}

LList::~LList() {
	// TODO Auto-generated destructor stub
}

bool LList::isEmpty()
{
	bool ans = false;
	if(lp->payP == (Payload*)0)
	{
		ans = true;
	}
	return ans;
}

bool LList::isEmpty2()
{
	bool ans = false;
	if(lp2->payP == (Payload2*)0)
	{
		ans = true;
	}
	return ans;
}

bool LList::isEmpty3()
{
	bool ans = false;
	if(lp3->payP == (Payload3*)0)
	{
		ans = true;
	}
	return ans;
}

LLNode* LList::makeEmptyLinkedList()
{
	LLNode* lp = (LLNode*) malloc(sizeof(LLNode));
	lp->next = (struct LLNode*)0;
	lp->prev = (struct LLNode*)0;
	lp->payP = (Payload*)0;

	return lp;
}
LLNode2* LList::makeEmptyLinkedList2()
{
	LLNode2* lp = (LLNode2*) malloc(sizeof(LLNode2));
	lp->next = (struct LLNode2*)0;
	lp->prev = (struct LLNode2*)0;
	lp->payP = (Payload2*)0;

	return lp;
}

LLNode3* LList::makeEmptyLinkedList3()
{
	LLNode3* lp = (LLNode3*) malloc(sizeof(LLNode2));
	lp->next = (struct LLNode3*)0;
	lp->prev = (struct LLNode3*)0;
	lp->payP = (Payload3*)0;

	return lp;
}

void LList::savePayload(Payload* mp)
{
	//if the list is empty, then make payP be mp
	//else traverse the list,
	//make a new list element
	//put mp in that
	//attach the new list element to the existing list
	if(isEmpty())
	{
		lp->payP = mp;
	}
	else
	{
		LLNode* temp = lp;
		while(temp->next)
		{
			temp=(LLNode*)temp->next;
		}
		//now temp points to the last element

		//make a new element, attach mp to it, wire up the new element
		LLNode* newList = makeEmptyLinkedList();
		newList->payP = mp;
		temp->next = (struct LLNode*)newList;
		newList->prev = (struct LLNode*) temp;
	}
}
void LList::savePayload2(Payload2* mp)
{
	//if the list is empty, then make payP be mp
	//else traverse the list,
	//make a new list element
	//put mp in that
	//attach the new list element to the existing list
	if(isEmpty2())
	{
		lp2->payP = mp;
	}
	else
	{
		LLNode2* temp = lp2;
		while(temp->next)
		{
			temp=(LLNode2*)temp->next;
		}
		//now temp points to the last element

		//make a new element, attach mp to it, wire up the new element
		LLNode2* newList = makeEmptyLinkedList2();
		newList->payP = mp;
		temp->next = (struct LLNode2*) newList;
		newList->prev = (struct LLNode2*) temp;
	}
}

void LList::savePayload3(Payload3* mp)
{
	//if the list is empty, then make payP be mp
	//else traverse the list,
	//make a new list element
	//put mp in that
	//attach the new list element to the existing list
	if(isEmpty3())
	{
		lp3->payP = mp;
	}
	else
	{
		LLNode3* temp = lp3;
		while(temp->next)
		{
			temp=(LLNode3*)temp->next;
		}
		//now temp points to the last element

		//make a new element, attach mp to it, wire up the new element
		LLNode3* newList = makeEmptyLinkedList3();
		newList->payP = mp;
		temp->next = (struct LLNode3*) newList;
		newList->prev = (struct LLNode3*) temp;
	}
}


void LList::printMoveList()
{
	puts("Here are the moves:");fflush(stdout);
	if(lp3->payP == (Payload3*)0){
		puts("no moves");fflush(stdout);
	}
	else{
		LLNode3* temp = lp3;
		int currentRow = -1;
		int currentCol = -1;
		int capturedRow = -1;
		int capturedCol = -1;
		int nextRow = -1;
		int nextCol = -1;
		bool capture = false;
		int accum = 1;

		while(temp->next){
			currentRow = temp->payP->row;
			currentCol = temp->payP->col;
			capturedRow = temp->payP->capturedRow;
			capturedCol = temp->payP->capturedCol;
			nextRow = temp->payP->nextRow;
			nextCol = temp->payP->nextCol;
			capture = temp->payP->didCapture;

			if(capture){
				printf("%d. Piece at row %d and col %d can capture piece at row %d and col %d and will be at row %d and col %d\n",
						accum,currentRow,currentCol,capturedRow,capturedCol, nextRow,nextCol);fflush(stdout);
			}
			else{
				printf("%d. Piece at row %d and col %d will be at row %d and col %d\n", accum,
						currentRow,currentCol,nextRow,nextCol);fflush(stdout);
			}
			accum++;
			temp = temp->next;
		}
		currentRow = temp->payP->row;
		currentCol = temp->payP->col;
		capturedRow = temp->payP->capturedRow;
		capturedCol = temp->payP->capturedCol;
		nextRow = temp->payP->nextRow;
		nextCol = temp->payP->nextCol;
		capture = temp->payP->didCapture;

		if(capture){
			printf("%d. Piece at row %d and col %d can capture piece at row %d and col %d and will be at row %d and col %d\n",
					accum, currentRow,currentCol,capturedRow,capturedCol, nextRow,nextCol);
		}
		else{
			printf("%d. Piece at row %d and col %d will be at row %d and col %d\n", accum,
					currentRow,currentCol,nextRow,nextCol);
		}
	}
}


void LList::removeFromList(Payload* pP)
{
	LLNode* retHead = lp;//only changes if first element gets removed
	//find the payload
	//use the structure of a list, namely, list is empty or element followed by list
	if(isEmpty())
	{
		//nothing to do
	}
	else
	{
		//puts("list is not empty");fflush(stdout);
		LLNode* altHead = (LLNode*)lp->next;
		//find the item, if it is there
		LLNode* temp = lp;
		bool done = false;
		while((!done) && temp->next)
		{
			//are we there yet?
			if((temp->payP)->getRow() == pP->getRow() && temp->payP->getCol() == pP->getCol())
			{
				done=true;
				//puts("found it 1");fflush(stdout);
			}
			else
			{
				temp=(LLNode*)temp->next;
			}
		}
		//either we are pointing to the correct element, or we are at the end, or both
		if((temp->payP)->getRow() == pP->getRow() && temp->payP->getCol() == pP->getCol() )
		{
			//puts("found it 2");fflush(stdout);
			//found it, remove it
			//are we at the beginning?
			if(temp == lp)
			{  //found it at the first element
				//puts("found it at first element");fflush(stdout);
				//is the list of length 1?
				if(!(temp->next))
				{//if there is no next
					//remove payload, return empty list
					lp->payP = (Payload*)0;
				}
				else //not of length 1
				{ //not freeing the Payload, but freeing the first list element
					//puts("found it at first element of list with length > 1");fflush(stdout);
					//free(hP);
					retHead = altHead;
				}
			}
			else //not found at first location in list
			{
				//puts("found it not at first element");fflush(stdout);
				//save the linkages
				//found element has a next
				//found element has a prev
				//participant before has a next
				//participant after has a prev
				LLNode* prevPart = (LLNode*) temp->prev;//non-zero because not at first element
				LLNode* nextPart = (LLNode*) temp->next;//could be zero, if found at last element
				prevPart->next = (struct LLNode*) nextPart;//RHS is 0 if at end
				//puts("after setting the next of the previous");fflush(stdout);
               // printf("Next is %p, %d\n", nextPart, (bool)nextPart);fflush(stdout);
				if((bool)nextPart)//don't need guarded block if element found at end of list
				{
					//puts("before setting the previous of the next");fflush(stdout);
					nextPart->prev = (struct LLNode*) prevPart;

				}
				//puts("after handling the  previous of the next");fflush(stdout);
			}//end of not found at first location
		}//end of found it
		else
		{
			//didn't find it
			puts("did not find it");fflush(stdout);
			//nothing to do
		}//end did not find it
	}
	//printf("Returning %p\n", retHead); fflush(stdout);
	lp = retHead;
}

void LList::removeFromList2(Payload2* pP)
{
	LLNode2* retHead = lp2;//only changes if first element gets removed
	//find the payload
	//use the structure of a list, namely, list is empty or element followed by list
	if(isEmpty2())
	{
		//nothing to do
	}
	else
	{
		//puts("list is not empty");fflush(stdout);
		LLNode2* altHead = (LLNode2*)lp2->next;
		//find the item, if it is there
		LLNode2* temp = lp2;
		bool done = false;
		while((!done) && temp->next)
		{
			//are we there yet?
			if((temp->payP)->getRow() == pP->getRow() && temp->payP->getCol() == pP->getCol())
			{
				done=true;
				//puts("found it 1");fflush(stdout);
			}
			else
			{
				temp=(LLNode2*)temp->next;
			}
		}
		//either we are pointing to the correct element, or we are at the end, or both
		if((temp->payP)->getRow() == pP->getRow() && temp->payP->getCol() == pP->getCol() )
		{
			//puts("found it 2");fflush(stdout);
			//found it, remove it
			//are we at the beginning?
			if(temp == lp2)
			{  //found it at the first element
				//puts("found it at first element");fflush(stdout);
				//is the list of length 1?
				if(!(temp->next))
				{//if there is no next
					//remove payload, return empty list
					lp2->payP = (Payload2*)0;
				}
				else //not of length 1
				{ //not freeing the Payload, but freeing the first list element
					//puts("found it at first element of list with length > 1");fflush(stdout);
					//free(hP);
					retHead = altHead;
				}
			}
			else //not found at first location in list
			{
				//puts("found it not at first element");fflush(stdout);
				//save the linkages
				//found element has a next
				//found element has a prev
				//participant before has a next
				//participant after has a prev
				LLNode2* prevPart = (LLNode2*) temp->prev;//non-zero because not at first element
				LLNode2* nextPart = (LLNode2*) temp->next;//could be zero, if found at last element
				prevPart->next = (struct LLNode2*) nextPart;//RHS is 0 if at end
				//puts("after setting the next of the previous");fflush(stdout);
               // printf("Next is %p, %d\n", nextPart, (bool)nextPart);fflush(stdout);
				if((bool)nextPart)//don't need guarded block if element found at end of list
				{
					//puts("before setting the previous of the next");fflush(stdout);
					nextPart->prev = (struct LLNode2*) prevPart;

				}
				//puts("after handling the  previous of the next");fflush(stdout);
			}//end of not found at first location
		}//end of found it
		else
		{
			//didn't find it
			puts("did not find it");fflush(stdout);
			//nothing to do
		}//end did not find it
	}
	//printf("Returning %p\n", retHead); fflush(stdout);
	lp2 = retHead;
}

LLNode* LList::getTopSide(){
	return lp;
}

LLNode2* LList::getBotSide(){
	return lp2;
}

LLNode3* LList::getMoveList(){
	return lp3;
}

Move* LList::makeRandomMoveTopSide(){

	Move* randMove = (Move*)malloc(sizeof(Move));
	srand(time(0));

	LLNode3* moveList = lp3;
	LLNode3* moveList2 = lp3;
	LLNode3* moveList3 = lp3;
	//count the total number of moves and use modulo to get rand
	int accum = 0;
	int accum2 = 0; //to know where we are in the move list
	int accum3 = 0;
	int moveNumber = -1; //the move we will want
	bool hasCapture = false;
	bool done = false;

	while(moveList->next){
		accum++;
		moveList = moveList->next;
	}
	accum++; //now it counts all

	moveNumber = (rand() % accum); //random number from 0 to (n-1) total number of moves

	while(moveList3->next && !done){
		hasCapture = moveList3->payP->didCapture;
		if(hasCapture){
			puts("found capture");fflush(stdout);
			done = true;
			randMove = moveList3->payP;
			randMove->moveNum = accum3 + 1;
		}
		accum3++;
		moveList3 = moveList3->next;
	}//at the end of the list
	hasCapture = moveList3->payP->didCapture;
	if(hasCapture){
		puts("found capture");fflush(stdout);
		randMove = moveList3->payP;
		randMove->moveNum = accum3 + 1;
	}

	else{

		while(!done){
			puts("did not find capture");fflush(stdout);
			if(moveNumber == accum2){
				done = true;
				randMove = moveList2->payP;
				randMove->moveNum = accum2+1;
			}
			accum2++;
			moveList2 = moveList2->next;
		}
	}
	printf("row %d col %d to row %d col %d\n", randMove->row, randMove->col, randMove->nextRow,
			randMove->nextCol);fflush(stdout);
	return randMove;
}

Move* LList::userChooseMoveBotSide(int moveNumber){
	Move* chosenMove = (Move*)malloc(sizeof(Move));

	LLNode3* moveList = lp3;
	bool done = false;
	int accum = 1; //not zero index
	int accum2 = 0;

	while(moveList->next){
		accum2++;
		moveList = moveList->next;
	}
	accum2++;

	if(moveNumber > accum2){
		puts("Sorry invalid number please try again");fflush(stdout);
	}
	else{
		LLNode3* moveList2 = lp3;
		while(!done){
			if(moveNumber == accum){
				done = true;
				chosenMove = moveList2->payP;
			}
			accum++;
			moveList2 = moveList2->next;
		}
	}

	//print moves will show first in the console and it is not zero indexed



	return chosenMove;
}

void LList::dequeueAllMoves(){
	lp3 = this->makeEmptyLinkedList3();
}



