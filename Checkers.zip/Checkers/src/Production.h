/*
 * Production.h
 *
 *  Created on: Mar 9, 2021
 *      Author: Andrew Hariyanto
 */

#ifndef PRODUCTION_H_
#define PRODUCTION_H_
#include <stdio.h>
#include <stdbool.h>
#include <string.h>//strncpy
#include <stdlib.h>//strtol
#include "Board.h"
#include "Checker.h"

#define FILENAMELENGTHALLOWANCE 50

class Production {
public:
	Production();
	virtual ~Production();
	bool prod(int argc, char* argv[]);
	bool readFile(char*, Board*, LList*);
	void displayBoardInFile(FILE*, Board*);
	void printMoveListInFile(FILE*, Board* ,LList* );

private:

};

#endif /* PRODUCTION_H_ */
