/*
 * Tests.cpp
 *
 *  Created on: Mar 9, 2021
 *      Author: Andrew Hariyanto
 */

#include "Tests.h"
#include <stdbool.h>

Tests::Tests() {
	// TODO Auto-generated constructor stub

}

Tests::~Tests() {
	// TODO Auto-generated destructor stub
}

bool Tests::tests()
{
	bool answer = true;

	bool ok2 = testInitAndDisplayBoard();
	bool ok1 = testReadFile();

	bool ok3 = testIsEmpty();
	bool ok4 = testMakeLList();

	bool ok5 = testEnqueue();
	bool ok35 = testRemoveFromList();
	bool ok7 = testGetTopSidePieces();
	bool ok8 = testGetBotSidePieces();
	bool ok9 = testGetMoveList();
	bool ok10 = testCanMoveDownLeft();
	bool ok11 = testCanMoveDownRight();
	bool ok12 = testCanMoveUpLeft();
	bool ok13 = testCanMoveUpRight();
	bool ok14 = testCanJumpDownLeft();
	bool ok15 = testCanJumpDownRight();
	bool ok16 = testCanJumpUpLeft();
	bool ok17 = testCanJumpUpRight();
	bool ok18 = testCollectMovesTopSide();
	bool ok19 = testCollectMovesBotSide();
	bool ok20 = testPromotionTopSide();
	bool ok21 = testPromotionBotSide();
	bool ok22 = testPrintMoveList();
	bool ok23 = testMakeRandMoveTopSide();
	bool ok24 = testUserChooseMoveBotSide();
	bool ok25 = testDequeueAllMoves();
	bool ok26 = testUpdateBoard();
	bool ok27 = testDisplayBoardInFile();
	bool ok28 = testPrintMoveListInFile();
	bool ok29 = testSetGetPiecesP();
	bool ok30 = testGetCheckerPieceGetRowGetCol();
	bool ok32 = testSetGetType();
	bool ok33 = testSetGetSide();
	bool ok34 = testSetGetCoordinates();
	answer = ok1 && ok2 && ok3 && ok4 && ok5 && ok7 && ok8 && ok9 && ok10 && ok11 && ok12 && ok13
			&& ok14 && ok15 && ok16 && ok17 && ok18 && ok19 && ok20 && ok21 && ok22 && ok23 && ok24 && ok25
			&& ok26 && ok27 && ok28 && ok29 && ok30 && ok32 && ok33 && ok34 && ok35;
	return answer;
}

bool Tests::testReadFile()
{
	puts("starting testReadFile"); fflush(stdout);
	bool ok = false;

	Board* checkerBoard = new Board();

	Production* pP = new Production();
	LList* list = new LList();

	ok = pP->readFile("BoardConfig.txt", checkerBoard, list); //read the file
	puts("the board looks like");fflush(stdout);

	checkerBoard->displayBoard();

	//manual
	ok = true;
	if(ok){
		puts("testReadFile passed");fflush(stdout);
	}
	else{
		puts("testReadFile did not pass");fflush(stdout);
	}
	delete checkerBoard;

	return ok;
}

bool Tests::testInitAndDisplayBoard(){
	bool ok = false;
	puts("now testing init and display");fflush(stdout);

	Board* board = new Board();
	board->setPiecesP((Checker**)malloc(64*sizeof(Checker*)));
	board->initBoard();


	//manual test
	board->displayBoard();

	ok = true;

	if(ok){
		puts("testInitAndDisplayBoard passed");fflush(stdout);
	}
	else{
		puts("testInitAndDisplayBoard did not pass");fflush(stdout);
	}

	delete board;
	return ok;
}

bool Tests::testIsEmpty(){
	puts("Starting testIsEmpty");fflush(stdout);
	bool ans = true;
	LList* list = new LList();

	puts("check");fflush(stdout);
	if(!(list->isEmpty())){
		ans = false;
		puts("testIsEmpty did not pass");fflush(stdout);
	}
	else{
		puts("testIsEmpty passed");fflush(stdout);
	}
	delete list;
	return ans;
}

bool Tests::testEnqueue()
{
	bool ok = false;
	LList* list = new LList();

	Checker* temp = (Checker*) malloc(sizeof(Checker));
	temp->setType(2);
	temp->setTopSide(true);
	list->savePayload(temp);
	LLNode* ans = list->getTopSide();

	if(ans->payP == temp){
		ok = true;
		puts("testEnqueue passed");fflush(stdout);
	}
	else{
		puts("testEnqueue did not pass");fflush(stdout);
	}

	delete list;
	return ok;
}

bool Tests::testMakeLList()
{
	bool ok = true;

	LList* list = new LList();

	//what are the criteria for success for make LList?
	//should be able to make one, add data to it, get the data back
	//test case 1:
	bool rightAnswer = true;
	bool answer = list->isEmpty();
	if(answer!=rightAnswer)
	{
		ok = false;
		printf("testMakeLList case 1, 2, and 3 did not pass\n");fflush(stdout);
	}
	else{
		printf("testMakeLList case 1 passed\n");fflush(stdout);

		//test case 2:
		//add something to it and make sure it is not empty
		Checker* temp = (Checker*) malloc(sizeof(Checker));
		temp->setType(1);
		list->savePayload(temp);
		bool answer1 = list->isEmpty();
		if(answer1 == rightAnswer)
		{
			ok = false;
			puts("testMakeLList case 2 did not pass");fflush(stdout);
		}
		printf("testmakeLList case 2 passed\n");fflush(stdout);

		//test case 3:
		//add something to it and get it out, compare it with the expected answer
		LLNode* lp = list->getTopSide();
		Payload* pP = lp->payP;
		if(pP == temp){
			answer = true;
		}
		if(answer != rightAnswer){
			ok = false;
			puts("testMakeLList case 3 did not pass");fflush(stdout);
		}
		printf("testMakeLList case 3 passed\n");fflush(stdout);
	}
	delete list;
	return ok;
}

bool Tests::testGetTopSidePieces(){
	bool ans = true;
	LList* lists = new LList();

	//Test case 1: testing if the initial list is 0
	LLNode* topSide = lists->getTopSide();
	//if not empty then fail
	if(topSide->payP != (Payload*)0){
		ans = false;
		puts("testGetTopSidePieces did not pass test case 1");fflush(stdout);
	}
	else{
		puts("testGetTopSidePieces passed test case 1");fflush(stdout);
	}

	//Test case 2: testing if what we add is correct
	Checker* piece1 = (Checker*) malloc(sizeof(Checker));
	Checker* piece2 = (Checker*) malloc(sizeof(Checker));
	piece1->setType(1);
	piece1->setTopSide(true);
	piece2->setType(2);
	piece2->setTopSide(false);


	lists->savePayload(piece1);
	LLNode* topSideAgain = lists->getTopSide();
	if(topSideAgain->payP->getType() != piece1->getType() ||
			topSideAgain->payP->getSide() != piece1->getSide())
	{
		ans = false;
		puts("testGetTopSidePieces did not pass test case 2");fflush(stdout);
	}
	else{
		puts("testGetTopSidePieces passed test case 2");fflush(stdout);
	}

	//Test case 3: testing if what we add does not match a wrong room
	if(topSideAgain->payP->getType() == piece2->getType() ||
			topSideAgain->payP->getSide() == piece2->getSide()){
		ans = false;
		puts("testGetTopSidePieces did not pass test case 3");fflush(stdout);
	}
	else{
		puts("testGetTopSidePieces passed test case 3");fflush(stdout);
	}

	delete lists;
	return ans;
}

bool Tests::testGetBotSidePieces(){
	bool ans = true;
	LList* lists = new LList();

	//Test case 1: testing if the initial list is 0
	LLNode2* botSide = lists->getBotSide();
	//if not empty then fail
	if(botSide->payP){
		ans = false;
		puts("testGetBotSidePieces did not pass test case 1");fflush(stdout);
	}
	else{
		puts("testGetBotSidePieces passed test case 1");fflush(stdout);
	}

	//Test case 2: testing if what we add is correct
	Checker* piece1 = (Checker*) malloc(sizeof(Checker));
	Checker* piece2 = (Checker*) malloc(sizeof(Checker));
	piece1->setType(1);
	piece1->setTopSide(false);
	piece2->setType(2);
	piece2->setTopSide(true);


	lists->savePayload2(piece1);
	LLNode2* botSideAgain = lists->getBotSide();
	if(botSideAgain->payP->getType() != piece1->getType() ||
			botSideAgain->payP->getSide() != piece1->getSide())
	{
		ans = false;
		puts("testGetBotSidePieces did not pass test case 2");fflush(stdout);
	}
	else{
		puts("testGetBotSidePieces passed test case 2");fflush(stdout);
	}

	//Test case 3: testing if what we add does not match a wrong room
	if(botSideAgain->payP->getType() == piece2->getType() ||
			botSideAgain->payP->getSide() == piece2->getSide()){
		ans = false;
		puts("testGetBotSidePieces did not pass test case 3");fflush(stdout);
	}
	else{
		puts("testGetBotSidePieces passed test case 3");fflush(stdout);
	}

	delete lists;
	return ans;
}

bool Tests::testGetMoveList(){
	bool ans = true;
	LList* lists = new LList();

	//Test case 1: testing if the initial list is 0
	LLNode3* moveList = lists->getMoveList();
	//if not empty then fail
	if(moveList->payP){
		ans = false;
		puts("testGetMoveList did not pass test case 1");fflush(stdout);
	}
	else{
		puts("testGetMoveList passed test case 1");fflush(stdout);
	}

	//Test case 2: testing if what we add is correct

	Move* move1 = (Move*) malloc(sizeof(Move));
	Move* move2 = (Move*) malloc(sizeof(Move));
	move1->col = 1;
	move1->row = 1;
	move2->col = 2;
	move2->row = 3;


	lists->savePayload3(move1);
	LLNode3* moveListAgain = lists->getMoveList();
	if(moveListAgain->payP->col != move1->col ||
			moveListAgain->payP->row != move1->row)
	{
		ans = false;
		puts("testGetMoveList did not pass test case 2");fflush(stdout);
	}
	else{
		puts("testGetMoveList passed test case 2");fflush(stdout);
	}

	//Test case 3: testing if what we add does not match a wrong room
	if(moveListAgain->payP->col == move2->col ||
			moveListAgain->payP->row == move2->row){
		ans = false;
		puts("testGetMoveList did not pass test case 3");fflush(stdout);
	}
	else{
		puts("testGetMoveList passed test case 3");fflush(stdout);
	}

	delete lists;
	return ans;
}

bool Tests::testCanMoveDownLeft(){
	bool ok = true;

	Board* gameBoard = new Board();
	gameBoard->setPiecesP((Checker**)malloc(64*sizeof(Checker*)));
	gameBoard->initBoard();
	Checker* piece1 = (Checker*) malloc(sizeof(Checker));
	Checker* piece2 = (Checker*) malloc(sizeof(Checker));
	Checker* piece3 = (Checker*) malloc(sizeof(Checker));


	//Checker* piece = gameBoard->getCheckerPiece(3, 1);
	//printf("%d\n", (piece->getType()));
	piece1 = gameBoard->getCheckerPiece(2,4);
	piece1->setType(2);

	//test case 1: just one piece on the board should be able to move
	bool rightAns = true;
	bool ans = false;
	int currentRow = piece1->getRow();
	int currentCol = piece1->getCol();
	ans = gameBoard->canMoveDownLeft(currentRow,currentCol);

	if(ans != rightAns){
		ok = false;
		puts("testCanMoveDownLeft did not pass test case 1");fflush(stdout);
	}
	else{
		puts("testCanMoveDownLeft passed test case 1");fflush(stdout);
	}

	//test case 2: piece is at col 0
	piece2 = gameBoard->getCheckerPiece(1, 0);
	piece2->setType(1);
	rightAns = false;
	currentRow = piece2->getRow();
	currentCol = piece2->getCol();
	ans = gameBoard->canMoveDownLeft(currentRow, currentCol);

	if(ans != rightAns){
		ok = false;
		puts("testCanMoveDownLeft did not pass test case 2");fflush(stdout);
	}
	else{
		puts("testCanMoveDownLeft passed test case 2");fflush(stdout);
	}

	//test case 3: there is another piece in the space it wants to go to
	piece3 = gameBoard->getCheckerPiece(3, 3); //piece 3 is diagonal to piece1
	piece3->setType(1);

	rightAns = false;
	currentRow = piece1->getRow();
	currentCol = piece1->getCol();
	ans = gameBoard->canMoveDownLeft(currentRow, currentCol);
	if(ans != rightAns){
		ok = false;
		puts("testCanMoveDownLeft did not pass test case 3");fflush(stdout);
	}
	else{
		puts("testCanMoveDownLeft passed test case 3");fflush(stdout);
	}

	delete gameBoard;
	return ok;
}

bool Tests::testCanMoveDownRight(){
	bool ok = true;

	Board* gameBoard = new Board();
	gameBoard->setPiecesP((Checker**)malloc(64*sizeof(Checker*)));
	gameBoard->initBoard();

	Checker* piece1 = (Checker*) malloc(sizeof(Checker));
	Checker* piece2 = (Checker*) malloc(sizeof(Checker));
	Checker* piece3 = (Checker*) malloc(sizeof(Checker));

	piece1 = gameBoard->getCheckerPiece(2,4);
	piece1->setType(2);

	//test case 1: just one piece on the board should be able to move
	bool rightAns = true;
	bool ans = false;
	int currentRow = piece1->getRow();
	int currentCol = piece1->getCol();
	ans = gameBoard->canMoveDownRight(currentRow,currentCol);

	if(ans != rightAns){
		ok = false;
		puts("testCanMoveDownRight did not pass test case 1");fflush(stdout);
	}
	else{
		puts("testCanMoveDownRight passed test case 1");fflush(stdout);
	}

	//test case 2: piece is at col =7
	piece2 = gameBoard->getCheckerPiece(1, 7);
	piece2->setType(1);
	rightAns = false;
	currentRow = piece2->getRow();
	currentCol = piece2->getCol();
	ans = gameBoard->canMoveDownRight(currentRow, currentCol);

	if(ans != rightAns){
		ok = false;
		puts("testCanMoveDownRight did not pass test case 2");fflush(stdout);
	}
	else{
		puts("testCanMoveDownRight passed test case 2");fflush(stdout);
	}

	//test case 3: there is another piece in the space it wants to go to
	piece3 = gameBoard->getCheckerPiece(3, 5); //piece 3 is diagonal to piece1
	piece3->setType(1);

	rightAns = false;
	currentRow = piece1->getRow();
	currentCol = piece1->getCol();
	ans = gameBoard->canMoveDownRight(currentRow, currentCol);
	if(ans != rightAns){
		ok = false;
		puts("testCanMoveDownRight did not pass test case 3");fflush(stdout);
	}
	else{
		puts("testCanMoveDownRight passed test case 3");fflush(stdout);
	}

	delete gameBoard;
	return ok;
}

bool Tests::testCanMoveUpLeft(){
	bool ok = true;

	Board* gameBoard = new Board();
	gameBoard->setPiecesP((Checker**)malloc(64*sizeof(Checker*)));
	gameBoard->initBoard();

	Checker* piece1 = (Checker*) malloc(sizeof(Checker));
	Checker* piece2 = (Checker*) malloc(sizeof(Checker));
	Checker* piece3 = (Checker*) malloc(sizeof(Checker));

	piece1 = gameBoard->getCheckerPiece(2,4);
	piece1->setType(2);

	//test case 1: just one piece on the board should be able to move
	bool rightAns = true;
	bool ans = false;
	int currentRow = piece1->getRow();
	int currentCol = piece1->getCol();
	ans = gameBoard->canMoveUpLeft(currentRow,currentCol);

	if(ans != rightAns){
		ok = false;
		puts("testCanMoveUpLeft did not pass test case 1");fflush(stdout);
	}
	else{
		puts("testCanMoveUpLeft passed test case 1");fflush(stdout);
	}

	//test case 2: piece is at col = 0
	piece2 = gameBoard->getCheckerPiece(2,0);

	piece2->setType(1);

	rightAns = false;
	currentRow = piece2->getRow();
	currentCol = piece2->getCol();

	ans = gameBoard->canMoveUpLeft(currentRow, currentCol);

	if(ans != rightAns){
		ok = false;
		puts("testCanMoveUpLeft did not pass test case 2");fflush(stdout);
	}
	else{
		puts("testCanMoveUpLeft passed test case 2");fflush(stdout);
	}

	//test case 3: there is another piece in the space it wants to go to
	piece3 = gameBoard->getCheckerPiece(1, 3); //piece 3 is diagonal to piece1
	piece3->setType(1);

	rightAns = false;
	currentRow = piece1->getRow();
	currentCol = piece1->getCol();
	ans = gameBoard->canMoveUpLeft(currentRow, currentCol);
	if(ans != rightAns){
		ok = false;
		puts("testCanMoveUpLeft did not pass test case 3");fflush(stdout);
	}
	else{
		puts("testCanMoveUpLeft passed test case 3");fflush(stdout);
	}

	delete gameBoard;
	return ok;
}
bool Tests::testCanMoveUpRight(){
	bool ok = true;

	Board* gameBoard = new Board();
	gameBoard->setPiecesP((Checker**)malloc(64*sizeof(Checker*)));
	gameBoard->initBoard();

	Checker* piece1 = (Checker*) malloc(sizeof(Checker));
	Checker* piece2 = (Checker*) malloc(sizeof(Checker));
	Checker* piece3 = (Checker*) malloc(sizeof(Checker));

	piece1 = gameBoard->getCheckerPiece(2,4);
	piece1->setType(2);

	//test case 1: just one piece on the board should be able to move
	bool rightAns = true;
	bool ans = false;
	int currentRow = piece1->getRow();
	int currentCol = piece1->getCol();
	ans = gameBoard->canMoveUpRight(currentRow,currentCol);

	if(ans != rightAns){
		ok = false;
		puts("testCanMoveUpRight did not pass test case 1");fflush(stdout);
	}
	else{
		puts("testCanMoveUpRight passed test case 1");fflush(stdout);
	}

	//test case 2: piece is at row = 2 and col = 7
	piece2 = gameBoard->getCheckerPiece(2, 7);
	piece2->setType(1);
	rightAns = false;
	currentRow = piece2->getRow();
	currentCol = piece2->getCol();
	ans = gameBoard->canMoveUpRight(currentRow, currentCol);

	if(ans != rightAns){
		ok = false;
		puts("testCanMoveUpRight did not pass test case 2");fflush(stdout);
	}
	else{
		puts("testCanMoveUpRight passed test case 2");fflush(stdout);
	}

	//test case 3: there is another piece in the space it wants to go to
	piece3 = gameBoard->getCheckerPiece(1, 5); //piece 3 is diagonal to piece1
	piece3->setType(1);

	rightAns = false;
	currentRow = piece1->getRow();
	currentCol = piece1->getCol();
	ans = gameBoard->canMoveUpRight(currentRow, currentCol);
	if(ans != rightAns){
		ok = false;
		puts("testCanMoveUpRight did not pass test case 3");fflush(stdout);
	}
	else{
		puts("testCanMoveUpRight passed test case 3");fflush(stdout);
	}

	delete gameBoard;
	return ok;
}
bool Tests::testCanJumpDownLeft(){
	bool ok = true;

	Board* gameBoard = new Board();
	gameBoard->setPiecesP((Checker**)malloc(64*sizeof(Checker*)));
	gameBoard->initBoard();

	Checker* piece1 = (Checker*) malloc(sizeof(Checker));
	Checker* piece2 = (Checker*) malloc(sizeof(Checker));
	Checker* piece3 = (Checker*) malloc(sizeof(Checker));
	Checker* piece4 = (Checker*) malloc(sizeof(Checker));
	Checker* piece5 = (Checker*) malloc(sizeof(Checker));
	Checker* piece6 = (Checker*) malloc(sizeof(Checker));

	piece1 = gameBoard->getCheckerPiece(2,4);
	piece1->setType(2);
	piece1->setTopSide(true);


	//test case 1: just one piece on the board cannot jump
	bool rightAns = false;
	bool ans = false;
	int currentRow = piece1->getRow();
	int currentCol = piece1->getCol();
	ans = gameBoard->canJumpDownLeft(currentRow,currentCol);

	if(ans != rightAns){
		ok = false;
		puts("testCanJumpDownLeft did not pass test case 1");fflush(stdout);
	}
	else{
		puts("testCanJumpDownLeft passed test case 1");fflush(stdout);
	}

	//test case 2: piece is at row = 7 and col = 0
	piece2 = gameBoard->getCheckerPiece(7, 0);
	piece2->setType(1);
	rightAns = false;
	currentRow = piece2->getRow();
	currentCol = piece2->getCol();
	ans = gameBoard->canJumpDownLeft(currentRow, currentCol);

	if(ans != rightAns){
		ok = false;
		puts("testCanJumpDownLeft did not pass test case 2");fflush(stdout);
	}
	else{
		puts("testCanJumpDownLeft passed test case 2");fflush(stdout);
	}

	//test case 3: there is another piece in the space it wants to go to
	piece3 = gameBoard->getCheckerPiece(3, 3); //piece 3 is diagonal to piece1, there is space on the next
	piece3->setType(1);
	piece3->setTopSide(false);

	rightAns = true;
	currentRow = piece1->getRow();
	currentCol = piece1->getCol();
	ans = gameBoard->canJumpDownLeft(currentRow, currentCol);
	if(ans != rightAns){
		ok = false;
		puts("testCanJumpDownLeft did not pass test case 3");fflush(stdout);
	}
	else{
		puts("testCanJumpDownLeft passed test case 3");fflush(stdout);
	}

	//test case 4: piece is at row 6 and col 3 and there is a piece in its diagonal
	piece4 = gameBoard->getCheckerPiece(6, 3);
	piece4->setType(2);
	rightAns = false;
	currentRow = piece4->getRow();
	currentCol = piece4->getCol();
	piece5 = gameBoard->getCheckerPiece(7, 2);
	piece5->setType(1);
	ans = gameBoard->canJumpDownLeft(currentRow, currentCol);

	if(ans != rightAns){
		ok = false;
		puts("testCanJumpDownLeft did not pass test case 4");fflush(stdout);
	}
	else{
		puts("testCanJumpDownLeft passed test case 4");fflush(stdout);
	}

	//test case 5: piece cannot capture because there not available space
	piece6 = gameBoard->getCheckerPiece(3, 3);
	piece6->setType(2);
	rightAns = false;
	currentRow = piece1->getRow();
	currentCol = piece1->getCol();
	piece5 = gameBoard->getCheckerPiece(4, 2);
	piece5->setType(1);
	ans = gameBoard->canJumpDownLeft(currentRow, currentCol);

	if(ans != rightAns){
		ok = false;
		puts("testCanJumpDownLeft did not pass test case 5");fflush(stdout);
	}
	else{
		puts("testCanJumpDownLeft passed test case 5");fflush(stdout);
	}

	delete gameBoard;
	return ok;
}
bool Tests::testCanJumpDownRight(){
	bool ok = true;

	Board* gameBoard = new Board();
	gameBoard->setPiecesP((Checker**)malloc(64*sizeof(Checker*)));
	gameBoard->initBoard();

	Checker* piece1 = (Checker*) malloc(sizeof(Checker));
	Checker* piece2 = (Checker*) malloc(sizeof(Checker));
	Checker* piece3 = (Checker*) malloc(sizeof(Checker));
	Checker* piece4 = (Checker*) malloc(sizeof(Checker));
	Checker* piece5 = (Checker*) malloc(sizeof(Checker));
	Checker* piece6 = (Checker*) malloc(sizeof(Checker));

	piece1 = gameBoard->getCheckerPiece(2,4);
	piece1->setType(2);
	piece1->setTopSide(true);

	//test case 1: just one piece on the board cannot jump
	bool rightAns = false;
	bool ans = false;
	int currentRow = piece1->getRow();
	int currentCol = piece1->getCol();
	ans = gameBoard->canJumpDownRight(currentRow,currentCol);

	if(ans != rightAns){
		ok = false;
		puts("testCanJumpDownRight did not pass test case 1");fflush(stdout);
	}
	else{
		puts("testCanJumpDownRight passed test case 1");fflush(stdout);
	}

	//test case 2: piece is at row = 7 and col = 6
	piece2 = gameBoard->getCheckerPiece(7, 6);
	piece2->setType(1);
	rightAns = false;
	currentRow = piece2->getRow();
	currentCol = piece2->getCol();
	ans = gameBoard->canJumpDownRight(currentRow, currentCol);

	if(ans != rightAns){
		ok = false;
		puts("testCanJumpDownRight did not pass test case 2");fflush(stdout);
	}
	else{
		puts("testCanJumpDownRight passed test case 2");fflush(stdout);
	}

	//test case 3: there is another piece in the space it wants to go to
	piece3 = gameBoard->getCheckerPiece(3, 5); //piece 3 is diagonal to piece1, there is space on the next
	piece3->setType(1);
	piece3->setTopSide(false);

	rightAns = true;
	currentRow = piece1->getRow();
	currentCol = piece1->getCol();
	ans = gameBoard->canJumpDownRight(currentRow, currentCol);
	if(ans != rightAns){
		ok = false;
		puts("testCanJumpDownRight did not pass test case 3");fflush(stdout);
	}
	else{
		puts("testCanJumpDownRight passed test case 3");fflush(stdout);
	}

	//test case 4: piece is at row 6 and col 3 and there is a piece in its diagonal
	piece4 = gameBoard->getCheckerPiece(6, 3);
	piece4->setType(2);
	rightAns = false;
	currentRow = piece4->getRow();
	currentCol = piece4->getCol();
	piece5 = gameBoard->getCheckerPiece(7, 4);
	piece5->setType(1);
	ans = gameBoard->canJumpDownRight(currentRow, currentCol);

	if(ans != rightAns){
		ok = false;
		puts("testCanJumpDownRight did not pass test case 4");fflush(stdout);
	}
	else{
		puts("testCanJumpDownRight passed test case 4");fflush(stdout);
	}

	//test case 5: piece cannot capture because there not available space
	piece6 = gameBoard->getCheckerPiece(3, 5);
	piece6->setType(2);
	rightAns = false;
	currentRow = piece1->getRow();
	currentCol = piece1->getCol();
	piece5 = gameBoard->getCheckerPiece(4, 6);
	piece5->setType(1);
	ans = gameBoard->canJumpDownRight(currentRow, currentCol);

	if(ans != rightAns){
		ok = false;
		puts("testCanJumpDownRight did not pass test case 5");fflush(stdout);
	}
	else{
		puts("testCanJumpDownRight passed test case 5");fflush(stdout);
	}

	delete gameBoard;
	return ok;
}
bool Tests::testCanJumpUpLeft(){
	bool ok = true;

	Board* gameBoard = new Board();
	gameBoard->setPiecesP((Checker**)malloc(64*sizeof(Checker*)));
	gameBoard->initBoard();

	Checker* piece1 = (Checker*) malloc(sizeof(Checker));
	Checker* piece2 = (Checker*) malloc(sizeof(Checker));
	Checker* piece3 = (Checker*) malloc(sizeof(Checker));
	Checker* piece4 = (Checker*) malloc(sizeof(Checker));
	Checker* piece5 = (Checker*) malloc(sizeof(Checker));
	Checker* piece6 = (Checker*) malloc(sizeof(Checker));

	piece1 = gameBoard->getCheckerPiece(2,4);
	piece1->setType(2);
	piece1->setTopSide(true);

	//test case 1: just one piece on the board cannot jump
	bool rightAns = false;
	bool ans = false;
	int currentRow = piece1->getRow();
	int currentCol = piece1->getCol();
	ans = gameBoard->canJumpUpLeft(currentRow,currentCol);

	if(ans != rightAns){
		ok = false;
		puts("testCanJumpUpLeft did not pass test case 1");fflush(stdout);
	}
	else{
		puts("testCanJumpUpLeft passed test case 1");fflush(stdout);
	}

	//test case 2: piece is at row = 1 and col = 0
	piece2 = gameBoard->getCheckerPiece(1, 0);
	piece2->setType(1);
	rightAns = false;
	currentRow = piece2->getRow();
	currentCol = piece2->getCol();
	ans = gameBoard->canJumpUpLeft(currentRow, currentCol);

	if(ans != rightAns){
		ok = false;
		puts("testCanJumpUpLeft did not pass test case 2");fflush(stdout);
	}
	else{
		puts("testCanJumpUpLeft passed test case 2");fflush(stdout);
	}

	//test case 3: there is another piece in the space it wants to go to
	piece3 = gameBoard->getCheckerPiece(1, 3); //piece 3 is diagonal to piece1, there is space on the next
	piece3->setType(1);
	piece3->setTopSide(false);

	rightAns = true;
	currentRow = piece1->getRow();
	currentCol = piece1->getCol();
	ans = gameBoard->canJumpUpLeft(currentRow, currentCol);
	if(ans != rightAns){
		ok = false;
		puts("testCanJumpUpLeft did not pass test case 3");fflush(stdout);
	}
	else{
		puts("testCanJumpUpLeft passed test case 3");fflush(stdout);
	}

	//test case 4: piece is at row 1 and col 6 and there is a piece in its diagonal
	piece4 = gameBoard->getCheckerPiece(1, 6);
	piece4->setType(2);
	rightAns = false;
	currentRow = piece4->getRow();
	currentCol = piece4->getCol();
	piece5 = gameBoard->getCheckerPiece(0, 5);
	piece5->setType(1);
	ans = gameBoard->canJumpUpLeft(currentRow, currentCol);

	if(ans != rightAns){
		ok = false;
		puts("testCanJumpUpLeft did not pass test case 4");fflush(stdout);
	}
	else{
		puts("testCanJumpUpLeft passed test case 4");fflush(stdout);
	}

	//test case 5: piece cannot capture because there is no available space
	piece6 = gameBoard->getCheckerPiece(1, 3);
	piece6->setType(2);
	rightAns = false;
	currentRow = piece1->getRow();
	currentCol = piece1->getCol();
	piece5 = gameBoard->getCheckerPiece(0, 2);
	piece5->setType(1);
	ans = gameBoard->canJumpUpLeft(currentRow, currentCol);

	if(ans != rightAns){
		ok = false;
		puts("testCanJumpUpLeft did not pass test case 5");fflush(stdout);
	}
	else{
		puts("testCanJumpUpLeft passed test case 5");fflush(stdout);
	}

	delete gameBoard;
	return ok;
}
bool Tests::testCanJumpUpRight(){
	bool ok = true;

	Board* gameBoard = new Board();
	gameBoard->setPiecesP((Checker**)malloc(64*sizeof(Checker*)));
	gameBoard->initBoard();

	Checker* piece1 = (Checker*) malloc(sizeof(Checker));
	Checker* piece2 = (Checker*) malloc(sizeof(Checker));
	Checker* piece3 = (Checker*) malloc(sizeof(Checker));
	Checker* piece4 = (Checker*) malloc(sizeof(Checker));
	Checker* piece5 = (Checker*) malloc(sizeof(Checker));
	Checker* piece6 = (Checker*) malloc(sizeof(Checker));

	piece1 = gameBoard->getCheckerPiece(2,4);
	piece1->setType(2);
	piece1->setTopSide(true);

	//test case 1: just one piece on the board cannot jump
	bool rightAns = false;
	bool ans = false;
	int currentRow = piece1->getRow();
	int currentCol = piece1->getCol();
	ans = gameBoard->canJumpUpRight(currentRow,currentCol);

	if(ans != rightAns){
		ok = false;
		puts("testCanJumpUpRight did not pass test case 1");fflush(stdout);
	}
	else{
		puts("testCanJumpUpRight passed test case 1");fflush(stdout);
	}

	//test case 2: piece is at row = 5 and col = 6
	piece2 = gameBoard->getCheckerPiece(5, 6);
	piece2->setType(1);
	rightAns = false;
	currentRow = piece2->getRow();
	currentCol = piece2->getCol();
	ans = gameBoard->canJumpUpRight(currentRow, currentCol);

	if(ans != rightAns){
		ok = false;
		puts("testCanJumpUpRight did not pass test case 2");fflush(stdout);
	}
	else{
		puts("testCanJumpUpRight passed test case 2");fflush(stdout);
	}

	//test case 3: there is another piece in the space it wants to go to
	piece3 = gameBoard->getCheckerPiece(1, 5); //piece 3 is diagonal to piece1, there is space on the next
	piece3->setType(1);
	piece3->setTopSide(false);

	rightAns = true;
	currentRow = piece1->getRow();
	currentCol = piece1->getCol();
	ans = gameBoard->canJumpUpRight(currentRow, currentCol);
	if(ans != rightAns){
		ok = false;
		puts("testCanJumpUpRight did not pass test case 3");fflush(stdout);
	}
	else{
		puts("testCanJumpUpRight passed test case 3");fflush(stdout);
	}

	//test case 4: piece is at row 1 and col 6 and there is a piece in its diagonal -> cannot
	piece4 = gameBoard->getCheckerPiece(1, 6);
	piece4->setType(2);
	rightAns = false;
	currentRow = piece4->getRow();
	currentCol = piece4->getCol();
	piece5 = gameBoard->getCheckerPiece(0, 7);
	piece5->setType(1);
	ans = gameBoard->canJumpUpRight(currentRow, currentCol);

	if(ans != rightAns){
		ok = false;
		puts("testCanJumpUpRight did not pass test case 4");fflush(stdout);
	}
	else{
		puts("testCanJumpUpRight passed test case 4");fflush(stdout);
	}

	//test case 5: piece cannot capture because there is no available space
	piece6 = gameBoard->getCheckerPiece(1, 5);
	piece6->setType(2);
	rightAns = false;
	currentRow = piece1->getRow();
	currentCol = piece1->getCol();
	piece5 = gameBoard->getCheckerPiece(0, 6);
	piece5->setType(1);
	ans = gameBoard->canJumpUpRight(currentRow, currentCol);

	if(ans != rightAns){
		ok = false;
		puts("testCanJumpUpRight did not pass test case 5");fflush(stdout);
	}
	else{
		puts("testCanJumpUpRight passed test case 5");fflush(stdout);
	}

	delete gameBoard;
	return ok;
}

bool Tests::testCollectMovesTopSide(){
	bool ok = true;

	LList* myLL = new LList();
	Board* gameBoard = new Board();
	gameBoard->setPiecesP((Checker**)malloc(64*sizeof(Checker*)));
	gameBoard->initBoard();
	//for board config
	Checker* topPawnBoard = (Checker*) malloc(sizeof(Checker));
	Checker* topKingBoard = (Checker*) malloc(sizeof(Checker));
	Checker* botPawnBoard = (Checker*) malloc(sizeof(Checker));
	Checker* botKingBoard = (Checker*) malloc(sizeof(Checker));
	topPawnBoard = gameBoard->getCheckerPiece(1, 2);
	topPawnBoard->setTopSide(true);
	topPawnBoard->setType(1);
	topKingBoard = gameBoard->getCheckerPiece(4, 6);
	topKingBoard->setType(2);
	topKingBoard->setTopSide(true);
	botPawnBoard = gameBoard->getCheckerPiece(2, 3);
	botPawnBoard->setType(1);
	botPawnBoard->setTopSide(false);
	botKingBoard = gameBoard->getCheckerPiece(3, 7);
	botKingBoard->setType(2);
	botKingBoard->setTopSide(false);

	//for saving in list
	Checker* topPawn = (Checker*) malloc(sizeof(Checker));
	Checker* topKing = (Checker*) malloc(sizeof(Checker));
	Checker* botPawn = (Checker*) malloc(sizeof(Checker));
	Checker* botKing = (Checker*) malloc(sizeof(Checker));

	topPawn->setCoordinates(1,2);
	topPawn->setType(1);
	topKing->setCoordinates(4,6);
	topKing->setType(2);
	botPawn->setCoordinates(2,3);
	botPawn->setType(1);
	botKing->setCoordinates(3,7);
	botKing->setType(2);

	myLL->savePayload(topKing);
	myLL->savePayload(topPawn);

	myLL->savePayload2(botPawn);
	myLL->savePayload2(botKing);

	//topKing cannot take botKing because it is at the edge -> canMoveDownLeft, canMoveDownRight, canMoveUpleft
	//topPawn can take botPawn -> canJumpBotRight

	gameBoard->displayBoard();
	gameBoard->collectMovesTopSide(myLL);
	LLNode3* moveList = myLL->getMoveList();


	//test case 1: moveList should not be empty
	if(myLL->isEmpty3()){
		ok = false;
		puts("testCollectMovesTopSide did not pass test case 1");fflush(stdout);
	}
	else{
		puts("testCollectMovesTopSide passed test case 1");fflush(stdout);
	}

	//test case 2: moveList should have 4 stuff in it
	int accum = 0;
	while(moveList->next){
		accum++;
		moveList = moveList->next;
	}
	//now at the end
	accum++;
	int rightAns = 4;
	if(accum != rightAns){
		ok = false;
		puts("testCollectMovesTopSide did not pass test case 2");fflush(stdout);
	}
	else{
		puts("testCollectMovesTopSide passed test case 2");fflush(stdout);
	}


	delete myLL;
	delete gameBoard;
	return ok;
}

bool Tests::testCollectMovesBotSide(){
	bool ok = true;

	LList* myLL = new LList();
	Board* gameBoard = new Board();
	gameBoard->setPiecesP((Checker**)malloc(64*sizeof(Checker*)));
	gameBoard->initBoard();
	//for board config
	Checker* topPawnBoard = (Checker*) malloc(sizeof(Checker));
	Checker* topKingBoard = (Checker*) malloc(sizeof(Checker));
	Checker* botPawnBoard = (Checker*) malloc(sizeof(Checker));
	Checker* botKingBoard = (Checker*) malloc(sizeof(Checker));
	topPawnBoard = gameBoard->getCheckerPiece(0, 2);
	topPawnBoard->setTopSide(true);
	topPawnBoard->setType(1);
	topKingBoard = gameBoard->getCheckerPiece(4, 6);
	topKingBoard->setType(2);
	topKingBoard->setTopSide(true);
	botPawnBoard = gameBoard->getCheckerPiece(2, 3);
	botPawnBoard->setType(1);
	botPawnBoard->setTopSide(false);
	botKingBoard = gameBoard->getCheckerPiece(3, 7);
	botKingBoard->setType(2);
	botKingBoard->setTopSide(false);

	//for saving in list
	Checker* topPawn = (Checker*) malloc(sizeof(Checker));
	Checker* topKing = (Checker*) malloc(sizeof(Checker));
	Checker* botPawn = (Checker*) malloc(sizeof(Checker));
	Checker* botKing = (Checker*) malloc(sizeof(Checker));

	topPawn->setCoordinates(0,2);
	topPawn->setType(1);
	topKing->setCoordinates(4,6);
	topKing->setType(2);
	botPawn->setCoordinates(2,3);
	botPawn->setType(1);
	botPawn->setTopSide(false);
	botKing->setCoordinates(3,7);
	botKing->setType(2);
	botKing->setTopSide(false);

	myLL->savePayload(topPawn);
	myLL->savePayload(topKing);

	myLL->savePayload2(botKing);
	myLL->savePayload2(botPawn);

	//botKing can take topKing-> canJumpDownLeft
	//botPawn cannot take topPawn -> canMoveUpLeft, canMoveUpRight

	gameBoard->displayBoard();
	gameBoard->collectMovesBotSide(myLL);
	LLNode3* moveList = myLL->getMoveList();


	//test case 1: moveList should not be empty
	if(myLL->isEmpty3()){
		ok = false;
		puts("testCollectMovesBotSide did not pass test case 1");fflush(stdout);
	}
	else{
		puts("testCollectMovesBotSide passed test case 1");fflush(stdout);
	}


	//test case 2: moveList should have 4 stuff in it
	int accum = 0;
	while(moveList->next){
		accum++;
		moveList = moveList->next;
	}
	//now at the end
	accum++;

	int rightAns = 3;
	if(accum != rightAns){
		ok = false;
		puts("testCollectMovesBotSide did not pass test case 2");fflush(stdout);
	}
	else{
		puts("testCollectMovesBotSide passed test case 2");fflush(stdout);
	}
	delete myLL;
	delete gameBoard;
	return ok;

}

bool Tests::testPromotionTopSide(){
	bool ok = true;
	LList* myLL = new LList();
	Board* gameBoard = new Board();
	gameBoard->setPiecesP((Checker**)malloc(64*sizeof(Checker*)));
	gameBoard->initBoard();
	//board config
	Checker* topPawnBoard = new Checker();
	topPawnBoard = gameBoard->getCheckerPiece(7, 1);
	topPawnBoard->setType(1);

	//for LL
	Checker* topPawn = new Checker();
	topPawn->setCoordinates(7,1);
	topPawn->setType(1);
	topPawn->setTopSide(true);
	myLL->savePayload(topPawn);

	gameBoard->promotionTopSide(7, 1, myLL);
	LLNode* pieces = myLL->getTopSide();


	//test case 1: topSideList should not be empty
	if(myLL->isEmpty()){
		ok = false;
		puts("testPromotionTopSide did not pass test case 1");fflush(stdout);
	}
	else{
		puts("testPromotionTopSide passed test case 1");fflush(stdout);
	}

	//test case 2: topSideList should not have a king
	if(pieces->payP->getType() != 2){
		ok = false;
		puts("testPromotionTopSide did not pass test case 2");fflush(stdout);
	}
	else{
		puts("testPromotionTopSide passed test case 2");fflush(stdout);
	}

	//test case 3: topSideList should only have 1
	int accum = 0;
	while(pieces->next){
		accum++;
		pieces = pieces->next;
	}
	//now at the end
	accum++;

	if(accum != 1){
		ok = false;
		puts("testPromotionTopSide did not pass test case 3");fflush(stdout);
	}
	else{
		puts("testPromotionTopSide passed test case 3");fflush(stdout);
	}

	delete gameBoard;
	delete myLL;

	return ok;
}

bool Tests::testPromotionBotSide(){
	bool ok = true;
	LList* myLL = new LList();
	Board* gameBoard = new Board();
	gameBoard->setPiecesP((Checker**)malloc(64*sizeof(Checker*)));
	gameBoard->initBoard();
	//board config
	Checker* botPawnBoard = new Checker();
	botPawnBoard = gameBoard->getCheckerPiece(0, 1);
	botPawnBoard->setType(1);
	botPawnBoard->setTopSide(false);

	//for LL
	Checker* botPawn = new Checker();
	botPawn->setCoordinates(0,1);
	botPawn->setType(1);
	botPawn->setTopSide(false);
	myLL->savePayload2(botPawn);

	gameBoard->promotionBotSide(0, 1, myLL);
	LLNode2* pieces = myLL->getBotSide();


	//test case 1: botSideList should not be empty
	if(myLL->isEmpty2()){
		ok = false;
		puts("testPromotionBotSide did not pass test case 1");fflush(stdout);
	}
	else{
		puts("testPromotionBotSide passed test case 1");fflush(stdout);
	}

	//test case 2: botSideList should have a king

	if(pieces->payP->getType() != 2){
		ok = false;
		puts("testPromotionBotSide did not pass test case 2");fflush(stdout);
	}
	else{
		puts("testPromotionBotSide passed test case 2");fflush(stdout);
	}

	//test case 3: botSideList should only have 1
	int accum = 0;
	while(pieces->next){
		accum++;
		pieces = pieces->next;
	}
	//now at the end
	accum++;

	if(accum != 1){
		ok = false;
		puts("testPromotionBotSide did not pass test case 3");fflush(stdout);
	}
	else{
		puts("testPromotionBotSide passed test case 3");fflush(stdout);
	}

	return ok;
}

bool Tests::testPrintMoveList(){
	bool ok = true;

	LList* myLL = new LList();
	Move* myMove = (Move*)malloc(sizeof(Move));
	myMove->row = 1;
	myMove->col = 2;
	myMove->didCapture = false;
	myMove->capturedCol = -1;
	myMove->capturedRow = -1;
	myMove->nextCol = 3;
	myMove->nextRow = 2;

	Move* myMove2 = (Move*)malloc(sizeof(Move));
	myMove2->row = 5;
	myMove2->col = 3;
	myMove2->didCapture = true;
	myMove2->capturedCol = 2;
	myMove2->capturedRow = 4;
	myMove2->nextRow = 3;
	myMove2->nextCol = 1;

	myLL->savePayload3(myMove);
	myLL->savePayload3(myMove2);

	myLL->printMoveList();

	//manual
	ok = true;
	if(ok){
		puts("testPrintMoveList passed");fflush(stdout);
	}
	else{
		puts("printMoveList did not print anything");fflush(stdout);
		puts("testPrintMoveList did not pass");fflush(stdout);
	}

	delete myLL;
	return ok;
}

bool Tests::testMakeRandMoveTopSide(){
	bool ok = true;

	LList* myLL = new LList();
	Move* myMove = (Move*)malloc(sizeof(Move));
	myMove->row = 1;
	myMove->col = 2;
	myMove->didCapture = false;
	myMove->capturedCol = -1;
	myMove->capturedRow = -1;
	myMove->nextCol = 3;
	myMove->nextRow = 2;

	Move* myMove2 = (Move*)malloc(sizeof(Move));
	myMove2->row = 5;
	myMove2->col = 3;
	myMove2->didCapture = true;
	myMove2->capturedCol = 2;
	myMove2->capturedRow = 4;
	myMove2->nextRow = 3;
	myMove2->nextCol = 1;

	myLL->savePayload3(myMove);
	myLL->savePayload3(myMove2);

	Move* chosenMove = (Move*) malloc(sizeof(Move));
	chosenMove = myLL->makeRandomMoveTopSide();

	//tests if the chosen move is the captured one
	if(chosenMove == myMove2){
		puts("testMakeRandMoveTopSide passed");fflush(stdout);
	}
	else{
		ok = false;
		puts("testMakeRandMoveTopSide did not pass");fflush(stdout);
	}

	delete myLL;
	return ok;
}

bool Tests::testUserChooseMoveBotSide(){
	bool ok = true;

	LList* myLL = new LList();
	Move* myMove = (Move*)malloc(sizeof(Move));
	myMove->row = 1;
	myMove->col = 2;
	myMove->didCapture = false;
	myMove->capturedCol = -1;
	myMove->capturedRow = -1;
	myMove->nextCol = 3;
	myMove->nextRow = 2;

	Move* myMove2 = (Move*)malloc(sizeof(Move));
	myMove2->row = 5;
	myMove2->col = 3;
	myMove2->didCapture = true;
	myMove2->capturedCol = 2;
	myMove2->capturedRow = 4;
	myMove2->nextRow = 3;
	myMove2->nextCol = 1;

	myLL->savePayload3(myMove);
	myLL->savePayload3(myMove2);

	Move* chosenMove = (Move*) malloc(sizeof(Move));


	//test case 1: the chosen move was the first one
	chosenMove = myLL->userChooseMoveBotSide(1);
	if(chosenMove != myMove){
		ok = false;
		puts("testUserChooseMoveBotSide did not pass test case 1");fflush(stdout);
	}
	else{
		puts("testUserChooseMoveBotSide passed test case 1");fflush(stdout);
	}

	//test case 2: the chosen move was not the first one (second one)
	chosenMove = myLL->userChooseMoveBotSide(2);
	if(chosenMove != myMove2){
		ok = false;
		puts("testUserChooseMoveBotSide did not pass test case 2");fflush(stdout);
	}
	else{
		puts("testUserChooseMoveBotSide passed test case 2");fflush(stdout);
	}


	delete myLL;
	return ok;
}

bool Tests::testDequeueAllMoves(){
	bool ok = true;

	LList* myLL = new LList();
	Move* myMove = (Move*)malloc(sizeof(Move));
	myMove->row = 1;
	myMove->col = 2;
	myMove->didCapture = false;
	myMove->capturedCol = -1;
	myMove->capturedRow = -1;
	myMove->nextCol = 3;
	myMove->nextRow = 2;

	Move* myMove2 = (Move*)malloc(sizeof(Move));
	myMove2->row = 5;
	myMove2->col = 3;
	myMove2->didCapture = true;
	myMove2->capturedCol = 2;
	myMove2->capturedRow = 4;
	myMove2->nextRow = 3;
	myMove2->nextCol = 1;

	myLL->savePayload3(myMove);
	myLL->savePayload3(myMove2); //should have 2 moves


	myLL->dequeueAllMoves();
	//test case 1: 2 moves in list and new move list should be empty
	if(!(myLL->isEmpty3())){
		ok = false;
		puts("testDequeueAllMoves did not pass test case 1");fflush(stdout);
	}
	else{
		puts("testDequeueAllMoves passed test case 1");fflush(stdout);
	}

	//test case 2: the list is already empty
	myLL->dequeueAllMoves();
	bool rightAns = true;
	bool ans = myLL->isEmpty3();
	if(rightAns != ans){
		ok = false;
		puts("testDequeueAllMoves did not pass test case 2");fflush(stdout);
	}
	else{
		puts("testDequeueAllMoves passed test case 2");fflush(stdout);
	}

	return ok;
}

bool Tests::testUpdateBoard(){
	bool ok = true;

	LList* myLL = new LList();
	Board* board = new Board();
	board->setPiecesP((Checker**)malloc(64*sizeof(Checker*)));
	board->initBoard();

	Checker* pieceKingTop = board->getCheckerPiece(2, 4);
	pieceKingTop->setType(2);
	pieceKingTop->setTopSide(true);
	Checker* pieceKingTopForList = new Checker();
	pieceKingTopForList->setCoordinates(2,4);
	pieceKingTopForList->setType(2);
	pieceKingTopForList->setTopSide(true);
	myLL->savePayload(pieceKingTopForList);


	Checker* pieceBot = board->getCheckerPiece(1, 3);
	pieceBot->setType(1);
	pieceBot->setTopSide(false);
	Checker* pieceBotForList = new Checker();
	pieceBotForList->setCoordinates(1,3);
	pieceBotForList->setTopSide(false);
	pieceBotForList->setType(1);
	myLL->savePayload2(pieceBotForList);

	Checker* pieceTop = board->getCheckerPiece(1, 1);
	pieceTop->setType(1);
	pieceTop->setTopSide(true);
	Checker* pieceTopForList = new Checker();
	pieceTopForList->setCoordinates(1,1);
	pieceTopForList->setType(1);
	pieceTopForList->setTopSide(true);
	myLL->savePayload(pieceTopForList);

	Checker* pieceBot2 = board->getCheckerPiece(2,2);
	pieceBot2->setType(1);
	pieceBot2->setTopSide(false);
	Checker* pieceBot2ForList = new Checker();
	pieceBot2ForList->setCoordinates(2,2);
	pieceBot2ForList->setTopSide(false);
	pieceBot2ForList->setType(1);
	myLL->savePayload2(pieceBot2ForList);

	Move* myMove = (Move*)malloc(sizeof(Move));
	myMove->row = 2;
	myMove->col = 4;
	myMove->didCapture = true;
	myMove->capturedCol = 3;
	myMove->capturedRow = 1;
	myMove->nextCol = 2;
	myMove->nextRow = 0;

	//before update
	board->displayBoard();
	//test case 1: no promotion
	board->updateBoard(myMove, myLL);
	board->displayBoard();


	//manual
	ok = true;
	if(ok){
		puts("testUpdateBoard passed test case 1");fflush(stdout);
	}
	else{
		puts("testUpdateBoard did not pass test case 1");fflush(stdout);
	}

	//test case 2: there is promotion

	Move* myMove2 = (Move*)malloc(sizeof(Move));
	myMove2->row = 2;
	myMove2->col = 2;
	myMove2->didCapture = true;
	myMove2->capturedCol = 1;
	myMove2->capturedRow = 1;
	myMove2->nextCol = 0;
	myMove2->nextRow = 0;

	board->displayBoard();
	board->updateBoard(myMove2, myLL);
	board->displayBoard();

	ok = true;
	if(ok){
		puts("testUpdateBoard passed test case 2");fflush(stdout);
	}
	else{
		puts("testUpdateBoard did not pass test case 2");fflush(stdout);
	}

	return ok;
}

bool Tests::testDisplayBoardInFile(){
	bool ok  = false;

	FILE* fp = fopen("outputFileForTests.txt","w");
	Board* board = new Board();
	Production* prod = new Production();
	board->setPiecesP((Checker**)malloc(64*sizeof(Checker*)));
	board->initBoard();

	Checker* pieceKingTop = board->getCheckerPiece(2, 4);
	pieceKingTop->setType(2);
	pieceKingTop->setTopSide(true);

	Checker* pieceBot = board->getCheckerPiece(1, 3);
	pieceBot->setType(1);
	pieceBot->setTopSide(false);

	board->displayBoard();
	prod->displayBoardInFile(fp, board);

	//manual
	ok = true;
	if(ok){
		puts("testDisplayBoardInFile passed");fflush(stdout);
	}
	else{
		puts("testDisplayBoardInFile did not pass");fflush(stdout);
	}

	delete prod;
	delete board;

	fclose(fp);
	return ok;
}

bool Tests::testPrintMoveListInFile(){
	bool ok = false;

	FILE* fp = fopen("outputFileForTests.txt","w");
	Board* board = new Board();
	LList* myLL = new LList();
	Production* prod = new Production();
	board->setPiecesP((Checker**)malloc(64*sizeof(Checker*)));
	board->initBoard();

	Checker* pieceKingTop = board->getCheckerPiece(2, 4);
	pieceKingTop->setType(2);
	pieceKingTop->setTopSide(true);
	Checker* pieceKingTopForList = new Checker();
	pieceKingTopForList->setCoordinates(2,4);
	pieceKingTopForList->setType(2);
	pieceKingTopForList->setTopSide(true);
	myLL->savePayload(pieceKingTopForList);


	Checker* pieceBot = board->getCheckerPiece(1, 3);
	pieceBot->setType(1);
	pieceBot->setTopSide(false);
	Checker* pieceBotForList = new Checker();
	pieceBotForList->setCoordinates(1,3);
	pieceBotForList->setTopSide(false);
	pieceBotForList->setType(1);
	myLL->savePayload2(pieceBotForList);

	Checker* pieceTop = board->getCheckerPiece(1, 1);
	pieceTop->setType(1);
	pieceTop->setTopSide(true);
	Checker* pieceTopForList = new Checker();
	pieceTopForList->setCoordinates(1,1);
	pieceTopForList->setType(1);
	pieceTopForList->setTopSide(true);
	myLL->savePayload(pieceTopForList);

	Checker* pieceBot2 = board->getCheckerPiece(2,2);
	pieceBot2->setType(1);
	pieceBot2->setTopSide(false);
	Checker* pieceBot2ForList = new Checker();
	pieceBot2ForList->setCoordinates(2,2);
	pieceBot2ForList->setTopSide(false);
	pieceBot2ForList->setType(1);
	myLL->savePayload2(pieceBot2ForList);

	Move* myMove = (Move*)malloc(sizeof(Move));
	myMove->row = 2;
	myMove->col = 4;
	myMove->didCapture = true;
	myMove->capturedCol = 3;
	myMove->capturedRow = 1;
	myMove->nextCol = 2;
	myMove->nextRow = 0;

	myLL->savePayload3(myMove);

	myLL->printMoveList();
	prod->printMoveListInFile(fp, board, myLL);

	//manual
	ok = true;
	if(ok){
		puts("testPrintMoveListInFile passed");fflush(stdout);
	}
	else{
		puts("testPringMoveListInFile did not pass");fflush(stdout);
	}

	delete myLL;
	delete prod;
	delete board;

	fclose(fp);
	return ok;
}

bool Tests::testSetGetPiecesP(){
	bool ok = true;

	Board* board = new Board();
	Checker** pieceP = (Checker**)malloc(64*sizeof(Checker*));
	board->setPiecesP(pieceP);

	bool rightAns = true;
	bool ans = sizeof(board->getPiecesP()) == sizeof(pieceP);

	if(rightAns != ans){
		puts("testSetGetPiecesP did not pass test case 1");fflush(stdout);
		ok  = false;
	}
	else{
		puts("testSetGetPiecesP passed test case 1");fflush(stdout);
	}

	if(pieceP != board->getPiecesP()){
		puts("testSetGetPiecesP did not pass test case 2");fflush(stdout);
		ok  = false;
	}
	else{
		puts("testSetGetPiecesP passed test case 2");fflush(stdout);
	}

	delete board;

	return ok;
}
bool Tests::testGetCheckerPieceGetRowGetCol(){
	bool ok = true;
	Board* board = new Board();
	Checker** pieceP = (Checker**)malloc(64*sizeof(Checker*));
	board->setPiecesP(pieceP);
	board->initBoard();

	Checker* piece = board->getCheckerPiece(1, 0);
	if((piece->getRow() != 1 || piece->getCol() != 0)){
		puts("testGetCheckerPieceGetRowGetCol did not pass");fflush(stdout);
		ok = false;
	}
	else{
		puts("testGetCheckerPieceGetRowGetCol passed");fflush(stdout);
	}
	delete board;
	return ok;
}

bool Tests::testSetGetType(){
	bool ok = true;

	Board* board = new Board();
	Checker** pieceP = (Checker**)malloc(64*sizeof(Checker*));
	board->setPiecesP(pieceP);
	board->initBoard();

	Checker* piece = board->getCheckerPiece(0, 0);
	piece->setType(1); //pawn

	if(piece->getType() != 1){
		puts("testSetGetType did not pass");fflush(stdout);
		ok = false;
	}
	else{
		puts("testSetGetType passed");fflush(stdout);
	}
	delete board;
	return ok;
}
bool Tests::testSetGetSide(){
	bool ok = true;
	Board* board = new Board();
	Checker** pieceP = (Checker**)malloc(64*sizeof(Checker*));
	board->setPiecesP(pieceP);
	board->initBoard();

	Checker* piece = board->getCheckerPiece(0, 0);
	piece->setTopSide(false);//bot side

	if(piece->getSide()){
		puts("testSetGetSide did not pass");fflush(stdout);
		ok = false;
	}
	else{
		puts("testSetGetSide passed");fflush(stdout);
	}
	delete board;

	return ok;
}
bool Tests::testSetGetCoordinates(){
	bool ok = true;

	Checker* piece = new Checker();
	piece->setCoordinates(1,0);

	if(piece->getRow() != 1 || piece->getCol() != 0){
		puts("testSetGetCoordinates did not pass");fflush(stdout);
		ok = false;
	}
	else{
		puts("testSetGetCoordinates passed");fflush(stdout);
	}

	delete piece;
	return ok;
}
bool Tests::testRemoveFromList(){
	bool ok = true;

	//cases:
	//1 list is empty:return same list
	//2 list is of length one, and item is present: return empty list
	//3 list is of length one, and item is not present: return same list
	//4 list is longer than one, item is present, at first location: return list starting at second element
	//5 list is longer than one, item is present, not at first location: return list with item removed
	//6 list is longer than one, item is not present: return same list

	Payload* pay1 = (Payload*) malloc(sizeof(Checker));
	pay1->setCoordinates(0,0);
	LList* list = new LList();
	int ans = 0;
	int accum3 = 0;
	int accum4 = 0;
	int accum5 = 0;
	list->removeFromList(pay1);

	LLNode* myList = list->getTopSide();
	Payload* check = myList->payP;

	if(!(list->isEmpty()) || (check != (Payload*)0))
	{
		ok = false;

	}
	printf("testRemove case 1 with %d\n", ok); fflush(stdout);
	delete list;

	//this is case2
	LList* list1 = new LList();
	list1->savePayload(pay1);
	list1->removeFromList(pay1);


	myList = list->getTopSide();

	check = myList->payP;



	if(!(list->isEmpty()) || (check != (Payload*)0))
	{
		ok = false;

	}
	printf("testRemove case 2 with %d\n", ok); fflush(stdout);
	delete list1;

	//now case 3
	LList* list2 = new LList();
	list2->savePayload(pay1);
	Payload* pay3 = (Payload*) malloc(sizeof(Checker));
	pay3->setCoordinates(1,0);

	list2->removeFromList(pay3);

	myList = list2->getTopSide();


	if(list2->isEmpty())//this is only a partial check for list unchanged
	{
		ok = false;

	}
	printf("testRemove case 3 with %d\n", ok); fflush(stdout);
	delete list2;
	//now case 4
	LList* list3 = new LList();
	pay1 = (Payload*) malloc(sizeof(Checker));
	pay1->setCoordinates(2,0);
	list3->savePayload(pay1);
	pay3 = (Payload*) malloc(sizeof(Checker));
	pay3->setCoordinates(1,1);
	list3->savePayload(pay3);

	ans = 1;
	list3->removeFromList(pay1);

	LLNode* myList2 = list3->getTopSide();

	while(myList2->next){
		accum3++;
		myList2 = myList2->next;
	}
	accum3++;

	if(ans != accum3)
	{
		ok = false;

	}

	printf("testRemove case 4 with %d\n", ok); fflush(stdout);
	delete list3;
	//now case 5
	LList* list4 = new LList();
	pay1 = (Payload*) malloc(sizeof(Checker));
	pay1->setCoordinates(3,2);
	list4->savePayload(pay1);
	pay3 = (Payload*) malloc(sizeof(Checker));
	pay3->setCoordinates(3,3);
	list4->savePayload(pay3);

	ans = 1;
	list4->removeFromList(pay3);

	LLNode* myList3 = list4->getTopSide();

	while(myList3->next){
		accum4++;
		myList3 = myList3->next;
	}
	accum4++;


	if((ans != accum4))
	{
		ok = false;

	}

	printf("testRemove case 5 with %d\n", ok); fflush(stdout);
	delete list4;
	//now case 6
	LList* list5 = new LList();
	pay1 = (Payload*) malloc(sizeof(Checker));
	pay1->setCoordinates(1,3);
	list5->savePayload(pay1);
	pay3 = (Payload*) malloc(sizeof(Checker));
	pay3->setCoordinates(4,5);
	list5->savePayload(pay3);
	Payload* another = (Payload*) malloc(sizeof(Checker));
	another->setCoordinates(6,6);
	ans = 2;


	list5->removeFromList(another);

	LLNode* myList4 = list5->getTopSide();

	while(myList4->next){
		accum5++;
		myList4 = myList4->next;
	}
	accum5++;

	if((ans != accum5))
	{
		ok = false;

	}
	printf("testRemove case 6 with %d\n", ok); fflush(stdout);
	delete list5;
	return ok;
}

