/*
 * Checker.cpp
 *
 *  Created on: Mar 9, 2021
 *      Author: Andrew Hariyanto
 */

#include "Checker.h"

Checker::Checker() {
	// TODO Auto-generated constructor stub

}

Checker::~Checker() {
	// TODO Auto-generated destructor stub
}

int Checker::getType(){
	if(isKing && !isPawn && !isEmpty){
		return 2;
	}
	else if(isPawn && !isKing && !isEmpty){
		return 1;
	}
	else{
		return 0;
	}
}
void Checker::setType(int key){
	if(key == 2){
		this->isEmpty = false;
		this->isPawn = false;
		this->isKing = true;
	}
	else if(key == 1){
		this->isEmpty = false;
		this->isPawn = true;
		this->isKing = false;
	}
	else{
		this->isEmpty = true;
		this->isPawn = false;
		this->isKing = false;
	}
}

void Checker::setCoordinates(int row, int col){
	this->row = row;
	this->col = col;
}
int Checker::getRow(){
	return this->row;
}
int Checker::getCol(){
	return this->col;
}


void Checker::setTopSide(bool isTop){
	topSide = isTop;
}
bool Checker::getSide(){
	return topSide;
}


