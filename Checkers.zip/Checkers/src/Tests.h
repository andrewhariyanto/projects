/*
 * Tests.h
 *
 *  Created on: Mar 9, 2021
 *      Author: Andrew Hariyanto
 */

#ifndef TESTS_H_
#define TESTS_H_
#include "Production.h"
#include "LList.h"


class Tests {
public:
	Tests();
	virtual ~Tests();
	bool tests();

private:
	bool testReadFile();
	bool testEnqueue();
	bool testInitAndDisplayBoard();
	bool testTesting();
	bool testIsEmpty();
	bool testMakeLList();
	bool testRemoveFromList();
	bool testGetTopSidePieces();
	bool testGetBotSidePieces();
	bool testGetMoveList();
	bool testCanMoveDownLeft();
	bool testCanMoveDownRight();
	bool testCanMoveUpLeft();
	bool testCanMoveUpRight();
	bool testCanJumpDownLeft();
	bool testCanJumpDownRight();
	bool testCanJumpUpLeft();
	bool testCanJumpUpRight();
	bool testCollectMovesTopSide();
	bool testCollectMovesBotSide();
	bool testPromotionTopSide();
	bool testPromotionBotSide();
	bool testPrintMoveList();
	bool testMakeRandMoveTopSide();
	bool testUserChooseMoveBotSide();
	bool testDequeueAllMoves();
	bool testUpdateBoard();
	bool testDisplayBoardInFile();
	bool testPrintMoveListInFile();
	bool testSetGetPiecesP();
	bool testGetCheckerPieceGetRowGetCol();
	bool testSetGetType();
	bool testSetGetSide();
	bool testSetGetCoordinates();

};

#endif /* TESTS_H_ */
