/*
 * Board.h
 *
 *  Created on: Mar 9, 2021
 *      Author: Andrew Hariyanto
 */

#ifndef SRC_BOARD_H_
#define SRC_BOARD_H_

#include "Checker.h"
#include "LList.h"
#include <stdio.h>
#include <stdbool.h>

class Board {
public:
	Board();
	virtual ~Board();
	void initBoard();
	void setPiecesP(Checker**);
	Checker** getPiecesP();
	Checker* getCheckerPiece(int, int);
	void displayBoard();
	bool canMoveDownLeft(int, int);
	bool canMoveDownRight(int, int);
	bool canMoveUpLeft(int, int);
	bool canMoveUpRight(int, int);
	bool canJumpDownLeft(int, int);
	bool canJumpDownRight(int, int);
	bool canJumpUpLeft(int, int);
	bool canJumpUpRight(int, int);
	void promotionTopSide(int, int, LList*);
	void promotionBotSide(int, int, LList*);
	void collectMovesTopSide(LList*);
	void collectMovesBotSide(LList*);
	void updateBoard(Move*,LList*);

private:
	Checker** piecesP;
};

#endif /* SRC_BOARD_H_ */
