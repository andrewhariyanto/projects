/*
 * Production.cpp
 *
 *  Created on: Mar 9, 2021
 *      Author: Andrew Hariyanto
 */

#include "Production.h"
#include <stdbool.h>

Production::Production() {
	// TODO Auto-generated constructor stub

}

Production::~Production() {
	// TODO Auto-generated destructor stub
}

bool Production::prod(int argc, char* argv[])
{
	printf("Starting Production\n");
	bool answer = false;

	if(argc <=1) //no interesting information
	{
		puts("Didn't find any arguments.");
		fflush(stdout);
		answer = false;
	}
	else //there is interesting information
	{
		printf("Found %d interesting arguments.\n", argc-1);
		fflush(stdout);
		char filename[FILENAMELENGTHALLOWANCE];
		char* eptr=(char*) malloc(sizeof(char*));
		long aL=-1L;

		int maxMoves;
		bool topFirst;

		for(int i = 1; i<argc; i++) //don't want to read argv[0]
				{//argv[i] is a string

					switch(i)
					{
					case 1:
						//this is filename
						printf("The length of the filename is %d.\n",strlen(argv[i]));
						printf("The proposed filename is %s.\n", argv[i]);
						if(strlen(argv[i])>=FILENAMELENGTHALLOWANCE)
						{
							puts("Filename is too long.");
							fflush(stdout);
							answer = false;
						}
						else
						{
							strcpy(filename, argv[i]);
							printf("Filename was %s.\n", filename);
							fflush(stdout);
						}
						break;
					case 2:
						//this is maximum number of moves

						aL = strtol(argv[i], &eptr, 10);
						maxMoves = (int) aL;
						printf("Number of moves is %d\n",maxMoves);fflush(stdout);
						break;
					case 3:
						//this is who goes first either 1 or 0; 1 is top first

						aL = strtol(argv[i], &eptr, 10);
						topFirst = (int) aL;
						printf("Top goes first is %d\n",topFirst);fflush(stdout);
						break;

					default:
						puts("Unexpected argument count."); fflush(stdout);
						answer = false;
						break;
					}//end of switch
				}//end of for loop on argument count
				puts("after reading arguments"); fflush(stdout);

		//we'll want to read the file
		Board* checkerBoard = (Board*) malloc(sizeof(Board));

		puts("Before read file"); fflush(stdout);
		LList* myLL = new LList();

		answer = this->readFile(filename, checkerBoard,myLL);

		puts("Back from read file"); fflush(stdout);



		//TODO
		//1. display the board
		//2. check who goes first
		//3. depending on who goes first, collect the moves
		//4. if no moves then end the game with no winner
		//5. if there are moves, then print the selection and make a selection
		//6. update the board
		//7. dequeue all the moves in the list

		checkerBoard->displayBoard();

		FILE* fOP = fopen("outputFile.txt", "w");//write on file

		displayBoardInFile(fOP, checkerBoard);
		fprintf(fOP, "\n");fflush(fOP);


		bool done = false;
		int moveAccum = 0;

		if(topFirst){
			while(!done){
				fprintf(fOP, "Move %d\n", moveAccum+1);fflush(fOP);
				fprintf(fOP, "Now top side's turn\n");fflush(fOP);

				puts("now top side's turn");fflush(stdout);
				checkerBoard->collectMovesTopSide(myLL);
				if(myLL->isEmpty3()){
					fprintf(fOP, "Top has no moves available... game ending\n");fflush(fOP);
					puts("Top has no moves available... game ending");fflush(stdout);
					done = true;
				}
				else{
					myLL->printMoveList();
					printMoveListInFile(fOP, checkerBoard, myLL);

					Move* chosenMove = myLL->makeRandomMoveTopSide();
					checkerBoard->updateBoard(chosenMove, myLL);
					myLL->dequeueAllMoves();
					fprintf(fOP, "Computer made move %d\n", chosenMove->moveNum);fflush(fOP);

					fprintf(fOP, "\n");fflush(fOP);
					puts("top side done");fflush(stdout);

					checkerBoard->displayBoard();
					displayBoardInFile(fOP, checkerBoard);
					fprintf(fOP, "\n");fflush(fOP);

					puts("now bot side's turn");fflush(stdout);
					fprintf(fOP, "Now bot side's turn\n");fflush(fOP);

					checkerBoard->collectMovesBotSide(myLL);

					if(myLL->isEmpty3()){
						puts("Bot has no moves available... game ending");fflush(stdout);
						fprintf(fOP, "Bot has no moves available... game ending\n");fflush(fOP);
						done = true;
					}
					else{
						myLL->printMoveList();
						printMoveListInFile(fOP, checkerBoard, myLL);
						int userMove = -1;
						printf("Please choose your move\n");fflush(stdout);
						printf("Pick a number: ");fflush(stdout);
						scanf("%d", &userMove);

						fprintf(fOP, "User chose move %d\n", userMove);fflush(fOP);
						Move* chosenMove = myLL->userChooseMoveBotSide(userMove);
						checkerBoard->updateBoard(chosenMove, myLL);
						myLL->dequeueAllMoves();

						puts("bot side done");fflush(stdout);
						fprintf(fOP, "\n");fflush(fOP);

						checkerBoard->displayBoard();
						displayBoardInFile(fOP, checkerBoard);
						fprintf(fOP, "\n");fflush(fOP);

						moveAccum++;
					}
				}

				if(moveAccum == maxMoves){
					puts("max moves has been reached... game ending");fflush(stdout);
					fprintf(fOP, "Max moves has been reached... game ending");fflush(stdout);
					done = true;
				}

			}
		}
		else{
			while(!done){
				fprintf(fOP, "Move %d\n", moveAccum+1);fflush(fOP);

				puts("now bot side's turn");fflush(stdout);
				fprintf(fOP, "Now bot side's turn\n");fflush(fOP);

				checkerBoard->collectMovesBotSide(myLL);

				if(myLL->isEmpty3()){
					puts("Bot has not more moves available... game ending");fflush(stdout);
					fprintf(fOP, "Bot has no moves available... game ending\n");fflush(fOP);
					done = true;
				}
				else{
					myLL->printMoveList();
					printMoveListInFile(fOP, checkerBoard, myLL);

					int userMove = - 1;
					printf("Please choose your move\n");fflush(stdout);
					printf("Pick a number: ");fflush(stdout);
					scanf("%d", &userMove);

					Move* chosenMove = myLL->userChooseMoveBotSide(userMove);
					fprintf(fOP,"User chose %d\n",userMove);
					checkerBoard->updateBoard(chosenMove, myLL);
					myLL->dequeueAllMoves();
					puts("bot side done");fflush(stdout);
					fprintf(fOP, "\n");fflush(fOP);
					checkerBoard->displayBoard();
					displayBoardInFile(fOP, checkerBoard);
					fprintf(fOP, "\n");fflush(fOP);

					puts("now top side's turn");fflush(stdout);
					fprintf(fOP, "Now top side's turn\n");fflush(fOP);

					checkerBoard->collectMovesTopSide(myLL);

					if(myLL->isEmpty3()){
						puts("Top has no moves available... game ending");fflush(stdout);
						fprintf(fOP, "Top has no moves available... game ending\n");fflush(fOP);
						done = true;
					}
					else{
						myLL->printMoveList();
						printMoveListInFile(fOP, checkerBoard, myLL);

						Move* chosenMove = myLL->makeRandomMoveTopSide();
						checkerBoard->updateBoard(chosenMove, myLL);
						myLL->dequeueAllMoves();
						fprintf(fOP, "Computer made move %d\n", chosenMove->moveNum);fflush(fOP);

						puts("top side done");fflush(stdout);
						fprintf(fOP, "\n");fflush(fOP);

						checkerBoard->displayBoard();
						displayBoardInFile(fOP, checkerBoard);
						fprintf(fOP, "\n");fflush(fOP);

						moveAccum++;
					}

					if(moveAccum == maxMoves){
						puts("max moves has been reached... game ending");fflush(stdout);
						fprintf(fOP,"Max moves has been reached... game ending");fflush(fOP);
						done = true;
					}
				}
			}
		}
		fclose(fOP);
	}
	return answer;
}

bool Production::readFile(char* filename, Board* board, LList* list)
{
	bool ok = false;
	//the file tells how many rooms there are
	FILE* fp = fopen(filename, "r"); //read the file

	if (fp == NULL)
	{
		puts("Error! opening file");

	}
	else
	{
		board->setPiecesP((Checker**) malloc(64*sizeof(Checker*)));

		puts("Before init Checker Board"); fflush(stdout);
		board->initBoard();
		puts("After init Checker Board"); fflush(stdout);
		board->displayBoard();
		char temp1[2];
		//int accumForTop = 0;
		//int accumForBot = 0;

		for(int row = 0; row < 8; row++)
		{
			printf("on row %d\n", row);fflush(stdout);
			for(int col = 0; col < 8; col++){
				fscanf(fp, "%s", temp1);
				printf("in column %d, read %c\n", col, temp1[0]);fflush(stdout);
				if(temp1[0] == 112)
				{
					Checker* piece = (Checker*)malloc(sizeof(Checker));
					piece = board->getCheckerPiece(row,col);
					piece->setType(1);
					piece->setTopSide(true);
					printf("type is %d\n", piece->getType());fflush(stdout);

					Checker* newPiece = new Checker();
					newPiece->setType(1);
					newPiece->setTopSide(true);
					newPiece->setCoordinates(row,col);

					list->savePayload(newPiece);
					puts("save successful");fflush(stdout);
				}
				else if(temp1[0]==80)
				{
					Checker* piece = (Checker*)malloc(sizeof(Checker));
					piece = board->getCheckerPiece(row,col);
					piece->setType(1);
					piece->setTopSide(false);
					printf("type is %d\n", piece->getType());fflush(stdout);

					Checker* newPiece = new Checker();
					newPiece->setType(1);
					newPiece->setTopSide(false);
					newPiece->setCoordinates(row,col);

					list->savePayload2(newPiece);
					puts("save successful");fflush(stdout);
				}
				else if(temp1[0] == 107)
				{
					Checker* piece = (Checker*)malloc(sizeof(Checker));
					piece = board->getCheckerPiece(row,col);
					piece->setType(2);
					piece->setTopSide(true);
					printf("type is %d\n", piece->getType());fflush(stdout);

					Checker* newPiece = new Checker();
					newPiece->setType(2);
					newPiece->setTopSide(true);
					newPiece->setCoordinates(row,col);

					list->savePayload(newPiece);
					puts("save successful");fflush(stdout);
				}
				else if(temp1[0] == 75)
				{
					Checker* piece = (Checker*)malloc(sizeof(Checker));
					piece = board->getCheckerPiece(row,col);
					piece->setType(2);
					piece->setTopSide(false);
					printf("type is %d\n", piece->getType());fflush(stdout);

					Checker* newPiece = new Checker();
					newPiece->setType(2);
					newPiece->setTopSide(false);
					newPiece->setCoordinates(row,col);

					list->savePayload2(newPiece);
					puts("save successful");fflush(stdout);
				}
			}
		}
		ok = true;
	}
	fclose(fp);

	return ok;
}

void Production::displayBoardInFile(FILE* fOP, Board* board){
	//display board in config file
	for(int row = 0; row < 8; row++){
		for(int col = 0; col<8; col++){
			Checker* piece = board->getCheckerPiece(row, col);
			if(piece->getType() == 0){
				fprintf(fOP, "x ");fflush(fOP);//WRONG should be x
			}
			else if(piece->getType() == 2){
				if(piece->getSide()){
					fprintf(fOP, "k ");fflush(fOP);
				}
				else{
					fprintf(fOP, "K ");fflush(fOP);
				}
			}
			else if(piece->getType() == 1){
				if(piece->getSide()){
					fprintf(fOP,"p ");fflush(fOP);
				}
				else{
					fprintf(fOP, "P ");fflush(fOP);
				}
			}
		}
		fprintf(fOP, "\n");fflush(fOP);
	}
}

void Production::printMoveListInFile(FILE* fOP, Board* board,LList* list){
	fprintf(fOP, "Here are the moves:\n");fflush(stdout);

	LLNode3* moveList = list->getMoveList();

	if(moveList->payP == (Payload3*)0){
		fprintf(fOP, "No moves\n");fflush(fOP);
	}
	else{
		LLNode3* temp = list->getMoveList();
		int currentRow = -1;
		int currentCol = -1;
		int capturedRow = -1;
		int capturedCol = -1;
		int nextRow = -1;
		int nextCol = -1;
		bool capture = false;
		int accum = 1;

		while(temp->next){
			currentRow = temp->payP->row;
			currentCol = temp->payP->col;
			capturedRow = temp->payP->capturedRow;
			capturedCol = temp->payP->capturedCol;
			nextRow = temp->payP->nextRow;
			nextCol = temp->payP->nextCol;
			capture = temp->payP->didCapture;

			if(capture){
				fprintf(fOP, "%d. Piece at row %d and col %d can capture piece at row %d and col %d and will be at row %d and col %d\n",
						accum,currentRow,currentCol,capturedRow,capturedCol, nextRow,nextCol);fflush(fOP);
			}
			else{
				fprintf(fOP, "%d. Piece at row %d and col %d will be at row %d and col %d\n", accum,
						currentRow,currentCol,nextRow,nextCol);fflush(fOP);
			}
			accum++;
			temp = temp->next;
		}
		currentRow = temp->payP->row;
		currentCol = temp->payP->col;
		capturedRow = temp->payP->capturedRow;
		capturedCol = temp->payP->capturedCol;
		nextRow = temp->payP->nextRow;
		nextCol = temp->payP->nextCol;
		capture = temp->payP->didCapture;

		if(capture){
			fprintf(fOP, "%d. Piece at row %d and col %d can capture piece at row %d and col %d and will be at row %d and col %d\n",
					accum, currentRow,currentCol,capturedRow,capturedCol, nextRow,nextCol);
		}
		else{
			fprintf(fOP, "%d. Piece at row %d and col %d will be at row %d and col %d\n", accum,
					currentRow,currentCol,nextRow,nextCol);
		}
	}
}
