/*
 * LList.h
 *
 *  Created on: Mar 9, 2021
 *      Author: Andrew Hariyanto
 */

#ifndef LLIST_H_
#define LLIST_H_

#include "Checker.h"
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include "time.h"


typedef struct Move
{
	int row;
	int col;
	int nextRow;
	int nextCol;
	bool didCapture;
	int capturedRow;
	int capturedCol;
	int moveNum;
}Move;

typedef Checker Payload;//temp

typedef Checker Payload2;

typedef Move Payload3;

struct LLNode;
typedef struct LLNode
{
	struct LLNode* next;
	struct LLNode* prev;
	Payload* payP;
}LLNode;

struct LLNode2;
typedef struct LLNode2
{
	struct LLNode2* next;
	struct LLNode2* prev;
	Payload2* payP;
}LLNode2;

struct LLNode3;
typedef struct LLNode3
{
	struct LLNode3* next;
	struct LLNode3* prev;
	Payload3* payP;
}LLNode3;

typedef struct backFromDQFIFO
{
	Payload* mp;
	LLNode* newQHead;
}backFromDQFIFO;

class LList {
public:
	LList();
	virtual ~LList();
	void savePayload(Payload* mp);
	void savePayload2(Payload2* mp);
	void savePayload3(Payload3* mp);
	bool isEmpty();
	bool isEmpty2();
	bool isEmpty3();
	void removeFromList(Payload* pP);
	void removeFromList2(Payload2* pP);
	LLNode* getTopSide();
	LLNode2* getBotSide();
	LLNode3* getMoveList();
	void printMoveList();
	Move* makeRandomMoveTopSide();
	Move* userChooseMoveBotSide(int);
	void dequeueAllMoves();


private:
	LLNode* lp;
	LLNode2* lp2;
	LLNode3* lp3;

	LLNode* makeEmptyLinkedList();
	LLNode2* makeEmptyLinkedList2();
	LLNode3* makeEmptyLinkedList3();

};




#endif /* LLIST_H_ */
