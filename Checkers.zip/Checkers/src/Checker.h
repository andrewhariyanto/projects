/*
 * Checker.h
 *
 *  Created on: Mar 9, 2021
 *      Author: Andrew Hariyanto
 */

#ifndef SRC_CHECKER_H_
#define SRC_CHECKER_H_

typedef struct Piece
{
	bool isPawn;
	bool isKing;
	bool isEmpty;
}Piece;

class Checker {
public:
	Checker();
	virtual ~Checker();
	int getType();
	bool getSide();
	void setCoordinates(int, int);
	void setType(int);
	void setTopSide(bool);
	int getRow();
	int getCol();

private:
	int row;
	int col;
	bool isKing;
	bool isPawn;
	bool isEmpty;
	bool topSide;
};

#endif /* SRC_CHECKER_H_ */
