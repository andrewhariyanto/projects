/*
 * Board.cpp
 *
 *  Created on: Mar 9, 2021
 *      Author: Andrew Hariyanto
 */

#include "Board.h"


Board::Board() {
	// TODO Auto-generated constructor stub
}

Board::~Board() {
	// TODO Auto-generated destructor stub
}

void Board::initBoard(){
	puts("Now initializing checker board");fflush(stdout);
	for(int row = 0; row < 8; row++){
		for(int col = 0; col<8; col++){
			Checker** pieceAddress = piecesP + 8*row +col;
			Checker* piece = (Checker*) malloc(sizeof(Checker));
			piece->setCoordinates(row,col);
			piece->setType(0);
			piece->setTopSide(true);
			*(pieceAddress) = piece;
		}
	}
}

void Board::displayBoard(){
	puts("Now displaying board:");fflush(stdout);
	for(int row = 0; row < 8; row++){
		for(int col = 0; col<8; col++){
			Checker* piece = getCheckerPiece(row, col);
			if(piece->getType() == 0){
				printf("x ");fflush(stdout);
			}
			else if(piece->getType() == 2){
				if(piece->getSide()){
					printf("k ");fflush(stdout);
				}
				else{
					printf("K ");fflush(stdout);
				}
			}
			else if(piece->getType() == 1){
				if(piece->getSide()){
					printf("p ");fflush(stdout);
				}
				else{
					printf("P ");fflush(stdout);
				}
			}
		}
		printf("\n");fflush(stdout);
	}
}

void Board::setPiecesP(Checker** pieceStart){
	piecesP = pieceStart;
}

Checker** Board::getPiecesP(){
	return piecesP;
}

Checker* Board::getCheckerPiece(int row, int col){
	return *(piecesP + (8*row) + col);
}

bool Board::canMoveDownLeft(int row, int col){
	bool ans = false;
	if(col == 0 || row == 7){
		//we are at the edges
		ans = false;
	}
	else
	{
		Checker* cell = getCheckerPiece(row+1, col-1);
		if(cell->getType() == 0){
			ans = true;
		}
		else{
			ans = false;
		}
	}
	return ans;
}

bool Board::canMoveDownRight(int row, int col){
	bool ans = false;
	if(col == 7 || row == 7){
		//we are at the edges
		ans = false;
	}
	else{
		Checker* cell = getCheckerPiece(row+1, col+1);
		if(cell->getType() == 0){
			ans = true;
		}
		else{
			ans = false;
		}
	}
	return ans;
}

bool Board::canMoveUpLeft(int row, int col){
	bool ans = false;
	if(row == 0 || col == 0){
		ans = false;
	}
	else{
		Checker* cell = getCheckerPiece(row-1, col-1);
		if(cell->getType() == 0){
			ans = true;
		}
		else{
			ans = false;
		}
	}
	return ans;
}

bool Board::canMoveUpRight(int row, int col){
	bool ans = false;
	if(row == 0 || col == 7){
		ans = false;
	}
	else{
		Checker* cell = getCheckerPiece(row-1, col+1);
		if(cell->getType() == 0){
			ans = true;
		}
		else{
			ans = false;
		}
	}
	return ans;
}

bool Board::canJumpDownLeft(int row, int col){
	bool ans = false;
	if(row == 6 || row == 7|| col == 0 || col == 1){
		ans = false;
	}
	else{
		Checker* currentCell = getCheckerPiece(row, col);
		Checker* cell = getCheckerPiece(row+1, col-1);
		Checker* cell2 = getCheckerPiece(row+2, col-2);
		if(currentCell->getSide() != cell->getSide()){
			if(cell->getType() == 1 || cell->getType()==2){
				if(cell2->getType() == 0){
					ans = true;
				}
			}
		}
	}
	return ans;
}

bool Board::canJumpDownRight(int row, int col){
	bool ans = false;
	if(row == 6 || row == 7|| col == 6 || col == 7){
		ans = false;
	}
	else{
	Checker* cell = getCheckerPiece(row+1, col+1);
	Checker* cell2 = getCheckerPiece(row+2, col+2);
	Checker* currentCell = getCheckerPiece(row, col);
	if(currentCell->getSide() != cell->getSide()){
		if(cell->getType() == 1 || cell->getType()==2){
			if(cell2->getType() == 0){
				ans = true;
			}
		}
	}
	}
	return ans;
}

bool Board::canJumpUpLeft(int row, int col){
	bool ans = false;
	if(row == 0 || row == 1|| col == 0 || col == 1){
		ans = false;
	}
	else{

	Checker* cell = getCheckerPiece(row-1, col-1);
	Checker* cell2 = getCheckerPiece(row-2, col-2);
	Checker* currentCell = getCheckerPiece(row, col);
	if(currentCell->getSide() != cell->getSide()){
		if(cell->getType() == 1 || cell->getType()==2){
			if(cell2->getType() == 0){
				ans = true;
			}
		}
	}
	}
	return ans;
}

bool Board::canJumpUpRight(int row, int col){
	bool ans = false;
	if(row == 0 || row == 1|| col == 6 || col == 7){
		ans = false;
	}
	else{
	Checker* cell = getCheckerPiece(row-1, col+1);
	Checker* cell2 = getCheckerPiece(row-2, col+2);
	Checker* currentCell = getCheckerPiece(row, col);
	if(currentCell->getSide() != cell->getSide()){
		if(cell->getType() == 1 || cell->getType()==2){
			if(cell2->getType() == 0){
				ans = true;
			}
		}
	}
	}
	return ans;
}

void Board::promotionTopSide(int row, int col, LList* list){
	if(row == 7){
		Checker* piece = getCheckerPiece(row, col);
		puts("found a piece");fflush(stdout);
		if(piece->getType() == 1){
			puts("found a pawn");fflush(stdout);
			piece->setType(2);

			list->removeFromList(piece);

			Checker* newKing = (Checker*) malloc(sizeof(Checker));
			newKing->setType(2);
			newKing->setTopSide(false);
			newKing->setCoordinates(row,col);
			list->savePayload(newKing);
			puts("promotion successful");fflush(stdout);
		}
	}
}

void Board::promotionBotSide(int row, int col, LList* list){
	if(row == 0){
		Checker* piece = getCheckerPiece(row, col);
		puts("found a piece");fflush(stdout);
		if(piece->getType() == 1){
			puts("found a pawn");fflush(stdout);
			piece->setType(2);

			list->removeFromList2(piece);

			Checker* newKing = (Checker*) malloc(sizeof(Checker));
			newKing->setType(2);
			newKing->setTopSide(false);
			newKing->setCoordinates(row,col);
			list->savePayload2(newKing);
			puts("promotion successful");fflush(stdout);
		}
	}
}

void Board::collectMovesTopSide(LList* lists)
{
	LLNode* temp = lists->getTopSide();
	int currentRow = -1;
	int currentCol = -1;

	if(lists->isEmpty()){
		//do nothing
	}
	else{
		while(temp->next){
			Checker* piece = temp->payP;
			currentRow = piece->getRow();
			currentCol = piece->getCol();
			printf("now on piece in row %d col %d\n", currentRow, currentCol);fflush(stdout);

			if(piece->getType() == 2){
				puts("found king");fflush(stdout);
				if(canJumpDownLeft(currentRow,currentCol) || canJumpDownRight(currentRow,currentCol)
						|| canJumpUpLeft(currentRow, currentCol) || canJumpUpRight(currentRow, currentCol)){
					puts("king can jump");;fflush(stdout);
					if(canJumpDownLeft(currentRow, currentCol)){
						Move* myMove = (Move*) malloc(sizeof(Move));
						myMove->col = currentCol;
						myMove->row = currentRow;
						myMove->nextCol = currentCol - 2;
						myMove->nextRow = currentRow +2;
						myMove->didCapture = true;
						myMove->capturedCol = currentCol -1;
						myMove->capturedRow = currentRow +1;
						lists->savePayload3(myMove);
					}
					if(canJumpDownRight(currentRow, currentCol)){
						Move* myMove = (Move*) malloc(sizeof(Move));
						myMove->col = currentCol;
						myMove->row = currentRow;
						myMove->nextCol = currentCol + 2;
						myMove->nextRow = currentRow + 2;
						myMove->didCapture = true;
						myMove->capturedCol = currentCol +1;
						myMove->capturedRow = currentRow +1;
						lists->savePayload3(myMove);
					}
					if(canJumpUpRight(currentRow, currentCol)){
						Move* myMove = (Move*) malloc(sizeof(Move));
						myMove->col = currentCol;
						myMove->row = currentRow;
						myMove->nextCol = currentCol + 2;
						myMove->nextRow = currentRow - 2;
						myMove->didCapture = true;
						myMove->capturedCol = currentCol +1;
						myMove->capturedRow = currentRow -1;
						lists->savePayload3(myMove);
					}
					if(canJumpUpLeft(currentRow, currentCol)){
						Move* myMove = (Move*) malloc(sizeof(Move));
						myMove->col = currentCol;
						myMove->row = currentRow;
						myMove->nextCol = currentCol - 2;
						myMove->nextRow = currentRow - 2;
						myMove->didCapture = true;
						myMove->capturedCol = currentCol -1;
						myMove->capturedRow = currentRow -1;
						lists->savePayload3(myMove);
					}
				}
				else{
					puts("king cannot jump");fflush(stdout);
					if(canMoveDownRight(currentRow,currentCol)){
							Move* myMove = (Move*) malloc(sizeof(Move));
							myMove->col = currentCol;
							myMove->row = currentRow;
							myMove->nextCol = currentCol + 1;
							myMove->nextRow = currentRow + 1;
							myMove->didCapture = false;
							lists->savePayload3(myMove);
					}
					if(canMoveDownLeft(currentRow,currentCol)){
							Move* myMove = (Move*) malloc(sizeof(Move));
							myMove->col = currentCol;
							myMove->row = currentRow;
							myMove->nextCol = currentCol - 1;
							myMove->nextRow = currentRow + 1;
							myMove->didCapture = false;
							lists->savePayload3(myMove);
					}
					if(canMoveUpLeft(currentRow,currentCol)){
							Move* myMove = (Move*) malloc(sizeof(Move));
							myMove->col = currentCol;
							myMove->row = currentRow;
							myMove->nextCol = currentCol - 1;
							myMove->nextRow = currentRow - 1;
							myMove->didCapture = false;
							lists->savePayload3(myMove);
						}
					if(canMoveUpRight(currentRow,currentCol)){
							Move* myMove = (Move*) malloc(sizeof(Move));
							myMove->col = currentCol;
							myMove->row = currentRow;
							myMove->nextCol = currentCol + 1;
							myMove->nextRow = currentRow - 1;
							myMove->didCapture = false;
							lists->savePayload3(myMove);
					}
				}
			}
			else if(piece->getType() == 1){
				puts("found pawn");fflush(stdout);
				if(canJumpDownLeft(currentRow,currentCol) || canJumpDownRight(currentRow,currentCol)){
					puts("pawn can jump");fflush(stdout);
					if(canJumpDownLeft(currentRow, currentCol)){
						Move* myMove = (Move*) malloc(sizeof(Move));
						myMove->col = currentCol;
						myMove->row = currentRow;
						myMove->nextCol = currentCol - 2;
						myMove->nextRow = currentRow +2;
						myMove->didCapture = true;
						myMove->capturedCol = currentCol -1;
						myMove->capturedRow = currentRow +1;
						lists->savePayload3(myMove);
					}
					if(canJumpDownRight(currentRow, currentCol)){
						Move* myMove = (Move*) malloc(sizeof(Move));
						myMove->col = currentCol;
						myMove->row = currentRow;
						myMove->nextCol = currentCol + 2;
						myMove->nextRow = currentRow + 2;
						myMove->didCapture = true;
						myMove->capturedCol = currentCol +1;
						myMove->capturedRow = currentRow +1;
						lists->savePayload3(myMove);
					}
				}
				else{
					puts("pawn cannot jump");fflush(stdout);
					if(canMoveDownRight(currentRow,currentCol)){
						Move* myMove = (Move*) malloc(sizeof(Move));
						myMove->col = currentCol;
						myMove->row = currentRow;
						myMove->nextCol = currentCol + 1;
						myMove->nextRow = currentRow + 1;
						myMove->didCapture = false;
						lists->savePayload3(myMove);
					}
					if(canMoveDownLeft(currentRow,currentCol)){
						Move* myMove = (Move*) malloc(sizeof(Move));
						myMove->col = currentCol;
						myMove->row = currentRow;
						myMove->nextCol = currentCol - 1;
						myMove->nextRow = currentRow + 1;
						myMove->didCapture = false;
						lists->savePayload3(myMove);
					}
				}
			}
			temp = temp->next;
		}
		//do one more
		Checker* piece = temp->payP;
		currentRow = piece->getRow();
		currentCol = piece->getCol();
		printf("now on piece in row %d col %d\n", currentRow, currentCol);fflush(stdout);

		if(piece->getType() == 2){
			if(canJumpDownLeft(currentRow,currentCol) || canJumpDownRight(currentRow,currentCol)
					|| canJumpUpLeft(currentRow, currentCol) || canJumpUpRight(currentRow, currentCol)){
				if(canJumpDownLeft(currentRow, currentCol)){
					puts("king can jump");fflush(stdout);
					Move* myMove = (Move*) malloc(sizeof(Move));
					myMove->col = currentCol;
					myMove->row = currentRow;
					myMove->nextCol = currentCol - 2;
					myMove->nextRow = currentRow +2;
					myMove->didCapture = true;
					myMove->capturedCol = currentCol -1;
					myMove->capturedRow = currentRow +1;
					lists->savePayload3(myMove);
				}
				if(canJumpDownRight(currentRow, currentCol)){
					Move* myMove = (Move*) malloc(sizeof(Move));
					myMove->col = currentCol;
					myMove->row = currentRow;
					myMove->nextCol = currentCol + 2;
					myMove->nextRow = currentRow + 2;
					myMove->didCapture = true;
					myMove->capturedCol = currentCol +1;
					myMove->capturedRow = currentRow +1;
					lists->savePayload3(myMove);
				}
				if(canJumpUpRight(currentRow, currentCol)){
					Move* myMove = (Move*) malloc(sizeof(Move));
					myMove->col = currentCol;
					myMove->row = currentRow;
					myMove->nextCol = currentCol + 2;
					myMove->nextRow = currentRow - 2;
					myMove->didCapture = true;
					myMove->capturedCol = currentCol +1;
					myMove->capturedRow = currentRow -1;
					lists->savePayload3(myMove);
				}
				if(canJumpUpLeft(currentRow, currentCol)){
					Move* myMove = (Move*) malloc(sizeof(Move));
					myMove->col = currentCol;
					myMove->row = currentRow;
					myMove->nextCol = currentCol - 2;
					myMove->nextRow = currentRow - 2;
					myMove->didCapture = true;
					myMove->capturedCol = currentCol -1;
					myMove->capturedRow = currentRow -1;
					lists->savePayload3(myMove);
				}
			}
			else{
				if(canMoveDownRight(currentRow,currentCol)){
					Move* myMove = (Move*) malloc(sizeof(Move));
					myMove->col = currentCol;
					myMove->row = currentRow;
					myMove->nextCol = currentCol + 1;
					myMove->nextRow = currentRow + 1;
					myMove->didCapture = false;
					lists->savePayload3(myMove);
				}
				if(canMoveDownLeft(currentRow,currentCol)){
					Move* myMove = (Move*) malloc(sizeof(Move));
					myMove->col = currentCol;
					myMove->row = currentRow;
					myMove->nextCol = currentCol - 1;
					myMove->nextRow = currentRow + 1;
					myMove->didCapture = false;
					lists->savePayload3(myMove);
				}
				if(canMoveUpLeft(currentRow,currentCol)){
					Move* myMove = (Move*) malloc(sizeof(Move));
					myMove->col = currentCol;
					myMove->row = currentRow;
					myMove->nextCol = currentCol - 1;
					myMove->nextRow = currentRow - 1;
					myMove->didCapture = false;
					lists->savePayload3(myMove);
				}
				if(canMoveUpRight(currentRow,currentCol)){
					Move* myMove = (Move*) malloc(sizeof(Move));
					myMove->col = currentCol;
					myMove->row = currentRow;
					myMove->nextCol = currentCol + 1;
					myMove->nextRow = currentRow - 1;
					myMove->didCapture = false;
					lists->savePayload3(myMove);
				}
			}
		}
		else if(piece->getType() == 1){
			if(canJumpDownLeft(currentRow,currentCol) || canJumpDownRight(currentRow,currentCol)){
				puts("pawn can jump");fflush(stdout);
				if(canJumpDownLeft(currentRow, currentCol)){
					Move* myMove = (Move*) malloc(sizeof(Move));
					myMove->col = currentCol;
					myMove->row = currentRow;
					myMove->nextCol = currentCol - 2;
					myMove->nextRow = currentRow +2;
					myMove->didCapture = true;
					myMove->capturedCol = currentCol -1;
					myMove->capturedRow = currentRow +1;
					lists->savePayload3(myMove);
				}
				if(canJumpDownRight(currentRow, currentCol)){
					Move* myMove = (Move*) malloc(sizeof(Move));
					myMove->col = currentCol;
					myMove->row = currentRow;
					myMove->nextCol = currentCol + 2;
					myMove->nextRow = currentRow + 2;
					myMove->didCapture = true;
					myMove->capturedCol = currentCol +1;
					myMove->capturedRow = currentRow +1;
					lists->savePayload3(myMove);
				}
			}
			else{
				if(canMoveDownRight(currentRow,currentCol)){
					Move* myMove = (Move*) malloc(sizeof(Move));
					myMove->col = currentCol;
					myMove->row = currentRow;
					myMove->nextCol = currentCol + 1;
					myMove->nextRow = currentRow + 1;
					myMove->didCapture = false;
					lists->savePayload3(myMove);
				}
				if(canMoveDownLeft(currentRow,currentCol)){
					Move* myMove = (Move*) malloc(sizeof(Move));
					myMove->col = currentCol;
					myMove->row = currentRow;
					myMove->nextCol = currentCol - 1;
					myMove->nextRow = currentRow + 1;
					myMove->didCapture = false;
					lists->savePayload3(myMove);
				}
			}
		}
	}

}

void Board::collectMovesBotSide(LList* lists){
	LLNode2* temp = lists->getBotSide();
	int currentRow = -1;
	int currentCol = -1;

	if(lists->isEmpty2()){
		//do nothing
	}
	else{
		while(temp->next){
			Checker* piece = temp->payP;
			currentRow = piece->getRow();
			currentCol = piece->getCol();
			printf("now on piece in row %d col %d\n", currentRow, currentCol);fflush(stdout);

			if(piece->getType() == 2){
				if(canJumpDownLeft(currentRow,currentCol) || canJumpDownRight(currentRow,currentCol)
						|| canJumpUpLeft(currentRow, currentCol) || canJumpUpRight(currentRow, currentCol)){

					if(canJumpDownLeft(currentRow, currentCol)){
						Move* myMove = (Move*) malloc(sizeof(Move));
						myMove->col = currentCol;
						myMove->row = currentRow;
						myMove->nextCol = currentCol - 2;
						myMove->nextRow = currentRow +2;
						myMove->didCapture = true;
						myMove->capturedCol = currentCol -1;
						myMove->capturedRow = currentRow +1;
						lists->savePayload3(myMove);
					}
					if(canJumpDownRight(currentRow, currentCol)){
						Move* myMove = (Move*) malloc(sizeof(Move));
						myMove->col = currentCol;
						myMove->row = currentRow;
						myMove->nextCol = currentCol + 2;
						myMove->nextRow = currentRow + 2;
						myMove->didCapture = true;
						myMove->capturedCol = currentCol +1;
						myMove->capturedRow = currentRow +1;
						lists->savePayload3(myMove);
					}
					if(canJumpUpRight(currentRow, currentCol)){
						Move* myMove = (Move*) malloc(sizeof(Move));
						myMove->col = currentCol;
						myMove->row = currentRow;
						myMove->nextCol = currentCol + 2;
						myMove->nextRow = currentRow - 2;
						myMove->didCapture = true;
						myMove->capturedCol = currentCol +1;
						myMove->capturedRow = currentRow -1;
						lists->savePayload3(myMove);
					}
					if(canJumpUpLeft(currentRow, currentCol)){
						Move* myMove = (Move*) malloc(sizeof(Move));
						myMove->col = currentCol;
						myMove->row = currentRow;
						myMove->nextCol = currentCol - 2;
						myMove->nextRow = currentRow - 2;
						myMove->didCapture = true;
						myMove->capturedCol = currentCol -1;
						myMove->capturedRow = currentRow -1;
						lists->savePayload3(myMove);
					}
				}
				else{
					if(canMoveDownRight(currentRow,currentCol)){
						Move* myMove = (Move*) malloc(sizeof(Move));
						myMove->col = currentCol;
						myMove->row = currentRow;
						myMove->nextCol = currentCol + 1;
						myMove->nextRow = currentRow + 1;
						myMove->didCapture = false;
						lists->savePayload3(myMove);
					}
					if(canMoveDownLeft(currentRow,currentCol)){
						Move* myMove = (Move*) malloc(sizeof(Move));
						myMove->col = currentCol;
						myMove->row = currentRow;
						myMove->nextCol = currentCol - 1;
						myMove->nextRow = currentRow + 1;
						myMove->didCapture = false;
						lists->savePayload3(myMove);
					}
					if(canMoveUpLeft(currentRow,currentCol)){
						Move* myMove = (Move*) malloc(sizeof(Move));
						myMove->col = currentCol;
						myMove->row = currentRow;
						myMove->nextCol = currentCol - 1;
						myMove->nextRow = currentRow - 1;
						myMove->didCapture = false;
						lists->savePayload3(myMove);
					}
					if(canMoveUpRight(currentRow,currentCol)){
						Move* myMove = (Move*) malloc(sizeof(Move));
						myMove->col = currentCol;
						myMove->row = currentRow;
						myMove->nextCol = currentCol + 1;
						myMove->nextRow = currentRow - 1;
						myMove->didCapture = false;
						lists->savePayload3(myMove);
					}
				}
			}

			else if(piece->getType() == 1){
				if(canJumpUpLeft(currentRow,currentCol) || canJumpUpRight(currentRow,currentCol)){
					if(canJumpUpLeft(currentRow, currentCol)){
						Move* myMove = (Move*) malloc(sizeof(Move));
						myMove->col = currentCol;
						myMove->row = currentRow;
						myMove->nextCol = currentCol - 2;
						myMove->nextRow = currentRow - 2;
						myMove->didCapture = true;
						myMove->capturedCol = currentCol -1;
						myMove->capturedRow = currentRow -1;
						lists->savePayload3(myMove);
					}
					if(canJumpUpRight(currentRow, currentCol)){
						Move* myMove = (Move*) malloc(sizeof(Move));
						myMove->col = currentCol;
						myMove->row = currentRow;
						myMove->nextCol = currentCol + 2;
						myMove->nextRow = currentRow - 2;
						myMove->didCapture = true;
						myMove->capturedCol = currentCol +1;
						myMove->capturedRow = currentRow -1;
						lists->savePayload3(myMove);
					}
				}
				else{
					if(canMoveUpRight(currentRow,currentCol)){
						Move* myMove = (Move*) malloc(sizeof(Move));
						myMove->col = currentCol;
						myMove->row = currentRow;
						myMove->nextCol = currentCol + 1;
						myMove->nextRow = currentRow - 1;
						myMove->didCapture = false;
						lists->savePayload3(myMove);
					}
					if(canMoveUpLeft(currentRow,currentCol)){
						Move* myMove = (Move*) malloc(sizeof(Move));
						myMove->col = currentCol;
						myMove->row = currentRow;
						myMove->nextCol = currentCol - 1;
						myMove->nextRow = currentRow - 1;
						myMove->didCapture = false;
						lists->savePayload3(myMove);
					}
				}
			}
			temp = temp->next;
		}
		//do one more
		Checker* piece = temp->payP;
		currentRow = piece->getRow();
		currentCol = piece->getCol();
		printf("now on piece in row %d col %d\n", currentRow, currentCol);fflush(stdout);

		if(piece->getType() == 2){
			puts("found king");fflush(stdout);
			if(canJumpDownLeft(currentRow,currentCol) || canJumpDownRight(currentRow,currentCol)
					|| canJumpUpLeft(currentRow, currentCol) || canJumpUpRight(currentRow, currentCol)){
				puts("king can jump");fflush(stdout);
				if(canJumpDownLeft(currentRow, currentCol)){
					Move* myMove = (Move*) malloc(sizeof(Move));
					myMove->col = currentCol;
					myMove->row = currentRow;
					myMove->nextCol = currentCol - 2;
					myMove->nextRow = currentRow +2;
					myMove->didCapture = true;
					myMove->capturedCol = currentCol -1;
					myMove->capturedRow = currentRow +1;
					lists->savePayload3(myMove);
				}
				if(canJumpDownRight(currentRow, currentCol)){
					Move* myMove = (Move*) malloc(sizeof(Move));
					myMove->col = currentCol;
					myMove->row = currentRow;
					myMove->nextCol = currentCol + 2;
					myMove->nextRow = currentRow + 2;
					myMove->didCapture = true;
					myMove->capturedCol = currentCol +1;
					myMove->capturedRow = currentRow +1;
					lists->savePayload3(myMove);
				}
				if(canJumpUpRight(currentRow, currentCol)){
					Move* myMove = (Move*) malloc(sizeof(Move));
					myMove->col = currentCol;
					myMove->row = currentRow;
					myMove->nextCol = currentCol + 2;
					myMove->nextRow = currentRow - 2;
					myMove->didCapture = true;
					myMove->capturedCol = currentCol +1;
					myMove->capturedRow = currentRow -1;
					lists->savePayload3(myMove);
				}
				if(canJumpUpLeft(currentRow, currentCol)){
					Move* myMove = (Move*) malloc(sizeof(Move));
					myMove->col = currentCol;
					myMove->row = currentRow;
					myMove->nextCol = currentCol - 2;
					myMove->nextRow = currentRow - 2;
					myMove->didCapture = true;
					myMove->capturedCol = currentCol -1;
					myMove->capturedRow = currentRow -1;
					lists->savePayload3(myMove);
				}
			}
			else{
				puts("king cannot jump");fflush(stdout);
				if(canMoveDownRight(currentRow,currentCol)){
					Move* myMove = (Move*) malloc(sizeof(Move));
					myMove->col = currentCol;
					myMove->row = currentRow;
					myMove->nextCol = currentCol + 1;
					myMove->nextRow = currentRow + 1;
					myMove->didCapture = false;
					lists->savePayload3(myMove);
				}
				if(canMoveDownLeft(currentRow,currentCol)){
					Move* myMove = (Move*) malloc(sizeof(Move));
					myMove->col = currentCol;
					myMove->row = currentRow;
					myMove->nextCol = currentCol - 1;
					myMove->nextRow = currentRow + 1;
					myMove->didCapture = false;
					lists->savePayload3(myMove);
				}
				if(canMoveUpLeft(currentRow,currentCol)){
					Move* myMove = (Move*) malloc(sizeof(Move));
					myMove->col = currentCol;
					myMove->row = currentRow;
					myMove->nextCol = currentCol - 1;
					myMove->nextRow = currentRow - 1;
					myMove->didCapture = false;
					lists->savePayload3(myMove);
				}
				if(canMoveUpRight(currentRow,currentCol)){
					Move* myMove = (Move*) malloc(sizeof(Move));
					myMove->col = currentCol;
					myMove->row = currentRow;
					myMove->nextCol = currentCol + 1;
					myMove->nextRow = currentRow - 1;
					myMove->didCapture = false;
					lists->savePayload3(myMove);
				}
			}
		}

		else if(piece->getType() == 1){
			puts("found pawn");fflush(stdout);
			if(canJumpUpLeft(currentRow,currentCol) || canJumpUpRight(currentRow,currentCol)){
				puts("pawn can jump");fflush(stdout);
				if(canJumpUpLeft(currentRow, currentCol)){
					Move* myMove = (Move*) malloc(sizeof(Move));
					myMove->col = currentCol;
					myMove->row = currentRow;
					myMove->nextCol = currentCol - 2;
					myMove->nextRow = currentRow - 2;
					myMove->didCapture = true;
					myMove->capturedCol = currentCol -1;
					myMove->capturedRow = currentRow -1;
					lists->savePayload3(myMove);
				}
				if(canJumpUpRight(currentRow, currentCol)){
					Move* myMove = (Move*) malloc(sizeof(Move));
					myMove->col = currentCol;
					myMove->row = currentRow;
					myMove->nextCol = currentCol + 2;
					myMove->nextRow = currentRow - 2;
					myMove->didCapture = true;
					myMove->capturedCol = currentCol +1;
					myMove->capturedRow = currentRow -1;
					lists->savePayload3(myMove);
				}
			}
			else{
				puts("pawn cannot jump");fflush(stdout);
				if(canMoveUpRight(currentRow,currentCol)){
					Move* myMove = (Move*) malloc(sizeof(Move));
					myMove->col = currentCol;
					myMove->row = currentRow;
					myMove->nextCol = currentCol + 1;
					myMove->nextRow = currentRow - 1;
					myMove->didCapture = false;
					lists->savePayload3(myMove);
				}
				if(canMoveUpLeft(currentRow,currentCol)){
					Move* myMove = (Move*) malloc(sizeof(Move));
					myMove->col = currentCol;
					myMove->row = currentRow;
					myMove->nextCol = currentCol - 1;
					myMove->nextRow = currentRow - 1;
					myMove->didCapture = false;
					lists->savePayload3(myMove);
				}
			}
		}
	}

}

void Board::updateBoard(Move* chosenMove, LList* list){
	int currentRow = chosenMove->row;
	int currentCol = chosenMove->col;
	int capturedRow = chosenMove->capturedRow;
	int capturedCol = chosenMove->capturedCol;
	int nextRow = chosenMove->nextRow;
	int nextCol = chosenMove->nextCol;
	bool captured = chosenMove->didCapture;

	//check if there was a captured piece
	if(captured){
		//a piece was captured
		//1. remove the piece that was captured from appropriate lists
		//2. set the old coordinates to type 0, set new coordinates to the
		//   type of piece that was moved, set the captured cell to 0
		//3. remove the old piece coordinate from list and add a new piece with new coordinates to it

		//remove the piece that was captured
		Checker* pieceFromTop = new Checker();
		Checker* pieceFromBot = new Checker();
		pieceFromTop->setCoordinates(capturedRow,capturedCol);
		pieceFromBot->setCoordinates(capturedRow,capturedCol);
		//there is only one piece on that row/col so only one of the lists would change
		list->removeFromList(pieceFromTop);
		list->removeFromList2(pieceFromBot);

		//now captured piece will be set to type 0 in board
		Checker* capturedCell = getCheckerPiece(capturedRow, capturedCol);
		capturedCell->setType(0);


		//now old coordinates will be set to type 0 in board, new coordinates will be set to the type of the piece that was moved
		Checker* oldCell = getCheckerPiece(currentRow, currentCol);
		Checker* newCell = getCheckerPiece(nextRow, nextCol);
		int oldCheckerType = oldCell->getType(); //old type for reference
		bool oldCheckerSide = oldCell->getSide();

		newCell->setType(oldCheckerType);
		newCell->setTopSide(oldCheckerSide);


		//time to replace pieces within list
		Checker* pieceToBeReplaced = new Checker();
		pieceToBeReplaced->setCoordinates(currentRow,currentCol);
		pieceToBeReplaced->setTopSide(oldCheckerSide);
		pieceToBeReplaced->setType(oldCheckerType);

		Checker* pieceToBeAdded = new Checker();
		pieceToBeAdded->setCoordinates(nextRow, nextCol);
		pieceToBeAdded->setType(oldCheckerType);
		pieceToBeAdded->setTopSide(oldCheckerSide);

		//new piece has been added
		if(oldCheckerSide){
			list->removeFromList(pieceToBeReplaced);
			list->savePayload(pieceToBeAdded);
			puts("save successful");fflush(stdout);
		}
		else{
			list->removeFromList2(pieceToBeReplaced);
			list->savePayload2(pieceToBeAdded);
			puts("save successful");fflush(stdout);
		}

		//finally set the old coordinates to type 0;
		oldCell->setType(0);

		//now we want to check for any promotions
		//each function won't do anything if the piece is not on the end rows
		promotionTopSide(nextRow,nextCol,list);
		promotionBotSide(nextRow,nextCol,list);

	}
	else{
		//piece was not captured
		//1. set new coordinates to appropriate type
		//2. replace the old piece in the lists with the new piece
		//3. set old coordinates to 0


		//now old coordinates will be set to type 0 in board, new coordinates will be set to the type of the piece that was moved
		Checker* oldCell = getCheckerPiece(currentRow, currentCol);
		Checker* newCell = getCheckerPiece(nextRow, nextCol);
		int oldCheckerType = oldCell->getType(); //old type for reference
		bool oldCheckerSide = oldCell->getSide();

		newCell->setType(oldCheckerType);
		newCell->setTopSide(oldCheckerSide);


		Checker* pieceToBeReplaced = new Checker();
		pieceToBeReplaced->setCoordinates(currentRow,currentCol);
		pieceToBeReplaced->setTopSide(oldCheckerSide);
		pieceToBeReplaced->setType(oldCheckerType);

		Checker* pieceToBeAdded = new Checker();
		pieceToBeAdded->setCoordinates(nextRow, nextCol);
		pieceToBeAdded->setType(oldCheckerType);
		pieceToBeAdded->setTopSide(oldCheckerSide);

		//new piece has been replaced
		if(oldCheckerSide){
			list->removeFromList(pieceToBeReplaced);
			list->savePayload(pieceToBeAdded);
			puts("save successful");fflush(stdout);
		}
		else{
			list->removeFromList2(pieceToBeReplaced);
			list->savePayload2(pieceToBeAdded);
			puts("save successful");fflush(stdout);
		}

		//finally set the old coordinates to type 0;
		oldCell->setType(0);

		//now we want to check for any promotions
		//each function won't do anything if the piece is not on the end rows
		promotionTopSide(nextRow,nextCol,list);
		promotionBotSide(nextRow,nextCol,list);
	}
}
