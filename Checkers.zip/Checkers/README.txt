This is Andrew's checkers game.*

How it works:
The console will display who's turn it is. Then, the program can identify and display
all possible moves the player can make. The player then enters the move number from
the choices available.

The program must take in 3 arguments in the run configurations:
1. The name of the file where your board configuration is stored (Ex. BoardConfig.txt)
2. The number of moves each player can do
3. Who's going first - 0 for the player and 1 for the computer

For the board configuration:
x - open space
p - computer's pawn
k - computer's king
P - player's pawn
K - player's king
The standard configuration for a checkers game has been included in BoardConfig.txt



*As of now, little artificial intelligence has been applied. Also, a double jump mechanism
has not been implemented.