/*
 * tests.h
 *
 *  Created on: Jan 27, 2021
 *      Author: Andrew Hariyanto
 */

#ifndef TESTS_H_
#define TESTS_H_


#include "production.h"

bool tests();

bool testReadFile();
bool testGotAdjacencyMatrix();
bool testMakeLList();
bool testEnqueue();
bool testRemoveFromList();
bool testPrintHistory();
bool testInitSpace();
bool testDisplaySpace();
bool testCallRandomCell();
bool testCompareCellFailLetter();
bool testCompareCellFailDigit();
bool testCompareCellPass();
bool testSetMatchSingle();
bool testSetMatchMoreThanOne();
bool testCheckColumn();
bool testCheckRow();
bool testCheckDiagonalLeftToRight();
bool testCheckDiagonalRightToLeft();
bool testIsWin();
bool testSetMatchNone();
bool testDelay();



#endif /* TESTS_H_ */
