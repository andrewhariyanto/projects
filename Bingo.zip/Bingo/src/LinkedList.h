/*
 * LinkedList.h
 *
 *  Created on: Jan 27, 2021
 *      Author: Andrew Hariyanto
 */

#ifndef LINKEDLIST_H_
#define LINKEDLIST_H_

#include <stdbool.h>
#include "cardCell.h"

#define bool _Bool
#define false 0
#define true 1



typedef cardCellContent Payload;

struct LLNode;

typedef struct
{
	struct LLNode* next;
	struct LLNode* prev;
	Payload* payP;
}LLNode;


typedef struct
{
	Payload* mp;
	LLNode* newQHead;
}backFromDQFIFO;

LLNode* makeEmptyLinkedList();
LLNode* removeFromList(LLNode* hp, Payload* pP);
void savePayload(LLNode* lp, Payload* mp);
bool isEmpty(LLNode* lp);
Payload* dequeueLIFO(LLNode* lp);
backFromDQFIFO* dequeueFIFO(LLNode* lp);

#endif /* LINKEDLIST_H_ */
