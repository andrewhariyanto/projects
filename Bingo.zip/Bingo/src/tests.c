/*
 * tests.c
 *
 *  Created on: Jan 27, 2021
 *      Author: Andrew Hariyanto
 */

#include "tests.h"
#include "production.h"
#include "LinkedList.h"


bool tests()
{
	bool answer = false;

	//test the functions that get used
	//order the tests from simplest first -- this produces building blocks for use in more complex tests
	//check how functions are used in production code, this gives clues about how to provide the arguments for the invocation
	bool ok1 = testReadFile();
	bool ok2 = testGotAdjacencyMatrix();
	bool ok3 = testMakeLList();
	bool ok4 = testEnqueue();
	bool ok5 = testRemoveFromList();
	bool ok6 = testPrintHistory();
	bool ok7 = testInitSpace();
	bool ok8 = testDisplaySpace();
	bool ok9 = testCallRandomCell();
	bool ok10 = testCompareCellFailLetter();
	bool ok11 = testCompareCellFailDigit();
	bool ok12 = testCompareCellPass();
	bool ok13 = testSetMatchSingle();
	bool ok14 = testSetMatchMoreThanOne();
	bool ok20 = testSetMatchNone();
	bool ok15 = testCheckRow();
	bool ok16 = testCheckColumn();
	bool ok17 = testCheckDiagonalLeftToRight();
	bool ok18 = testCheckDiagonalRightToLeft();
	bool ok19 = testIsWin();
	bool ok21 = testDelay();
	answer = ok1 && ok2 && ok3 && ok4 && ok5 && ok6 && ok7 && ok8 && ok9 && ok10 && ok11 && ok12 && ok13
			&& ok14 && ok15 && ok16 && ok17 && ok18 && ok19 && ok20 && ok21;
	//answer = true;
	return answer;
}

bool testReadFile()
{
	puts("starting testReadFile"); fflush(stdout);
	bool ok = true;
	return ok;
}

bool testGotAdjacencyMatrix()
{
	bool ans = true;
	return ans;
}

bool testMakeLList()
{
	bool ok = true;
	puts("starting testMakeLList");fflush(stdout);
	//what are the criteria for success for make LList?
	//should be able to make one, add data to it, get the data back
	//test case 1:
	LLNode* theListP = makeEmptyLinkedList();
	bool rightAnswer = true;
	bool answer = isEmpty(theListP);
	if(answer!=rightAnswer)
	{
		ok = false;
		printf("testMakeLList case 1, 2, and 3 did not pass\n");fflush(stdout);
	}
	else{
		printf("testMakeLList case 1 passed\n");fflush(stdout);

		//test case 2:
		//add something to it and make sure it is not empty
		cardCellContent* temp = (cardCellContent*) malloc (sizeof(cardCellContent));
		temp->col = 3;
		savePayload(theListP, temp);
		bool answer1 = isEmpty(theListP);
		if(answer1 == rightAnswer)
		{
			ok = false;
		}
		printf("testmakeLList case 2 passed\n");fflush(stdout);

		//test case 3:
		//add something to it and get it out, compare it with the expected answer
		cardCellContent* temp1 = (cardCellContent*) malloc (sizeof(cardCellContent));
		temp1->col = 3;
		savePayload(theListP, temp1);
		LLNode* lp = theListP;
		Payload* pP = lp->payP;
		if(pP == temp1){
			answer = true;
		}
		if(answer != rightAnswer){
			ok = false;
		}
		printf("testMakeLList case 3 passed\n");fflush(stdout);
	}
	return ok;
}

bool testEnqueue()
{
	bool ok = true;
	LLNode* theListP = makeEmptyLinkedList();
	bool rightAnswer = true;
	cardCellContent* temp = (cardCellContent*) malloc (sizeof(cardCellContent));
	temp->col = 3;
	savePayload(theListP, temp);
	bool answer = isEmpty(theListP);

	if(answer == rightAnswer){
		ok = false;
		puts("testEnqueue did not pass");fflush(stdout);
	}
	else{
		puts("testEnqueue passed");fflush(stdout);
	}

	return ok;
}

bool testRemoveFromList()
{
	bool ok = true;
	//cases:
	//1 list is empty:return same list
	//2 list is of length one, and item is present: return empty list
	//3 list is of length one, and item is not present: return same list
	//4 list is longer than one, item is present, at first location: return list starting at second element
	//5 list is longer than one, item is present, not at first location: return list with item removed
	//6 list is longer than one, item is not present: return same list
	LLNode* case1 = makeEmptyLinkedList();
	Payload* pay1 = (Payload*) malloc(sizeof(cardCellContent));
	pay1->col = 1;
	LLNode* ans = removeFromList(case1, pay1);
	if((ans != case1) || (ans->payP != (Payload*)0))
	{
		ok = false;

	}
	printf("testRemove case 1 with %d\n", ok); fflush(stdout);
	savePayload(case1, pay1);
	//this is case2
	ans = removeFromList(case1, pay1);
	if((ans != case1) || (ans->payP != (Payload*)0))
	{
		ok = false;

	}
	printf("testRemove case 2 with %d\n", ok); fflush(stdout);
	//now case 3
	Payload* pay3 = (Payload*) malloc(sizeof(cardCellContent));
	pay3->col = 3;
	ans = removeFromList(case1, pay3);
	if(ans != case1)//this is only a partial check for list unchanged
	{
		ok = false;

	}
	printf("testRemove case 3 with %d\n", ok); fflush(stdout);
	//now case 4
	case1 = makeEmptyLinkedList();
	pay1 = (Payload*) malloc(sizeof(cardCellContent));
	pay1->col = 1;
	savePayload(case1, pay1);
	pay3 = (Payload*) malloc(sizeof(cardCellContent));
	pay3->col = 3;
	savePayload(case1, pay3);
	ans = removeFromList(case1, pay1);

	if(ans == case1)
	{
		ok = false;

	}
	printf("testRemove case 4 with %d\n", ok); fflush(stdout);
	//now case 5
	case1 = makeEmptyLinkedList();
	pay1 = (Payload*) malloc(sizeof(cardCellContent));
	pay1->col = 1;
	savePayload(case1, pay1);
	pay3 = (Payload*) malloc(sizeof(cardCellContent));
	pay3->col = 3;
	savePayload(case1, pay3);
	//puts("trying case 5");fflush(stdout);
	ans = removeFromList(case1, pay3);//ans should be equal to case1
	LLNode* theNext = (LLNode*) ans->next; //this is element where pay3 got attached
	Payload* check = (Payload*) 0;
	if (theNext)
	{
		check = theNext->payP; //this should be pay3, which should have been removed
	}
	//printf("testRemove returned from case 5\n"); fflush(stdout);
	if((ans != case1) || (check != (Payload*)0))//disquiet
	{
		ok = false;

	}
	//printf("ans == case1 is %d\n", ans==case1);
	//printf("check != 0 is %d\n", check != (Payload*)0);
	printf("testRemove case 5 with %d\n", ok); fflush(stdout);
	//now case 6
	case1 = makeEmptyLinkedList();
	pay1 = (Payload*) malloc(sizeof(cardCellContent));
	pay1->col = 1;
	savePayload(case1, pay1);
	pay3 = (Payload*) malloc(sizeof(cardCellContent));
	pay3->col = 3;
	savePayload(case1, pay3);
	Payload* another = (Payload*) malloc(sizeof(cardCellContent));
	another->col = 2;
	ans = removeFromList(case1, another);
	if((ans != case1))
	{
		ok = false;

	}
	printf("testRemove case 6 with %d\n", ok); fflush(stdout);
	return ok;
}
bool testPrintHistory()
{
	bool ok = true;
	return ok;
}

bool testInitSpace()
{
	bool ok = false;
	cardCellContent** bingoCardP = (cardCellContent**) malloc(5*5*sizeof(cardCellContent*));
	initSpace(bingoCardP, 5);
	// check if the array is empty
	if(bingoCardP == NULL)
	{
		puts("testInitSpace failed"); fflush(stdout);
		return ok;
	}
		// check if each cell's letter and number are within the boundaries
	for(int row = 0; row< 5; row++)
		{
			for(int col = 0; col < 5; col++)
			{
				cardCellContent* cell = *(bingoCardP+row*5 + col);
				if(!(65 <= cell->letter && cell->letter <= 90 && 48 <= cell->digit && cell-> digit <= 57)){
					puts("testInitSpace failed"); fflush(stdout);
					return ok;
				}
			}
		}
	ok = true;
	puts("testInitSpace passed"); fflush(stdout);
	return ok;

}

bool testDisplaySpace()
{
	// manual test
	bool ok = false;
	cardCellContent** bingoCardP = (cardCellContent**) malloc(5*5*sizeof(cardCellContent*));
	initSpace(bingoCardP, 5); // need to initialize the board first
	displaySpace(bingoCardP, 5); // should display the board
	ok = true;
	if(ok)
	{
		puts("test displaySpace passed"); fflush(stdout);
	}
	else {
		puts("test displaySpace did not pass"); fflush(stdout);
	}
	return ok;
}

bool testCallRandomCell()
{
	bool ok = false;
	bool answer1 = false;
	bool answer2 = false;
	cardCellContent* cell = callRandomCell();
	//check if it is null
	if(cell == NULL)
	{
		puts("test callRandomCell did not pass"); fflush(stdout);
		return ok;
	}
	//check if the letter is within the boundary
	if(65 <= cell->letter && cell->letter <= 90)
	{
		answer1 = true;
	}
	//check of the number is within the boundary
	if(48 <= cell->digit && cell-> digit <= 57)
	{
		answer2 = true;
	}
	if(answer1 && answer2)
	{
		puts("test callRandomCell passed"); fflush(stdout);
		ok = true;
		return ok;
	}
	else
	{
		puts("test callRandomCell did not pass"); fflush(stdout);
		return ok;
	}
}

bool testCompareCellFailLetter()
{
	bool ok = false;
	bool realAnswer = false;

	cardCellContent* x = (cardCellContent*) malloc (sizeof(cardCellContent));
	x->letter = 'E';
	x->digit = '4';

	cardCellContent* y = (cardCellContent*) malloc (sizeof(cardCellContent));
	y->letter = 'T';
	y->digit = '4';

	bool answer = compareCell(x,y);
	if(answer == realAnswer)
	{
		ok = true;
		puts("testCompareCellFailLetter passed"); fflush(stdout);
		return ok;
	}
	else
	{
		puts("testCompareCellFailLetter did not pass"); fflush(stdout);
		return ok;
	}
}

bool testCompareCellFailDigit()
{
	bool ok = false;
	bool realAnswer = false;

	cardCellContent* x = (cardCellContent*) malloc (sizeof(cardCellContent));
	x->letter = 'E';
	x->digit = '4';

	cardCellContent* y = (cardCellContent*) malloc (sizeof(cardCellContent));
	y->letter = 'E';
	y->digit = '3';

	bool answer = compareCell(x,y);
	if(answer == realAnswer)
	{
		ok = true;
		puts("testCompareCellFailDigit passed"); fflush(stdout);
		return ok;
	}
	else
	{
		puts("testCompareCellFailDigit did not pass"); fflush(stdout);
		return ok;
	}
}

bool testCompareCellPass()
{
	bool ok = false;
	bool realAnswer = true;

	cardCellContent* x = (cardCellContent*) malloc (sizeof(cardCellContent));
	x->letter = 'E';
	x->digit = '4';

	cardCellContent* y = (cardCellContent*) malloc (sizeof(cardCellContent));
	y->letter = 'E';
	y->digit = '4';

	bool answer = compareCell(x,y);
	if(answer == realAnswer)
	{
		ok = true;
		puts("testCompareCellPass passed"); fflush(stdout);
		return ok;
	}
	else
	{
		puts("testCompareCellFailPass did not pass"); fflush(stdout);
		return ok;
	}
}

bool testSetMatchSingle()
{
	bool ok = false;
	//setting up the real answer
	cardCellContent* realAnswer = (cardCellContent*) malloc (sizeof(cardCellContent));
	realAnswer->row = 3;
	realAnswer->col = 2;
	realAnswer->letter = 'a';
	realAnswer->digit = '0';
	realAnswer->matched = true;


	//setting up the board
	cardCellContent** bingoCardP = (cardCellContent**) malloc(5*5*sizeof(cardCellContent*));
	initSpace(bingoCardP, 5);

	//modifying the cell at row 3 and col 2
	cardCellContent* cell = *(bingoCardP+3*5 + 2);
	cell->letter = 'E';
	cell->digit = '4';

	//setting the "random" call
	cardCellContent* z = (cardCellContent*) malloc (sizeof(cardCellContent)); //reserve a cardCell on heap
	z->letter = 'E';
	z->digit = '4';

	LLNode* list = makeEmptyLinkedList();

	//setMatch the known cell
	setMatch(bingoCardP, z , list);
	cardCellContent* answer = *(bingoCardP+3*5 +2);  //getting the variable at row 3 and col 2

	//checking the linked list
	bool answerList = true;
  	z->col = 2;
	z->row = 3;
	z->matched = true;
	Payload* pP = list->payP;
	if(pP != z){
		answerList = false;
	}


	//checking if all members are equal
	if(answer->row == realAnswer->row && answer->col == realAnswer->col && answer->letter == realAnswer->letter
			&& answer->digit == realAnswer->digit && answer->matched == realAnswer->matched && answerList)
	{
		ok = true;
		puts("testSetMatchSingle passed"); fflush(stdout);
		return ok;
	}
	else
	{
		puts("testSetMatchSingle did not pass"); fflush(stdout);
		return ok;
	}

}

bool testSetMatchMoreThanOne()
{
	bool ok = false;
	//setting up the real answers
	cardCellContent* realAnswer1 = (cardCellContent*) malloc (sizeof(cardCellContent));
	realAnswer1->row = 3;
	realAnswer1->col = 2;
	realAnswer1->letter = 'a';
	realAnswer1->digit = '0';
	realAnswer1->matched = true;

	cardCellContent* realAnswer2 = (cardCellContent*) malloc (sizeof(cardCellContent));
	realAnswer2->row = 1;
	realAnswer2->col = 3;
	realAnswer2->letter = 'a';
	realAnswer2->digit = '0';
	realAnswer2->matched = true;


	//setting up the board
	cardCellContent** bingoCardP = (cardCellContent**) malloc(5*5*sizeof(cardCellContent*));
	initSpace(bingoCardP, 5);

	//modifying the cell at row 3 and col 2
	cardCellContent* cell1 = *(bingoCardP+3*5 + 2);
	cell1->letter = 'E';
	cell1->digit = '4';

	//modifying the cell at row 1 and col 3
	cardCellContent* cell2 = *(bingoCardP+1*5 + 3);
	cell2->letter = 'E';
	cell2->digit = '4';

	//setting the "random" call
	cardCellContent* z = (cardCellContent*) malloc (sizeof(cardCellContent)); //reserve a cardCell on heap
	z->letter = 'E';
	z->digit = '4';

	//initialize empty list
	LLNode* list = makeEmptyLinkedList();


	//setMatch the known cell
	setMatch(bingoCardP, z, list);
	cardCellContent* answer1 = *(bingoCardP+3*5 +2);  //getting the variable at row 3 and col 2
	cardCellContent* answer2 = *(bingoCardP+1*5 +3);  //getting the variable at row 1 and col 3

	//checking the linked list first element
	bool answerList1 = false;
	z->col = 2;
	z->row = 3;
	z->matched = true;
	Payload* pP = list->payP;
	if(pP == z){
		answerList1 = true;
	}

	//checking the linked list second element
	bool answerList2 = false;
	z->col = 3;
	z->row = 1;
	LLNode* temp = list;
	Payload* pP2 = (Payload*)0;
	if(!(temp->next)){
		pP2 = (Payload*)0;
	}
	else{
		temp=(LLNode*)temp->next;
		pP2 = temp->payP;
	}
	if(pP2 == z){
		answerList2 = true;
	}

	//checking if all members are equal
	bool cond1 = (answer1->row == realAnswer1->row && answer1->col == realAnswer1->col && answer1->letter == realAnswer1->letter
			&& answer1->digit == realAnswer1->digit && answer1->matched == realAnswer1->matched && answerList1);
	bool cond2 = (answer2->row == realAnswer2->row && answer2->col == realAnswer2->col && answer2->letter == realAnswer2->letter
			&& answer2->digit == realAnswer2->digit && answer2->matched == realAnswer2->matched && answerList2);
	if(cond1 && cond2)
	{
		ok = true;
		puts("testSetMatchMoreThanOne passed"); fflush(stdout);
		return ok;
	}
	else
	{
		puts("testSetMatchMoreThanOne did not pass"); fflush(stdout);
		return ok;
	}
}

bool testSetMatchNone(){
	bool ok = false;
	bool answer = true;
	//setting up the real answer
	cardCellContent* realAnswer = (cardCellContent*) malloc (sizeof(cardCellContent));
	realAnswer->row = 3;
	realAnswer->col = 2;
	realAnswer->letter = 'a';
	realAnswer->digit = '0';
	realAnswer->matched = true;


	//setting up the board
	cardCellContent** bingoCardP = (cardCellContent**) malloc(5*5*sizeof(cardCellContent*));
	initSpace(bingoCardP, 5);

	//setting the "random" call intentionally making it fail
	cardCellContent* z = (cardCellContent*) malloc (sizeof(cardCellContent)); //reserve a cardCell on heap
	z->letter = 'e'; //lowercase = impossible
	z->digit = '3';

	LLNode* list = makeEmptyLinkedList();

	//setMatch the known cell
	setMatch(bingoCardP, z , list);

	for(int row = 0; row < 5; row++)
	{
		for(int col = 0; col < 5; col++)
		{
			cardCellContent* cell = *(bingoCardP+row*5 + col);
			if(cell->matched){
				answer = false;
			}
		}
	}

	//checking the linked list
	bool answerList = true;
	if(isEmpty(list)){
		answerList = false;
	}

	if(answerList && answer)
	{
		ok = true;
		puts("testSetMatchNone passed"); fflush(stdout);
		return ok;
	}
	else
	{
		puts("testSetMatchNone did not pass"); fflush(stdout);
		return ok;
	}
}

bool testCheckColumn(){
	bool ok = true;

	//initialize board
	cardCellContent** bingoCardP = (cardCellContent**) malloc(5*5*sizeof(cardCellContent*));
	initSpace(bingoCardP, 5);

	//case 1: no cells marked
	if(checkColumn(bingoCardP))
	{
		ok = false;
		puts("test checkColumn case 1 did not pass"); fflush(stdout);
	}
	else
	{
		puts("test checkColumn case 1 passed");fflush(stdout);
	}
	//case 2: three in a row

	//modifying the board
	cardCellContent* cell1 = *(bingoCardP + 0 + 0);
	cell1->letter = 'a';
	cell1->digit = '0';
	cell1->matched = true;

	cardCellContent* cell2 = *(bingoCardP + 5 + 0);
	cell2->letter = 'a';
	cell2->digit = '0';
	cell2->matched = true;

	cardCellContent* cell3 = *(bingoCardP + 10 + 0);
	cell3->letter = 'a';
	cell3->digit = '0';
	cell3->matched = true;

	if(checkColumn(bingoCardP))
	{
		ok = false;
		puts("test checkColumn case 2 did not pass");fflush(stdout);
	}
	else
	{
		puts("test checkColumn case 2 passed"); fflush(stdout);
	}

	//case 3: five in a row found at first column

	cardCellContent* cell4 = *(bingoCardP + 15 + 0);
	cell4->letter = 'a';
	cell4->digit = '0';
	cell4->matched = true;

	cardCellContent* cell5 = *(bingoCardP + 20 + 0);
	cell5->letter = 'a';
	cell5->digit = '0';
	cell5->matched = true;

	if(!checkColumn(bingoCardP))
	{
		ok = false;
		puts("test checkColumn case 3 did not pass");fflush(stdout);
	}
	else
	{
		puts("test checkColumn case 3 passed"); fflush(stdout);
	}

	//case 4: five in a row found at third column -> checks different place

	//cancel case 3
	cell5->letter = 'a';
	cell5->digit = '0';
	cell5->matched = false;

	//modifying column 3
	cardCellContent* cellA = *(bingoCardP + 0 + 2);
	cellA->letter = 'a';
	cellA->digit = '0';
	cellA->matched = true;

	cardCellContent* cellB = *(bingoCardP + 5 + 2);
	cellB->letter = 'a';
	cellB->digit = '0';
	cellB->matched = true;

	cardCellContent* cellC = *(bingoCardP + 10 + 2);
	cellC->letter = 'a';
	cellC->digit = '0';
	cellC->matched = true;

	cardCellContent* cellD = *(bingoCardP + 15 + 2);
	cellD->letter = 'a';
	cellD->digit = '0';
	cellD->matched = true;

	cardCellContent* cellE = *(bingoCardP + 20 + 2);
	cellE->letter = 'a';
	cellE->digit = '0';
	cellE->matched = true;

	if(!checkColumn(bingoCardP))
	{
		ok = false;
		puts("test checkColumn case 4 did not pass");fflush(stdout);
	}
	else
	{
		puts("test checkColumn case 4 passed"); fflush(stdout);
	}

	return ok;
}

bool testCheckRow(){
	bool ok = true;

	//initialize board
	cardCellContent** bingoCardP = (cardCellContent**) malloc(5*5*sizeof(cardCellContent*));
	initSpace(bingoCardP, 5);

	//case 1: no cells marked
	if(checkRow(bingoCardP))
	{
		ok = false;
		puts("test checkRow case 1 did not pass"); fflush(stdout);
	}
	else
	{
		puts("test checkRow case 1 passed");fflush(stdout);
	}
	//case 2: three in a row

	//modifying the board
	cardCellContent* cell1 = *(bingoCardP + 0 + 0);
	cell1->letter = 'a';
	cell1->digit = '0';
	cell1->matched = true;

	cardCellContent* cell2 = *(bingoCardP + 0 + 1);
	cell2->letter = 'a';
	cell2->digit = '0';
	cell2->matched = true;

	cardCellContent* cell3 = *(bingoCardP + 0 + 2);
	cell3->letter = 'a';
	cell3->digit = '0';
	cell3->matched = true;

	if(checkRow(bingoCardP))
	{
		ok = false;
		puts("test checkRow case 2 did not pass");fflush(stdout);
	}
	else
	{
		puts("test checkRow case 2 passed"); fflush(stdout);
	}

	//case 3: five in a row found at first row

	cardCellContent* cell4 = *(bingoCardP + 0 + 3);
	cell4->letter = 'a';
	cell4->digit = '0';
	cell4->matched = true;

	cardCellContent* cell5 = *(bingoCardP + 0 + 4);
	cell5->letter = 'a';
	cell5->digit = '0';
	cell5->matched = true;

	if(checkRow(bingoCardP))
	{
		puts("test checkRow case 3 passed"); fflush(stdout);
	}
	else
	{
		ok = false;
		puts("test checkRow case 3 did not pass");fflush(stdout);
	}

	//case 4: five in a row found at third row -> checks different place

	//cancel case 3
	cell5->letter = 'a';
	cell5->digit = '0';
	cell5->matched = false;

	//modifying row 3
	cardCellContent* cellA = *(bingoCardP + 10 + 0);
	cellA->letter = 'a';
	cellA->digit = '0';
	cellA->matched = true;

	cardCellContent* cellB = *(bingoCardP + 10 + 1);
	cellB->letter = 'a';
	cellB->digit = '0';
	cellB->matched = true;

	cardCellContent* cellC = *(bingoCardP + 10 + 2);
	cellC->letter = 'a';
	cellC->digit = '0';
	cellC->matched = true;

	cardCellContent* cellD = *(bingoCardP + 10 + 3);
	cellD->letter = 'a';
	cellD->digit = '0';
	cellD->matched = true;

	cardCellContent* cellE = *(bingoCardP + 10 + 4);
	cellE->letter = 'a';
	cellE->digit = '0';
	cellE->matched = true;

	if(checkRow(bingoCardP))
	{
		puts("test CheckRow case 4 passed"); fflush(stdout);
	}
	else
	{
		ok = false;
		puts("test checkRow case 4 did not pass");fflush(stdout);
	}

	return ok;
}

bool testCheckDiagonalLeftToRight(){
	bool ok = true;

	//initialize board
	cardCellContent** bingoCardP = (cardCellContent**) malloc(5*5*sizeof(cardCellContent*));
	initSpace(bingoCardP, 5);

	//case 1: no cells marked
	if(checkDiagonalLeftToRight(bingoCardP))
	{
		ok = false;
		puts("test checkDiagonalLeftToRight case 1 did not pass"); fflush(stdout);
	}
	else
	{
		puts("test checkDiagonalLeftToRight case 1 passed");fflush(stdout);
	}
	//case 2: three in a row

	//modifying the board
	cardCellContent* cell1 = *(bingoCardP + 0 + 0);
	cell1->letter = 'a';
	cell1->digit = '0';
	cell1->matched = true;

	cardCellContent* cell2 = *(bingoCardP + 5 + 1);
	cell2->letter = 'a';
	cell2->digit = '0';
	cell2->matched = true;

	cardCellContent* cell3 = *(bingoCardP + 10 + 2);
	cell3->letter = 'a';
	cell3->digit = '0';
	cell3->matched = true;

	if(checkDiagonalLeftToRight(bingoCardP))
	{
		ok = false;
		puts("test checkDiagonalLeftToRight case 2 did not pass");fflush(stdout);
	}
	else
	{
		puts("test checkDiagonalLeftToRight case 2 passed"); fflush(stdout);
	}

	//case 3: five in a row found at diagonal

	cardCellContent* cell4 = *(bingoCardP + 15 + 3);
	cell4->letter = 'a';
	cell4->digit = '0';
	cell4->matched = true;

	cardCellContent* cell5 = *(bingoCardP + 20 + 4);
	cell5->letter = 'a';
	cell5->digit = '0';
	cell5->matched = true;


	if(checkDiagonalLeftToRight(bingoCardP))
	{
		puts("test checkDiagonalLeftToRight case 3 passed"); fflush(stdout);
	}
	else
	{
		ok = false;
		puts("test checkDiagonalLeftToRight case 3 did not pass");fflush(stdout);
	}

	return ok;
}

bool testCheckDiagonalRightToLeft(){
	bool ok = true;

	//initialize board
	cardCellContent** bingoCardP = (cardCellContent**) malloc(5*5*sizeof(cardCellContent*));
	initSpace(bingoCardP, 5);

	//case 1: no cells marked
	if(checkDiagonalRightToLeft(bingoCardP))
	{
		ok = false;
		puts("test checkDiagonalRightToLeft case 1 did not pass"); fflush(stdout);
	}
	else
	{
		puts("test checkDiagonalRightToLeft case 1 passed");fflush(stdout);
	}
	//case 2: three in a row

	//modifying the board
	cardCellContent* cell1 = *(bingoCardP + 0 + 4);
	cell1->letter = 'a';
	cell1->digit = '0';
	cell1->matched = true;

	cardCellContent* cell2 = *(bingoCardP + 5 + 3);
	cell2->letter = 'a';
	cell2->digit = '0';
	cell2->matched = true;

	cardCellContent* cell3 = *(bingoCardP + 10 + 2);
	cell3->letter = 'a';
	cell3->digit = '0';
	cell3->matched = true;

	if(checkDiagonalRightToLeft(bingoCardP))
	{
		ok = false;
		puts("test checkDiagonalRightToLeft case 2 did not pass");fflush(stdout);
	}
	else
	{
		puts("test checkDiagonalRightToLeft case 2 passed"); fflush(stdout);
	}

	//case 3: five in a row found at diagonal

	cardCellContent* cell4 = *(bingoCardP + 15 + 1);
	cell4->letter = 'a';
	cell4->digit = '0';
	cell4->matched = true;

	cardCellContent* cell5 = *(bingoCardP + 20 + 0);
	cell5->letter = 'a';
	cell5->digit = '0';
	cell5->matched = true;


	if(checkDiagonalRightToLeft(bingoCardP))
	{
		puts("test checkDiagonalRightToLeft case 3 passed"); fflush(stdout);
	}
	else
	{
		ok = false;
		puts("test checkDiagonalRightToLeft case 3 did not pass");fflush(stdout);
	}

	return ok;
}

bool testIsWin(){
	bool ok = true;

	//initialize board
	cardCellContent** bingoCardP = (cardCellContent**) malloc(5*5*sizeof(cardCellContent*));
	initSpace(bingoCardP, 5);

	//case 1: no win
	if(isWin(bingoCardP)){
		ok = false;
		puts("test isWin case 1 did not pass"); fflush(stdout);
	}
	else{
		puts("test isWin case 1 passed");fflush(stdout);
	}

	//case 2: diagonal win
	cardCellContent* cell1 = *(bingoCardP + 0 + 4);
	cell1->letter = 'a';
	cell1->digit = '0';
	cell1->matched = true;

	cardCellContent* cell2 = *(bingoCardP + 5 + 3);
	cell2->letter = 'a';
	cell2->digit = '0';
	cell2->matched = true;

	cardCellContent* cell3 = *(bingoCardP + 10 + 2);
	cell3->letter = 'a';
	cell3->digit = '0';
	cell3->matched = true;

	cardCellContent* cell4 = *(bingoCardP + 15 + 1);
	cell4->letter = 'a';
	cell4->digit = '0';
	cell4->matched = true;

	cardCellContent* cell5 = *(bingoCardP + 20 + 0);
	cell5->letter = 'a';
	cell5->digit = '0';
	cell5->matched = true;

	if(isWin(bingoCardP)){
		puts("test isWin case 2 passed");fflush(stdout);
	}
	else{
		ok = false;
		puts("test isWin case 2 did not pass");fflush(stdout);
	}

	cell1->letter = 'a';
	cell1->digit = '0';
	cell1->matched = false;

	cell2->letter = 'a';
	cell2->digit = '0';
	cell2->matched = false;

	cell3->letter = 'a';
	cell3->digit = '0';
	cell3->matched = false;

	cell4->letter = 'a';
	cell4->digit = '0';
	cell4->matched = false;

	cell5->letter = 'a';
	cell5->digit = '0';
	cell5->matched = false;

	//case 3: horizontal win

	cardCellContent* cellA = *(bingoCardP + 0 + 0);
	cellA->letter = 'a';
	cellA->digit = '0';
	cellA->matched = true;

	cardCellContent* cellB = *(bingoCardP + 0 + 1);
	cellB->letter = 'a';
	cellB->digit = '0';
	cellB->matched = true;

	cardCellContent* cellC = *(bingoCardP + 0 + 2);
	cellC->letter = 'a';
	cellC->digit = '0';
	cellC->matched = true;

	cardCellContent* cellD = *(bingoCardP + 0 + 3);
	cellD->letter = 'a';
	cellD->digit = '0';
	cellD->matched = true;

	cardCellContent* cellE = *(bingoCardP + 0 + 4);
	cellE->letter = 'a';
	cellE->digit = '0';
	cellE->matched = true;

	if(isWin(bingoCardP)){
		puts("test isWin case 3 passed");fflush(stdout);
	}
	else{
		ok = false;
		puts("test isWin case 3 did not pass");fflush(stdout);
	}


	cellA->letter = 'a';
	cellA->digit = '0';
	cellA->matched = false;

	cellB->letter = 'a';
	cellB->digit = '0';
	cellB->matched = false;

	cellC->letter = 'a';
	cellC->digit = '0';
	cellC->matched = false;

	cellD->letter = 'a';
	cellD->digit = '0';
	cellD->matched = false;

	cellE->letter = 'a';
	cellE->digit = '0';
	cellE->matched = false;

	//case 4: vertical win

	cardCellContent* cellV = *(bingoCardP + 0 + 0);
	cellV->letter = 'a';
	cellV->digit = '0';
	cellV->matched = true;

	cardCellContent* cellW = *(bingoCardP + 5 + 0);
	cellW->letter = 'a';
	cellW->digit = '0';
	cellW->matched = true;

	cardCellContent* cellX = *(bingoCardP + 10 + 0);
	cellX->letter = 'a';
	cellX->digit = '0';
	cellX->matched = true;

	cardCellContent* cellY = *(bingoCardP + 15 + 0);
	cellY->letter = 'a';
	cellY->digit = '0';
	cellY->matched = true;

	cardCellContent* cellZ = *(bingoCardP + 20 + 0);
	cellZ->letter = 'a';
	cellZ->digit = '0';
	cellZ->matched = true;

	if(isWin(bingoCardP)){
		puts("test isWin case 4 passed");fflush(stdout);
	}
	else{
		ok = false;
		puts("test isWin case 4 did not pass");fflush(stdout);
	}

	return ok;
}

bool testDelay(){
	bool ok = true;
	int timeBefore = time(0);
	delay(1);
	if(timeBefore >= time(0)){
		ok = false;
		printf("testDelay did not pass\n");fflush(stdout);
	}
	else{
		printf("testDelay passed\n");fflush(stdout);
	}
	return ok;
}
