/*
 * production.c
 *
 *  Created on: Jan 27, 2021
 *      Author: Andrew Hariyanto
 */

#include "production.h"

bool production(int argc, char* argv[])
{
	bool answer = true;
	int nCalls = -1;

		if(argc <=1) //no interesting information
		{
			puts("Didn't find any arguments.");
			fflush(stdout);
			answer = false;
		}
		else //there is interesting information
		{
			printf("Found %d arguments.\n", argc);
			fflush(stdout);
			long aL=-1L;


			for(int i = 1; i<argc; i++) //don't want to read argv[0]
			{//argv[i] is a string
				//in this program our arguments are a filename followed by the max of rooms, followed by max of treasure
				switch(i)
				{
				case 1:

					//this is the number of calls

					aL= strtol(argv[i], NULL, 10);
					nCalls = (int) aL;
					if(nCalls <0)
					{
						answer = false;
					}
					printf("Number of calls is %d\n",nCalls);fflush(stdout);
					break;

				default:
					puts("Unexpected argument count."); fflush(stdout);
					answer = false;
					break;
				}//end of switch
			}//end of for loop on argument count
			puts("after reading arguments"); fflush(stdout);

		}//end of command line arguments

		//obtain space for bingo card
		cardCellContent** bingoCardP = (cardCellContent**) malloc(5*5*sizeof(cardCellContent*));
	    initSpace(bingoCardP, 5);
	    displaySpace(bingoCardP, 5);
	    printf("\n");fflush(stdout);

	    //initialize empty linked list
	    LLNode* recordList = makeEmptyLinkedList();

        //the caller is going call some random values
	    for(int i = 0; i<nCalls; i++)
	    {
	    	//caller calls
	    	cardCellContent* randCell = callRandomCell();

	    	//is it a match? And save result on linked list
	    	setMatch(bingoCardP, randCell, recordList);

	    	//show the board
	    	displaySpace(bingoCardP, 5);
	    	printf("\n");fflush(stdout);

	    	//did we win?
	    	if(isWin(bingoCardP)){
	    		printf("Congratulations! You won!\n"); fflush(stdout);
	    		displaySpace(bingoCardP, 5);
	    		return answer;
	    	}
	    	delay(1);
	    }

	    displaySpace(bingoCardP, 5);
		return answer;
}
