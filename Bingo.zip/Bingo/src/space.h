/*
 * space.h
 *
 *  Created on: Jan 27, 2021
 *      Author: Andrew Hariyanto
 */

#ifndef SPACE_H_
#define SPACE_H_

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include "time.h"  //<- for srand() function
#include "LinkedList.h"

void initSpace(cardCellContent**, int);
void displaySpace(cardCellContent**, int);
cardCellContent* callRandomCell();
bool compareCell(cardCellContent*, cardCellContent*);
void setMatch(cardCellContent**,cardCellContent*,LLNode*);
bool checkColumn(cardCellContent**);
bool checkRow(cardCellContent**);
bool checkDiagonalLeftToRight(cardCellContent**);
bool checkDiagonalRightToLeft(cardCellContent**);
bool isWin(cardCellContent**);
void delay(int);

#endif /* SPACE_H_ */
