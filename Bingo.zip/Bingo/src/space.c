/*
 * space.c
 *
 *  Created on: Jan 27, 2021
 *      Author: Andrew Hariyanto
 */
#include "space.h"

void initSpace(cardCellContent** corner, int howManyRows)
{
	for(int row = 0; row< howManyRows; row++)
	{
		for(int col = 0; col < howManyRows; col++)
		{
			cardCellContent* x = (cardCellContent*) malloc (sizeof(cardCellContent)); //reserve a cardCell on heap
			x->row = row;
			x->col = col;
			x->letter = (char) (rand() % 26) + 65;
			x->digit = (rand() % 10) + 48;
			cardCellContent**  thatCellP = corner + row*howManyRows + col;
			*thatCellP = x; //put its address into bingo card space
		}
	}
}

void displaySpace(cardCellContent** corner, int howManyRows)
{
	for(int row = 0; row< howManyRows; row++)
		{
			for(int col = 0; col < howManyRows; col++)
			{
				cardCellContent* cell = *(corner+row*howManyRows + col);
				printf(" %c%c ", cell->letter, cell->digit);
			}
			printf("\n");
		}
}

cardCellContent* callRandomCell()
{
	srand(time(0));//-> makes it even more random
	cardCellContent* x = (cardCellContent*) malloc (sizeof(cardCellContent)); //reserve a cardCell on heap
	x->letter = (char) (rand() % 26) + 65;
	x->digit = (rand() % 10) + 48;
	printf("The next call is %c%c\n", x->letter, x->digit);fflush(stdout);
	return x;
}

bool compareCell(cardCellContent* cell1, cardCellContent* cell2)
{
	bool isSame = false;
	if(cell1->letter == cell2->letter && cell1->digit == cell2->digit)
	{
		isSame = true;
		return isSame;
	}
	else
	{
		return isSame;
	}
}

void setMatch(cardCellContent** board, cardCellContent* randCell, LLNode* list)
{
	bool noMatch = true;
	for(int row = 0; row < 5; row++)
	{
		for(int col = 0; col < 5; col++)
		{
			cardCellContent* cell = *(board+row*5 + col);
			if(compareCell(cell, randCell))
			{
				cell->matched = true;
				cell->letter = 'a';
				cell->digit = '0';

				randCell->matched = true;
				randCell->col = col;
				randCell->row = row;

				savePayload(list, randCell);
				noMatch = false;
			}
		}
	}
	if(noMatch){
		savePayload(list, randCell);
	}
	else{
		//do nothing
	}
}

bool isWin(cardCellContent** board)
{
	bool ok = true;
	if(checkRow(board) || checkColumn(board) || checkDiagonalLeftToRight(board) || checkDiagonalRightToLeft(board))
	{
		return ok;
	}
	else{
		ok = false;
		return ok;
	}
}

bool checkRow(cardCellContent** board)
{
	bool ok = false;
	//checking all rows. Once five in a row is found, return true.
	for(int row = 0; row< 5; row++)
	{
		int accum = 0;
		for(int col = 0; col < 5; col++)
		{
			cardCellContent* cell = *(board+row*5 + col);
			if(cell->matched)
			{
				accum++;
			}
			if(accum == 5)
			{
				ok = true;
				return ok;
			}
		}
	}
	return ok;
}

bool checkColumn(cardCellContent** board)
{
	bool ok = false;
	//checking all columns. Once five in a row is found, return true.
	for(int col = 0; col< 5; col++)
	{
		int accum = 0;
		for(int row = 0; row < 5; row++)
		{
			cardCellContent* cell = *(board+row*5 + col);
			if(cell->matched)
			{
				accum++;
			}
			if(accum == 5)
			{
				ok = true;
				return ok;
			}
		}
	}
	return ok;
}

bool checkDiagonalLeftToRight(cardCellContent** board){
	bool ok = false;
	//checking all diagonals. Once five in a row is found, return true.
	int accum = 0;
	for(int col = 0, row = 0; col< 5; col++, row++)
	{
		cardCellContent* cell = *(board+row*5 + col);
		if(cell->matched)
		{
			accum++;
		}
		if(accum == 5)
		{
			ok = true;
			return ok;
		}
	}
	return ok;
}

bool checkDiagonalRightToLeft(cardCellContent** board){
	bool ok = false;
	//checking all diagonals. Once five in a row is found, return true.
	int accum = 0;
	for(int col = 4, row = 0; row<5; col--, row++)
	{
		cardCellContent* cell = *(board+row*5 + col);
		if(cell->matched)
		{
			accum++;
		}
		if(accum == 5)
		{
			ok = true;
			return ok;
		}
	}
	return ok;
}

void delay(int numSeconds) //<- for delay for srand()
{
    // Converting time into milli_seconds
    int milliSeconds = 1000 * numSeconds;

    // Storing start time
    clock_t startTime = clock();

    // looping till required time is not achieved
    while (clock() < startTime + milliSeconds);
}

