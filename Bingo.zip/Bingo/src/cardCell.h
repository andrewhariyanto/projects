/*
 * cardCell.h
 *
 *  Created on: Jan 27, 2021
 *      Author: Andrew Hariyanto
 */


typedef struct
{
	int row;
	int col;
	char letter;
	char digit;
	bool matched;
}cardCellContent;
