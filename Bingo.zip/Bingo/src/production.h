/*
 * production.h
 *
 *  Created on: Jan 27, 2021
 *      Author: Andrew Hariyanto
 */

#ifndef PRODUCTION_H_
#define PRODUCTION_H_
#include <stdio.h>
#include <stdbool.h>
#include <string.h>//strncpy
#include <stdlib.h>//strtol
#include "space.h"


#define FILENAMELENGTHALLOWANCE 50

bool production(int argc, char* argv[]);



#endif /* PRODUCTION_H_ */
